# SWarp

[![Build Status](https://travis-ci.org/astromatic/swarp.svg?branch=master)](https://travis-ci.org/astromatic/swarp
[![Coverity Scan Build Status](https://scan.coverity.com/projects/swarp/badge.svg)](https://scan.coverity.com/projects/swarp "Coverity Badge")
[![Documentation Status](https://readthedocs.org/projects/swarp/badge/?version=latest)](http://swarp.readthedocs.io/en/latest/?badge=latest)

[Swarp] resamples and coadds FITS images to an arbitrary astrometric projection

Check out the on-line [documentation], the [official web page], and the [user forum].

[SWarp]: http://astromatic.net/software/swarp
[documentation]: https://www.astromatic.net/pubsvn/software/swarp/trunk/doc/swarp.pdf
[official web page]: http://astromatic.net/software/swarp
[user forum]: http://astromatic.net/forum/forumdisplay.php?fid=5

