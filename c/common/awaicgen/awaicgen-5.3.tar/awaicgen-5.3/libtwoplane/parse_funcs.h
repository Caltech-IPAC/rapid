
int parse_str(char *fitsheader, char *value, const char *key);

int parse_double(char *fitsheader, double *value, const char *key);

int parse_int(char *fitsheader, int *value, const char *key);


