
/***********************************************
awaicgen_compute_results_hires.c

Purpose

Main computational processing loop of program for
HiRes. Depends on function in awaicgen_compute_hirespix.c
to support multi-threading.

Input-to-output interpolation is based on using
input PRF(s) as the interpolation kernel(s) and
includes HiRes'ing via the MCM algorithm.

See awaicgen_compute_results.c for first iteration
of MCM to create a PRF-interpolated co-add,
or awaicgen_compute_results_simple.c for simple
co-add created using exact overlap-area weighting.

***********************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <pthread.h>
#include "awaicgen.h"
#include "awaicgen_defs.h"
#include "fitsio.h"
#include "wcs.h"
#include "two_plane.h"
#include "distort.h"

void *awaicgen_compute_hirespix(AWA_Impix         *AWAP_Impix);

int awaicgen_compute_results_hires(AWA_Constants     *AWAP_Const,
                            AWA_Filenames     *AWAP_Fnames,
                            AWA_Computation   *AWAP_Comp,
                            AWA_Impix         *AWAP_Impix,
                            AWA_Status        *AWAP_Stat)
{
  struct   WorldCoor *wcsoutput;
  char     *inheaderfits;

  float   **sig_cell_array;
  float   **fitr_cell_array;
  float   **CF_j;
  float   **CFFVo_j;
  float   **CFVo_j;
  float   C_j, CS_j, CFV_j, CFV_jpctdiff;
  float   outin_area_ratio, chisq_m;
  double  xmin_Cm, xmax_Cm, ymin_Cm, ymax_Cm;

  long    i, ii, j, jj, k, tasksPerThread;
  long    fimgpix[2], xj_min, yj_min;
  long    naxis, naxes[2], priornaxis1, priornaxis2;
  int     m, p, iter, t, status=0, maxoffset=0, nkeys, offscl;
  int     x_scl, y_scl, ProjectionStatus, NumGoodD_i;
  short int **NlastIter_j;

  fitsfile *ffp_FITS_In;
  fitsfile *ffp_FITS_Msk;
  fitsfile *ffp_FITS_Unc;

  pthread_t thread[AWAP_Const->NumThreads];
  AWA_Impix hiresdata[AWAP_Const->NumThreads];

  if(AWAP_Stat->I_status)
    return 0;

/*----------------------------------------------------------------------*/
/* Copy some global variables into "AWA_Impix" global variables to use in
   each thread call to awaicgen_compute_hirespix.c below. */

  for(t = 0; t < AWAP_Const->NumThreads; t++) {
    hiresdata[t].cp.cellnaxis1 = AWAP_Comp->cellnaxis1;
    hiresdata[t].cp.cellnaxis2 = AWAP_Comp->cellnaxis2;
    hiresdata[t].cp.numprfs = AWAP_Comp->numprfs;
    hiresdata[t].cp.prfgriddim = AWAP_Comp->prfgriddim;
    hiresdata[t].cp.imgnaxis1 = AWAP_Comp->imgnaxis1;
    hiresdata[t].cp.imgnaxis2 = AWAP_Comp->imgnaxis2;
    hiresdata[t].cp.prflistind = AWAP_Comp->prflistind;
    hiresdata[t].cp.prfnaxis1 = AWAP_Comp->prfnaxis1;
    hiresdata[t].cp.prfnaxis2 = AWAP_Comp->prfnaxis2;
    hiresdata[t].cp.prfcrpix1 = AWAP_Comp->prfcrpix1;
    hiresdata[t].cp.prfcrpix2 = AWAP_Comp->prfcrpix2;
    hiresdata[t].cp.prfdata = AWAP_Comp->prfdata;
    hiresdata[t].co.have_uncert = AWAP_Const->have_uncert;
    hiresdata[t].co.have_masks = AWAP_Const->have_masks;
    hiresdata[t].co.Weight_Flag = AWAP_Const->Weight_Flag;
    hiresdata[t].co.Fatal_Bits = AWAP_Const->Fatal_Bits;
    hiresdata[t].co.Num_Iter = AWAP_Const->Num_Iter;
    hiresdata[t].co.RotPRF_Flag = AWAP_Const->RotPRF_Flag;
    hiresdata[t].co.Interp_Method = AWAP_Const->Interp_Method;
    hiresdata[t].co.want_cffv = AWAP_Const->want_cffv;
    strcpy(hiresdata[t].fn.Filename_Input_MosaicCell,
           AWAP_Fnames->Filename_Input_MosaicCell);
    hiresdata[t].st.I_Verbose = AWAP_Stat->I_Verbose;
  }


/*----------------------------------------------------------------------*/
/* Define number of tasks per thread, rounded to nearest integer. Also
   assign input image pixel ranges for each concurrent thread to run below.
   Note: kstart,kend refer to 1D pixel indices; iistart,iiend refer to
   indices along Y-axis of input image. */

  tasksPerThread = (long) (((AWAP_Comp->imgnaxis1*AWAP_Comp->imgnaxis2) +
                             AWAP_Const->NumThreads-1)/AWAP_Const->NumThreads);

  if( AWAP_Stat->I_Verbose )
    printf("awaicgen_comp_res_hires: %s to process per thread (%s %d %s) = %ld\n",
           "average number of input pixels", "over", AWAP_Const->NumThreads,
           "threads", tasksPerThread);

  for(t = 0; t < AWAP_Const->NumThreads; t++) {
    k = 0;
    for(ii = 0; ii < AWAP_Comp->imgnaxis2; ii++) {
      for(i = 0; i < AWAP_Comp->imgnaxis1; i++) {
        if( k == t*tasksPerThread ) {
          hiresdata[t].kstart = k;
          hiresdata[t].iistart = ii;
        }
        if( k == (t+1)*tasksPerThread - 1 ) {
          hiresdata[t].kend = k;
          hiresdata[t].iiend = ii;
        }
        k++;
      }
    }
  }

  /* ensure indices for last thread don't exceed their allowed maxima. */

  hiresdata[AWAP_Const->NumThreads-1].iiend = AWAP_Comp->imgnaxis2 - 1;
  hiresdata[AWAP_Const->NumThreads-1].kend =
                       (AWAP_Comp->imgnaxis1*AWAP_Comp->imgnaxis2) - 1;

  if( AWAP_Stat->I_Verbose ) {
    printf("awaicgen_comp_res_hires: input image pixel processing ranges %s:\n",
           "per thread (zero-based)");
    for(t = 0; t < AWAP_Const->NumThreads; t++) {
       printf("awaicgen_comp_res_hires: thread %d: ystart = %ld, yend = %ld; ",
              t, hiresdata[t].iistart, hiresdata[t].iiend);
       printf("1D: kstart = %ld, kend = %ld\n", hiresdata[t].kstart,
              hiresdata[t].kend);
    }
  }


/*----------------------------------------------------------------------*/
/* Allocate memory to internal working arrays. */

  /*----------*/
  /* Internal mosaic sub-pixel (cell) grid sampled at pixel size:
     Mosaic_PixFact * Mosaic_CellFact * inp_image_CDELT or
     Mosaic_PixScal * Mosaic_CellFact. */

  AWAP_Impix->mos_cell_array = (float **) calloc(AWAP_Comp->cellnaxis2,
                                                 sizeof(float *));

  if( AWAP_Impix->mos_cell_array == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not allocate %s\n",
            "memory for mos_cell_array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_comp_res_hires: allocated %f MB for %s\n",
             (AWAP_Comp->cellnaxis1*
             AWAP_Comp->cellnaxis2*sizeof(float)/1.0E+06),
             "internal mosaic cell array.");
    }
  }

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ ) {

    AWAP_Impix->mos_cell_array[i] = (float *) calloc(AWAP_Comp->cellnaxis1,
                                                     sizeof(float));

    if( AWAP_Impix->mos_cell_array[i] == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
              "allocate memory for mos_cell_array.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  /*----------*/
  /* Internal mosaic sub-pixel (cell) grid sampled similar to mos_cell_array to
     store first iteration intensities to write out to downsampled FITS image
     later. Only allocated if output filename specified and Num_Iter > 1. */

  if( strcmp(AWAP_Fnames->Filename_Output_MosaicFIter,"") &&
      (AWAP_Const->Num_Iter > 1) ) {

    fitr_cell_array = (float **) calloc(AWAP_Comp->cellnaxis2,
                                        sizeof(float *));

    if( fitr_cell_array == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
              "allocate memory for fitr_cell_array.");
      AWAP_Stat->I_status = 1;
      return 0;

    } else {

      if( AWAP_Stat->I_Verbose ) {
        printf("awaicgen_comp_res_hires: allocated %f MB for %s\n",
               (AWAP_Comp->cellnaxis1*
               AWAP_Comp->cellnaxis2*sizeof(float)/1.0E+06),
               "internal intensity mosaic first iteration cell array.");
      }
    }

    for( i = 0; i < AWAP_Comp->cellnaxis2; i++ ) {

      fitr_cell_array[i] = (float *) calloc(AWAP_Comp->cellnaxis1,
                                            sizeof(float));

      if( fitr_cell_array[i] == NULL ) {
        fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
                "allocate memory for fitr_cell_array.");
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }
  }

  /*----------*/
  /* Internal sub-pixel (cell) grid for Num_Iter = 1 uncertainties
     sampled at pixel size: Mosaic_PixFact * Mosaic_CellFact *
     inp_image_CDELT or Mosaic_PixScal * Mosaic_CellFact. */

  sig_cell_array = (float **) calloc(AWAP_Comp->cellnaxis2, sizeof(float *));

  if( sig_cell_array == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not allocate %s\n",
            "memory for sig_cell_array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_comp_res_hires: allocated %f MB for %s\n",
             (AWAP_Comp->cellnaxis1*
             AWAP_Comp->cellnaxis2*sizeof(float)/1.0E+06),
             "internal uncertainty (Num_Iter=1) cell array.");
    }
  }

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ ) {

    sig_cell_array[i] = (float *) calloc(AWAP_Comp->cellnaxis1, sizeof(float));

    if( sig_cell_array[i] == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
              "allocate memory for sig_cell_array.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  /*----------*/
  /* Internal Cnum_j (cell pixel grid) array for computing <C_j>. */

  AWAP_Impix->Cnum_j = (float **) calloc(AWAP_Comp->cellnaxis2,
                                         sizeof(float *));

  if( AWAP_Impix->Cnum_j == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not allocate %s\n",
            "memory for Cnum_j array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_comp_res_hires: allocated %f MB for %s\n",
             (AWAP_Comp->cellnaxis1*
             AWAP_Comp->cellnaxis2*sizeof(float)/1.0E+06),
             "internal Cnum_j array.");
    }
  }

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ ) {

    AWAP_Impix->Cnum_j[i] = (float *) calloc(AWAP_Comp->cellnaxis1,
                                             sizeof(float));

    if( AWAP_Impix->Cnum_j[i] == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
              "allocate memory for Cnum_j array.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  /*----------*/
  /* Internal NV_j (cell pixel grid) array for computing <C_j>. */

  AWAP_Impix->NV_j = (float **) calloc(AWAP_Comp->cellnaxis2, sizeof(float *));

  if( AWAP_Impix->NV_j == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not allocate %s\n",
            "memory for NV_j array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_comp_res_hires: allocated %f MB for %s\n",
             (AWAP_Comp->cellnaxis1*
             AWAP_Comp->cellnaxis2*sizeof(float)/1.0E+06),
             "internal NV_j array.");
    }
  }

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ ) {

    AWAP_Impix->NV_j[i] = (float *) calloc(AWAP_Comp->cellnaxis1,
                                           sizeof(float));

    if( AWAP_Impix->NV_j[i] == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
              "allocate memory for NV_j array.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  /*----------*/
  /* Internal N_j (cell pixel grid) "coverage depth" array. */

  AWAP_Impix->N_j = (float **) calloc(AWAP_Comp->cellnaxis2, sizeof(float *));

  if( AWAP_Impix->N_j == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not allocate %s\n",
            "memory for N_j array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_comp_res_hires: allocated %f MB for %s\n",
             (AWAP_Comp->cellnaxis1*
             AWAP_Comp->cellnaxis2*sizeof(float)/1.0E+06),
             "internal N_j array.");
    }
  }

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ ) {

    AWAP_Impix->N_j[i] = (float *) calloc(AWAP_Comp->cellnaxis1,sizeof(float));

    if( AWAP_Impix->N_j[i] == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
              "allocate memory for N_j array.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  /*----------*/
  /* Internal NSV_j (cell pixel grid) array for computing output uncerts.
     These output uncertainties are only valid for Num_Iter = 1. */

  AWAP_Impix->NSV_j = (float **) calloc(AWAP_Comp->cellnaxis2,sizeof(float *));

  if( AWAP_Impix->NSV_j == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not allocate %s\n",
            "memory for NSV_j array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_comp_res_hires: allocated %f MB for %s\n",
             (AWAP_Comp->cellnaxis1*
             AWAP_Comp->cellnaxis2*sizeof(float)/1.0E+06),
             "internal NSV_j array.");
    }
  }

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ ) {

    AWAP_Impix->NSV_j[i] = (float *) calloc(AWAP_Comp->cellnaxis1,
                                            sizeof(float));

    if( AWAP_Impix->NSV_j[i] == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
              "allocate memory for NSV_j array.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  /*----------*/
  /* Internal CF_j (cell pixel grid) array for storing MCM correction factors.
     Only valid if output filename for product specified. */

  if( AWAP_Const->want_corr ) {

    CF_j = (float **) calloc(AWAP_Comp->cellnaxis2, sizeof(float *));

    if( CF_j == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
              "allocate memory for CF_j array.");
      AWAP_Stat->I_status = 1;
      return 0;

    } else {

      if( AWAP_Stat->I_Verbose ) {
        printf("awaicgen_comp_res_hires: allocated %f MB for %s\n",
               (AWAP_Comp->cellnaxis1*
               AWAP_Comp->cellnaxis2*sizeof(float)/1.0E+06),
               "internal CF_j array.");
      }
    }

    for( i = 0; i < AWAP_Comp->cellnaxis2; i++ ) {

      CF_j[i] = (float *) calloc(AWAP_Comp->cellnaxis1, sizeof(float));

      if( CF_j[i] == NULL ) {
        fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
                "allocate memory for CF_j array.");
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }
  }

  /*----------*/
  /* Internal CFFV_j (cell pixel grid) array for storing MCM Correction
     Factor Flux Variance intermediate array. To be used for computing the
     data-derived 1-sigma uncertainty in final converged f_j flux value:
     CFFVo_j and the real CFV: CFVo_j. Only allocated if output filename
     for product specified. */

  if( AWAP_Const->want_cffv ) {

    AWAP_Impix->CFFV_j = (float **) calloc(AWAP_Comp->cellnaxis2,
                                           sizeof(float *));

    if( AWAP_Impix->CFFV_j == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
              "allocate memory for CFFV_j array.");
      AWAP_Stat->I_status = 1;
      return 0;

    } else {

      if( AWAP_Stat->I_Verbose ) {
        printf("awaicgen_comp_res_hires: allocated %f MB for %s\n",
               (AWAP_Comp->cellnaxis1*
               AWAP_Comp->cellnaxis2*sizeof(float)/1.0E+06),
               "internal CFFV_j array.");
      }
    }

    for( i = 0; i < AWAP_Comp->cellnaxis2; i++ ) {

      AWAP_Impix->CFFV_j[i] = (float *) calloc(AWAP_Comp->cellnaxis1,
                                               sizeof(float));

      if( AWAP_Impix->CFFV_j[i] == NULL ) {
        fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
                "allocate memory for CFFV_j array.");
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }
  }

  /*----------*/
  /* Actual output CFFVo_j (cell pixel grid) array for storing MCM Correction
     Factor Flux Variance array. To be used for computing the data-derived
     1-sigma uncertainty in final converged f_j flux value. Only allocated
     if output filename for product specified. */

  if( AWAP_Const->want_cffv ) {

    CFFVo_j = (float **) calloc(AWAP_Comp->cellnaxis2, sizeof(float *));

    if( CFFVo_j == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
              "allocate memory for CFFVo_j array.");
      AWAP_Stat->I_status = 1;
      return 0;

    } else {

      if( AWAP_Stat->I_Verbose ) {
        printf("awaicgen_comp_res_hires: allocated %f MB for %s\n",
               (AWAP_Comp->cellnaxis1*
               AWAP_Comp->cellnaxis2*sizeof(float)/1.0E+06),
               "internal CFFVo_j array.");
      }
    }

    for( i = 0; i < AWAP_Comp->cellnaxis2; i++ ) {

      CFFVo_j[i] = (float *) calloc(AWAP_Comp->cellnaxis1, sizeof(float));

      if( CFFVo_j[i] == NULL ) {
        fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
                "allocate memory for CFFVo_j array.");
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }
  }

  /*----------*/
  /* Real output CFVo_j (cell pixel grid) array for storing MCM Correction
     Factor Variances to write to FITS images and support position-dependent
     convergence processing. Only allocated if output filename for product
     specified. */

  if( AWAP_Const->want_cffv ) {

    CFVo_j = (float **) calloc(AWAP_Comp->cellnaxis2, sizeof(float *));

    if( CFVo_j == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
              "allocate memory for CFVo_j array.");
      AWAP_Stat->I_status = 1;
      return 0;

    } else {

      if( AWAP_Stat->I_Verbose ) {
        printf("awaicgen_comp_res_hires: allocated %f MB for %s\n",
               (AWAP_Comp->cellnaxis1*
               AWAP_Comp->cellnaxis2*sizeof(float)/1.0E+06),
               "internal CFVo_j array.");
      }
    }

    for( i = 0; i < AWAP_Comp->cellnaxis2; i++ ) {

      CFVo_j[i] = (float *) calloc(AWAP_Comp->cellnaxis1, sizeof(float));

      if( CFVo_j[i] == NULL ) {
        fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
                "allocate memory for CFVo_j array.");
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }
  }

  /*----------*/
  /* Internal NlastIter_j (cell pixel grid) array for storing the last
     "converged" iteration number for noise-suppression and position
     dependent covergence processing. */

  if( AWAP_Const->want_cffv && AWAP_Const->want_corr ) {

    NlastIter_j = (short int **) calloc(AWAP_Comp->cellnaxis2,
                                        sizeof(short int *));

    if( NlastIter_j == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
              "allocate memory for NlastIter_j array.");
      AWAP_Stat->I_status = 1;
      return 0;

    } else {

      if( AWAP_Stat->I_Verbose ) {
        printf("awaicgen_comp_res_hires: allocated %f MB for %s\n",
               (AWAP_Comp->cellnaxis1*
               AWAP_Comp->cellnaxis2*sizeof(short int)/1.0E+06),
               "internal NlastIter_j array.");
      }
    }

    for( i = 0; i < AWAP_Comp->cellnaxis2; i++ ) {

      NlastIter_j[i] = (short int *) calloc(AWAP_Comp->cellnaxis1,
                                            sizeof(short int));

      if( NlastIter_j[i] == NULL ) {
        fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
                "allocate memory for NlastIter_j array.");
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }
  }


/*----------------------------------------------------------------------*/
/* Initialize MCM model pixel values in mosaic sub-pixel (cell) grid to:
   (i) a flat image of 1's. This is recursively updated if Num_Iter > 1;
   (ii) a user-supplied model image (-f5 specified);
   (iii) an internally created overlap-area weighted (top-hat PRF) co-add
         (-fp 1 specified);
   (i) is used if (ii) and (iii) not set;
   (ii) is used if -f5 specified;
   (iii) is used if -fp 1 is specified and -f5 is not. */

  if( !strcmp(AWAP_Fnames->Filename_Input_MosaicCell,"") &&
      !AWAP_Const->TophatPrior ) {

    if( AWAP_Stat->I_Verbose )
      printf("awaicgen_comp_res_hires: assuming flat image of \"1's\" %s\n",
             "as starting model image for MCM...");

    for( jj = 0; jj < AWAP_Comp->cellnaxis2; jj++ )
      for( j = 0; j < AWAP_Comp->cellnaxis1; j++ )
        AWAP_Impix->mos_cell_array[jj][j] = 1.0;

  } else if( strcmp(AWAP_Fnames->Filename_Input_MosaicCell,"") ) {

    if( AWAP_Stat->I_Verbose )
      printf("awaicgen_comp_res_hires: using input FITS file: %s %s %s\n",
             AWAP_Fnames->Filename_Input_MosaicCell,
             "as starting model image for MCM", "...");

    fits_open_file(&ffp_FITS_In, AWAP_Fnames->Filename_Input_MosaicCell,
                   READONLY, &status);
    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: %s %s; %s %d\n",
              "error opening FITS file:",
              AWAP_Fnames->Filename_Input_MosaicCell,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    /* abort if dimensions of input prior image (-f5 input) does not
       match dimensions of internal cell-grid defined earlier. */

    fits_read_key(ffp_FITS_In, TLONG, "NAXIS1", &priornaxis1,
                  (char *)NULL, &status);
    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: error reading %s\n",
              "FITS keyword: NAXIS1");
      AWAP_Stat->I_status = 1;
      return 0;
    }

    fits_read_key(ffp_FITS_In, TLONG, "NAXIS2", &priornaxis2,
                  (char *)NULL, &status);
    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: error reading %s\n",
              "FITS keyword: NAXIS2");
      AWAP_Stat->I_status = 1;
      return 0;
    }

    if( priornaxis1 != AWAP_Comp->cellnaxis1 ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: NAXIS1 %s %s %s %ld\n",
              "of input prior image:",AWAP_Fnames->Filename_Input_MosaicCell,
              "must match internal cell-grid NAXIS1 =", AWAP_Comp->cellnaxis1);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    if( priornaxis2 != AWAP_Comp->cellnaxis2 ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: NAXIS2 %s %s %s %ld\n",
              "of input prior image:",AWAP_Fnames->Filename_Input_MosaicCell,
              "must match internal cell-grid NAXIS2 =", AWAP_Comp->cellnaxis2);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    fimgpix[0] = 1;  /* column dim. in input image. */
    fimgpix[1] = 1;  /* row dim. in input image.    */

    for(fimgpix[1] = 1; fimgpix[1] <= AWAP_Comp->cellnaxis2; fimgpix[1]++) {

      fits_read_pix(ffp_FITS_In, TFLOAT, fimgpix, AWAP_Comp->cellnaxis1,
                    NULL, AWAP_Impix->mos_cell_array[fimgpix[1] - 1],
                    NULL, &status);

      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_comp_res_hires: error %s %s\n",
                "storing pixel data from image",
                AWAP_Fnames->Filename_Input_MosaicCell);
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }

    fits_close_file(ffp_FITS_In, &status);
    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: %s %s; %s %d\n",
              "error closing FITS file:",
              AWAP_Fnames->Filename_Input_MosaicCell,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

  } else if( !strcmp(AWAP_Fnames->Filename_Input_MosaicCell,"")  &&
             AWAP_Const->TophatPrior ) {

    if( AWAP_Stat->I_Verbose )
      printf("awaicgen_comp_res_hires: creating top-hat PRF co-add %s\n",
             "for use as starting model image for MCM...");

    awaicgen_tophat_prior(AWAP_Impix->mos_cell_array,
                       AWAP_Const,
                       AWAP_Fnames,
                       AWAP_Comp,
                       AWAP_Stat);

    if(AWAP_Stat->I_status)
      return 0;
  }


/*----------------------------------------------------------------------*/
/* Initialize some ancillary cell-image arrays: position-dependent
   last-iteration number array NlastIter_j, and correction factor
   array CF_j. */

  for( jj = 0; jj < AWAP_Comp->cellnaxis2; jj++ ) {
    for( j = 0; j < AWAP_Comp->cellnaxis1; j++ ) {

      if( AWAP_Const->want_corr && AWAP_Const->want_cffv )
        NlastIter_j[jj][j] = AWAP_Const->Num_Iter;

      if( AWAP_Const->want_corr )
        CF_j[jj][j] = 0.0;
    }
  }


/*----------------------------------------------------------------------*/
/* Create output mosaic iteratively and incrementally using Maximum
   Correlation Method (MCM). Note, Num_Iter = 1 => simple mosaic.

   1. read single input image m;
   2. take a single detector pixel i with measured flux D_i;
   3. transform PRF pixels centered at this pixel to input image
      x,y system;
   4. transform this PRF's coords to the mosaic cell grid
      using same WCS as input image;
   5. assign each PRF data point to _nearest_ cell grid pixel;
   6. multiply PRF values in each cell grid with model/simulated
      flux already present and sum over all cell pixels j. This
      is the simulated detector pixel flux F_i;
   7. compute flux correction factor for detector pixel i in m:
      C_i = D_i / F_i and store. N.B. if Num_Iter = 1, C_i = D_i
      and no need to compute F_i from 6. Hence skip steps 6 and 7.
   8. repeat 2. --> 7. for all detector pixels in input image m;
   9. for a given cell pixel j, build mean correction factor
      <C_j> using response (and optionally prior variance)
      weighted averaging over all input factors C_i from image m;
  10. repeat 9. for all cell pixels j.
  11. repeat 1. --> 10. for all input images until <C_j> is built.
  12. compute corrected mosaic cell pixel flux:
      mos_cell_array[j] = mos_cell_array[j] * C_j.
  13. if ready to stop iteration, downsample (and trim if necessary)
      mos_cell_array[j] to final output: mos_pix_array[j]. */

  for( iter = 1; iter <= AWAP_Const->Num_Iter; iter++ ) {

    /*----------*/
    /* Initialize the <C_j> component arrays: Cnum_j, NV_j
       where eventually <C_j> = Cnum_j / NV_j, also coverage
       depth: N_j, output uncertainty component array:
       NSV_j (only valid for Num_Iter = 1), and Correction
       Factor Variance array: CFFV_j. */

    for( jj = 0; jj < AWAP_Comp->cellnaxis2; jj++ ) {
      for( j = 0; j < AWAP_Comp->cellnaxis1; j++ ) {

        AWAP_Impix->Cnum_j[jj][j] = 0.0;
        AWAP_Impix->NV_j[jj][j] = 0.0;
        AWAP_Impix->NSV_j[jj][j] = 0.0;
        AWAP_Impix->N_j[jj][j] = 0.0;

        if( AWAP_Const->want_cffv )
          AWAP_Impix->CFFV_j[jj][j] = 0.0;
      }
    }

    /* Loop over detector images. Initialize projection flag. */

    ProjectionStatus = 0;

    for( m = 0; m < AWAP_Comp->numimages; m++ ) {

      fits_open_file(&ffp_FITS_In, AWAP_Fnames->Filename_FITS_Image[m],
                     READONLY, &status);
      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_comp_res_hires: %s %s; %s %d\n",
                "error opening FITS file:",
                AWAP_Fnames->Filename_FITS_Image[m],
                "FITS error code =", status);
        AWAP_Stat->I_status = 1;
        return 0;
      }

      /*----------*/
      /* store pixel data from detector image m in 2D dynamic array. */

      AWAP_Impix->imgdata = (float **) calloc(AWAP_Comp->imgnaxis2,
                                              sizeof(float *));

      for( p = 0; p < AWAP_Comp->imgnaxis2; p++ )
        AWAP_Impix->imgdata[p] = (float *) calloc(AWAP_Comp->imgnaxis1,
                                                  sizeof(float));

      if( AWAP_Impix->imgdata == NULL ) {
        fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
                "allocate memory for imgdata array.");
        AWAP_Stat->I_status = 1;
        return 0;
      }

      fimgpix[0] = 1;  /* column dim. in input image. */
      fimgpix[1] = 1;  /* row dim. in input image.    */

      /* pixel data is stored as: imgdata[y_pix-1][x_pix-1] where
         y_pix = 1..naxis2; x_pix = 1..naxis1. */

      for(fimgpix[1] = 1; fimgpix[1] <= AWAP_Comp->imgnaxis2; fimgpix[1]++) {

        fits_read_pix(ffp_FITS_In, TFLOAT, fimgpix, AWAP_Comp->imgnaxis1,
                      NULL, AWAP_Impix->imgdata[fimgpix[1] - 1],NULL,&status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_comp_res_hires: error %s %s\n",
                  "storing pixel data from image",
                  AWAP_Fnames->Filename_FITS_Image[m]);
          AWAP_Stat->I_status = 1;
          return 0;
        }
      }

      printf("\n----------\n");
      printf("awaicgen_comp_res_hires: %s #%d of %d: %s #%d of %d: %s %s\n",
             "iteration", iter, AWAP_Const->Num_Iter, "processing image",
             m+1, AWAP_Comp->numimages,
             AWAP_Fnames->Filename_FITS_Image[m],"...");

      /*----------*/
      /* get the WCS keywords from image m to use in projection below. */

      ffhdr2str(ffp_FITS_In, 1, NULL, 0, &inheaderfits, &nkeys, &status);
      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_comp_res_hires: %s %s; %s %d\n",
                "error reading FITS header:",
                AWAP_Fnames->Filename_FITS_Image[m],
                "FITS error code =", status);
        AWAP_Stat->I_status = 1;
        return 0;
      }

      fits_close_file(ffp_FITS_In, &status);
      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_comp_res_hires: %s %s; %s %d\n",
                "error closing FITS file:",
                AWAP_Fnames->Filename_FITS_Image[m],
                "FITS error code =", status);
        AWAP_Stat->I_status = 1;
        return 0;
      }

      /*----------*/
      /* read/store pixel uncertainty data (if specified) for detector image
         m in 2D dynamic array. These are assumed to be sigmas, not
         variances. */

      if( AWAP_Const->have_uncert ) {

        if( AWAP_Stat->I_Verbose )
          printf("awaicgen_comp_res_hires: reading/storing %s #%d: %s %s\n",
                 "uncertainty image", m+1,
                 AWAP_Fnames->Filename_FITS_Uncert[m], "...");

        fits_open_file(&ffp_FITS_Unc, AWAP_Fnames->Filename_FITS_Uncert[m],
                       READONLY, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_comp_res_hires: %s %s; %s %d\n",
                  "error opening FITS file:",
                  AWAP_Fnames->Filename_FITS_Uncert[m],
                  "FITS error code =", status);
          AWAP_Stat->I_status = 1;
          return 0;
        }

        AWAP_Impix->uncdata = (float **) calloc(AWAP_Comp->imgnaxis2,
                                                sizeof(float *));

        for( p = 0; p < AWAP_Comp->imgnaxis2; p++ )
          AWAP_Impix->uncdata[p] = (float *) calloc(AWAP_Comp->imgnaxis1,
                                                    sizeof(float));

        if( AWAP_Impix->uncdata == NULL ) {
          fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
                  "allocate memory for uncdata array.");
          AWAP_Stat->I_status = 1;
          return 0;
        }

        /* uncertainty data is stored as: uncdata[y_pix-1][x_pix-1] where
           y_pix = 1..naxis2; x_pix = 1..naxis1. */

        for(fimgpix[1] = 1; fimgpix[1] <= AWAP_Comp->imgnaxis2; fimgpix[1]++) {

          fits_read_pix(ffp_FITS_Unc, TFLOAT, fimgpix, AWAP_Comp->imgnaxis1,
                        NULL,AWAP_Impix->uncdata[fimgpix[1] - 1],NULL,&status);
          if( status ) {
            fprintf(stderr,"*** Error: awaicgen_comp_res_hires: error %s %s\n",
                    "storing pixel data from uncertainty image:",
                    AWAP_Fnames->Filename_FITS_Uncert[m]);
            AWAP_Stat->I_status = 1;
            return 0;
          }
        }

        fits_close_file(ffp_FITS_Unc, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_comp_res_hires: %s %s; %s %d\n",
                  "error closing FITS file:",
                  AWAP_Fnames->Filename_FITS_Uncert[m],
                  "FITS error code =", status);
          AWAP_Stat->I_status = 1;
          return 0;
        }
      }

      /*----------*/
      /* read/store pixel mask data (if specified) for detector image m
         in 2D dynamic array. Assumes good pixels have value 0; "bad" pixels
         have integer values > 0 up to integer +2^31. */

      if( AWAP_Const->have_masks ) {

        if( AWAP_Stat->I_Verbose )
          printf("awaicgen_comp_res_hires: reading/storing mask #%d: %s %s\n",
                 m+1, AWAP_Fnames->Filename_FITS_Mask[m],"...");

        fits_open_file(&ffp_FITS_Msk, AWAP_Fnames->Filename_FITS_Mask[m],
                       READONLY, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_comp_res_hires: %s %s; %s %d\n",
                  "error opening FITS file:",
                  AWAP_Fnames->Filename_FITS_Mask[m],
                  "FITS error code =", status);
          AWAP_Stat->I_status = 1;
          return 0;
        }

        AWAP_Impix->mskdata = (long **) calloc(AWAP_Comp->imgnaxis2,
                                               sizeof(long));

        for( p = 0; p < AWAP_Comp->imgnaxis2; p++ )
          AWAP_Impix->mskdata[p] = (long *) calloc(AWAP_Comp->imgnaxis1,
                                                   sizeof(long));

        if( AWAP_Impix->mskdata == NULL ) {
          fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
                  "allocate memory for mskdata array.");
          AWAP_Stat->I_status = 1;
          return 0;
        }

        /* mask data is stored as: mskdata[y_pix-1][x_pix-1] where
           y_pix = 1..naxis2; x_pix = 1..naxis1. */

        for(fimgpix[1] = 1; fimgpix[1] <= AWAP_Comp->imgnaxis2; fimgpix[1]++) {

          fits_read_pix(ffp_FITS_Msk, TLONG, fimgpix, AWAP_Comp->imgnaxis1,
                        NULL,AWAP_Impix->mskdata[fimgpix[1] - 1],NULL,&status);
          if( status ) {
            fprintf(stderr,"*** Error: awaicgen_comp_res_hires: error %s %s\n",
                    "storing pixel data from mask:",
                    AWAP_Fnames->Filename_FITS_Mask[m]);
            AWAP_Stat->I_status = 1;
            return 0;
          }
        }

        fits_close_file(ffp_FITS_Msk, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_comp_res_hires: %s %s; %s %d\n",
                  "error closing FITS file:",
                  AWAP_Fnames->Filename_FITS_Mask[m],
                  "FITS error code =", status);
          AWAP_Stat->I_status = 1;
          return 0;
        }
      }

      /*----------*/
      /* set-up the structure for the plane-to-plane WCS transform:
         image m to output mosaic cell grid. */

      wcsoutput = wcsinit(AWAP_Comp->outwcsheader);

      status = Initialize_TwoPlane_FirstDistort(&AWAP_Impix->twoplane,
                                                inheaderfits,
                                                wcsoutput);

      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
                "set-up plane-to-plane transform.");
        AWAP_Stat->I_status = 1;
        return 0;
      }

      wcsfree(wcsoutput);

      free(inheaderfits);

      /*----------*/
      /* compute rotation of image m in Cartesian frame of mosaic cell
         grid. This will be used for transorming PRF from a "rotated" detector
         frame pixel to cell grid. This is important for non-axisymmetric
         PRFs and Num_Iter > 1 coadds. Compute theta_m by first transforming
         two points along native dectector x-axis and then use atan2
         function. Don't care if offscale here since offscale pixels
         avoided below. Since this step involving theta_m is slow
         (in particular its usage in rotation matrix below), we can turn
         off this functionality by setting RotPRF_Flag = 0. */

      /* if RotPRF_Flag is "on", also add 180 degrees to PRF rotation, i.e.,
         this is equivalent to flipping PRF in x then y. This is to conform with
         the rules of convolution and is important if (i) HiRes'ing (n > 1)
         is being performed, and (ii) the input PRF(s) are highly asymmetric.
         No PRF flipping is performed for n=1 (co-add) since a
         cross-correlation with input data is desired, i.e., PRF is a
         matched filter optimized for detecting point sources. */

      AWAP_Impix->theta_m = 0;

      if( AWAP_Const->RotPRF_Flag ) {

        /* transform pixel (1, 1). */
        offscl = plane1_to_plane2_transform( 1, 1, &xmin_Cm, &ymin_Cm,
                                             &AWAP_Impix->twoplane );

        /* transform pixel (NAXIS1, 1). */
        offscl = plane1_to_plane2_transform( AWAP_Comp->imgnaxis1, 1,
                                             &xmax_Cm, &ymax_Cm,
                                             &AWAP_Impix->twoplane );

        /* image m rotation: -pi < theta < pi radians. */
        AWAP_Impix->theta_m = atan2((ymax_Cm - ymin_Cm), (xmax_Cm - xmin_Cm));

        /* also flip in x and y (+pi radians) only if HiRes is performed. */
        if( AWAP_Const->Num_Iter > 1 )
          AWAP_Impix->theta_m += (4.0 * atan2(1,1));

        if( AWAP_Stat->I_Debug )
          printf("awaicgen_comp_res_hires: image/prf rotation in %s = %f %s\n",
                 "mosaic frame", AWAP_Impix->theta_m*(180.0/(4.0*atan2(1,1))),
                 "degrees");
      }

      /*----------*/
      /* for each detector pixel (D_x, D_y) in image m, transform to
         mosaic cell grid frame =(CD_x, CD_y) using fast WCS projection.
         Then transform native PRF coords centered at this pixel to mosaic
         cell grid using linear transformation and round to nearest integer
         cell pixel. Beware that PRF is not transformed using full non-linear
         WCS transformation from input image to mosaic plane. For large
         mosaics, there could be an inaccurate representation of the PRF
         flux distribution towards mosaic edges. */

      if(AWAP_Stat->I_status)
        return 0;

      /* launch concurrent threads according to input pixel processing
         ranges defined above for image m. */

      for(t = 0; t < AWAP_Const->NumThreads; t++) {
        if( AWAP_Stat->I_Verbose )
          printf("awaicgen_comp_res_hires: creating thread %d...\n", t);

        hiresdata[t].threadid = t;
        hiresdata[t].twoplane = AWAP_Impix->twoplane;
        hiresdata[t].theta_m = AWAP_Impix->theta_m;
        hiresdata[t].mos_cell_array = AWAP_Impix->mos_cell_array;
        hiresdata[t].Cnum_j = AWAP_Impix->Cnum_j;
        hiresdata[t].NV_j = AWAP_Impix->NV_j;
        hiresdata[t].NSV_j = AWAP_Impix->NSV_j;
        hiresdata[t].N_j = AWAP_Impix->N_j;
        hiresdata[t].CFFV_j = AWAP_Impix->CFFV_j;
        hiresdata[t].imgdata = AWAP_Impix->imgdata;
        hiresdata[t].uncdata = AWAP_Impix->uncdata;
        hiresdata[t].mskdata = AWAP_Impix->mskdata;

        if( pthread_create(&thread[t], NULL, (void *)awaicgen_compute_hirespix,
                           &hiresdata[t]) ) {
          fprintf(stderr,"*** Error: awaicgen_comp_res_hires: %s %d; %s\n",
                  "problem creating thread", t, "quitting...");
          AWAP_Stat->I_status = 1;
          return 0;
        }
      }

      /* wait for threads to finish */

      for(t = 0; t < AWAP_Const->NumThreads; t++) {
        if( pthread_join(thread[t], NULL) ) {
          fprintf(stderr,"*** Error: awaicgen_comp_res_hires: %s %d; %s\n",
                  "problem completing (pthread_join'ing) thread", t,
                  "quitting...");
          AWAP_Stat->I_status = 1;
          return 0;

        } else {
          if( AWAP_Stat->I_Verbose )
            printf("awaicgen_comp_res_hires: thread %d run of %s finished.\n", t,
                   "\'awaicgen_compute_hirespix\'");
        }
      }

      /* Combine some parameter outputs that depend on entire input image
         being processed by all threads. */

      chisq_m = 0.;
      NumGoodD_i = 0;

      for(t = 0; t < AWAP_Const->NumThreads; t++) {
        if( hiresdata[t].ProjectionStatus )
          ProjectionStatus = 1;

        if( AWAP_Const->have_uncert ) {
          chisq_m += hiresdata[t].chisq_m;
          NumGoodD_i += hiresdata[t].NumGoodD_i;
        }
      }

      /*----------*/
      /* report value of reduced chi-square for image m to stdout.
         NB: 1 input image => doesn't really converge to 1 with Niter
         since F_i -> D_i, i.e., process tries to fit the noise
         and we get chisq < 1. But change in chisq -> 0 as Niter
         increases. If F_i = average from a stack, then chisq -> ~1. */

      if( AWAP_Const->have_uncert ) {

        chisq_m /= NumGoodD_i;

        printf("awaicgen_comp_res_hires: reduced chi-square %s #%d %s %d = %f\n",
               "for image", m+1, "after iteration", iter, chisq_m);
      }

      /*----------*/
      /* free memory in 2D pixel data array for image m. */

      for( p = 0; p < AWAP_Comp->imgnaxis2; p++ )
        free( AWAP_Impix->imgdata[p] );

      free( AWAP_Impix->imgdata );

      /*----------*/
      /* free memory in 2D pixel mask array for image m if masks
         were specified. */

      if( AWAP_Const->have_masks ) {

        for( p = 0; p < AWAP_Comp->imgnaxis2; p++ )
          free( AWAP_Impix->mskdata[p] );

        free( AWAP_Impix->mskdata );
      }

      /*----------*/
      /* free memory in 2D pixel uncertainty array for image m if
         uncertainty images were specified. */

      if( AWAP_Const->have_uncert ) {

        for( p = 0; p < AWAP_Comp->imgnaxis2; p++ )
          free( AWAP_Impix->uncdata[p] );

        free( AWAP_Impix->uncdata );
      }

    }  /* end of loop for detector image m. */

    /*----------*/
    /* compute the PRF and inverse variance weighted average correction
       factor array <C_j> per cell pixel j, and update the (corrected)
       flux: f_j = f_j * <C_j>. Also compute the output uncertainty for
       cell pixel j => only valid for Num_Iter = 1, the mean correction
       factor CF_j, and the data-derived estimate for the 1-sigma uncertainty
       in f_j from the Correction Factor Variance if warranted. */

    for( jj = 0; jj < AWAP_Comp->cellnaxis2; jj++ ) {
      for( j = 0; j < AWAP_Comp->cellnaxis1; j++ ) {

        C_j = AWAP_Impix->Cnum_j[jj][j] / AWAP_Impix->NV_j[jj][j];

        if( AWAP_Const->want_cffv ) {

          CS_j = AWAP_Impix->CFFV_j[jj][j] / AWAP_Impix->NV_j[jj][j];

          CFV_j = CS_j - (C_j * C_j);

          if( CFV_j < 0.0 )
            CFV_j = 0.0;

          /* Compute percentage difference between "real" CFV from previous
             iteration and current CFV at this cell pixel for purposes of
             suppressing noise amplification with spatially dependent
             MCM convergence. I.e., halt iterations "earlier" at "pure"
             noise dominated pixels. Reset C_j to 1 if not previously 1
             and if pctdiff in CFV from iter n -> n+1 is < some threshold. */

          if( AWAP_Const->want_corr ) {

            if( (iter > 1) && (CF_j[jj][j] != 1.0) ) {

              CFV_jpctdiff = 100.0 * fabs((CFVo_j[jj][j] - CFV_j) /
                                           CFVo_j[jj][j]);

              /*
              if(j==198 && jj==1100)
                printf("DBG %12.7f; %12.7f; %12.7f; %12.7f; %12.7f\n",
                       CF_j[jj][j], C_j, CFVo_j[jj][j], CFV_j, CFV_jpctdiff);
              */

              if( CFV_jpctdiff < AWAP_Const->CFVpctdiff ) {
                C_j = 1.0;
                NlastIter_j[jj][j] = iter - 1;
              }
            }
          }

          /* Store current value of CFV so can use as "previous" value in
             next MCM iteration for CFV_jpctdiff. Also written to cell FITS
             image for this iteration below. */

          CFVo_j[jj][j] = CFV_j;
        }

        /* If previous CF_j[jj][j] already 1, force current C_j to 1 to
           avoid updating hires'd image arrays further. */

        if( AWAP_Const->want_corr ) {

          if( (iter > 1) && (CF_j[jj][j] == 1.0) )
            C_j = 1.0;

          CF_j[jj][j] = C_j;
        }

        /* Actual data-derived 1-sigma flux uncertainty from CFV to write
           to final downsampled output FITS images. */

        if( AWAP_Const->want_cffv )
          CFFVo_j[jj][j] = AWAP_Impix->mos_cell_array[jj][j] *
                           sqrt( CFV_j / AWAP_Impix->N_j[jj][j] );

        AWAP_Impix->mos_cell_array[jj][j] = AWAP_Impix->mos_cell_array[jj][j] *
                                            C_j;

        sig_cell_array[jj][j] = sqrt(AWAP_Impix->NSV_j[jj][j]) /
                                AWAP_Impix->NV_j[jj][j];

        /* If on first iteration, optionally save the intensities to a
           separate cell array for writing out to downsampled FITS image. */

        if( strcmp(AWAP_Fnames->Filename_Output_MosaicFIter,"") &&
            (AWAP_Const->Num_Iter > 1) &&
            (iter == 1 ) )
          fitr_cell_array[jj][j] = AWAP_Impix->mos_cell_array[jj][j];
      }
    }

    /*----------*/
    /* If output base filename specified (-o7), write mos_cell_array[jj][j]
       array to FITS file. Really for diagnostic purposes and optional
       input for further MCM iterations on subsequent re-runs of AWAIC
       (i.e., starting model img). Note: This image contains no WCS
       keywords. Output FITS filename will be:
       <Filename_Output_MosaicCell>_iter. */

    if( strcmp(AWAP_Fnames->Filename_Output_MosaicCell,"") ) {

      awaicgen_write_mcmimg(AWAP_Impix->mos_cell_array,
                         iter,
                         AWAP_Comp,
                         AWAP_Fnames,
                         AWAP_Stat);

      if(AWAP_Stat->I_status)
        return 0;
    }

    /*----------*/
    /* If output base filename specified (-o8), write values of CFV_j
       to FITS file. Really for qualitative diagnostic purposes. This image
       contains no WCS keywords. Output FITS filename will be:
       <Filename_Output_MosaicCFV>_iter. */

    if( strcmp(AWAP_Fnames->Filename_Output_MosaicCFV,"") &&
        AWAP_Const->want_cffv ) {

      awaicgen_write_mcmcfv(CFVo_j,
                         iter,
                         AWAP_Comp,
                         AWAP_Fnames,
                         AWAP_Stat);

      if(AWAP_Stat->I_status)
        return 0;
    }

    /*----------*/
    /* If output base filename specified (-o9), write values of CF_j (corr
       factors in cell grid) to FITS file. Really for qualitative diagnostic
       purposes. This image contains no WCS keywords. Output FITS filename
       will be: <Filename_Output_MosaicCOR>_iter. */

    if( strcmp(AWAP_Fnames->Filename_Output_MosaicCOR,"") ) {

      awaicgen_write_mcmcf(CF_j,
                        iter,
                        AWAP_Comp,
                        AWAP_Fnames,
                        AWAP_Stat);

      if(AWAP_Stat->I_status)
        return 0;
    }

  }  /* end of loop for MCM iteration # "iter". */


/*----------------------------------------------------------------------*/
/* If warranted and if output base filename specified (-oi), write values
   of position-dependent last-iteration image. Contains no WCS keywords. */

  if( AWAP_Const->want_cffv && AWAP_Const->want_corr ) {

    if( strcmp(AWAP_Fnames->Filename_Output_MosaicIter,"") ) {

      awaicgen_write_mcmiter(NlastIter_j,
                          AWAP_Comp,
                          AWAP_Fnames,
                          AWAP_Stat);

      if(AWAP_Stat->I_status)
        return 0;
    }
  }


/*----------------------------------------------------------------------*/
/* Check projection status flag to ensure some of the input pixels
   were projected. If not, abort with error message. */

  if( !ProjectionStatus ) {

    fprintf(stderr,"*** Error: awaicgen_comp_res_hires: %s; %s\n",
            "none of the input pixels fell onto the WCS grid",
            "quitting...");
    AWAP_Stat->I_status = 1;
    return 0;
  }


/*----------------------------------------------------------------------*/
/* Free some undesired memory. */

  free( AWAP_Fnames->Filename_FITS_Image );

  if( AWAP_Const->have_uncert )
    free( AWAP_Fnames->Filename_FITS_Uncert );

  if( AWAP_Const->have_masks )
    free( AWAP_Fnames->Filename_FITS_Mask );

  free( AWAP_Comp->outwcsheader );

  free( AWAP_Comp->xprf );

  free( AWAP_Comp->yprf );

  for( i = 0; i < AWAP_Comp->numprfs; i++ )
    free( AWAP_Comp->prfdata[i] );

  free( AWAP_Comp->prfdata );

  for( i = 0; i < AWAP_Comp->prfgriddim; i++ )
    free( AWAP_Comp->prflistind[i] );

  free( AWAP_Comp->prflistind );

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ )
    free( AWAP_Impix->Cnum_j[i] );

  free( AWAP_Impix->Cnum_j );

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ )
    free( AWAP_Impix->NSV_j[i] );

  free( AWAP_Impix->NSV_j );

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ )
    free( AWAP_Impix->NV_j[i] );

  free( AWAP_Impix->NV_j );

  if( AWAP_Const->want_cffv ) {
    for( i = 0; i < AWAP_Comp->cellnaxis2; i++ )
      free( AWAP_Impix->CFFV_j[i] );

    free( AWAP_Impix->CFFV_j );

    for( i = 0; i < AWAP_Comp->cellnaxis2; i++ )
      free( CFVo_j[i] );

    free( CFVo_j );
  }

  if( AWAP_Const->want_cffv && AWAP_Const->want_corr ) {

    for( i = 0; i < AWAP_Comp->cellnaxis2; i++ )
      free( NlastIter_j[i] );

    free( NlastIter_j );
  }


/*----------------------------------------------------------------------*/
/* Allocate memory to final output mosaic product arrays. */

  /*----------*/
  /* Actual real output mosaic grid sampled at pixel size:
     Mosaic_PixFact * inp_image_CDELT or simply Mosaic_PixScal: */

  AWAP_Comp->mos_pix_array = (float **) calloc(AWAP_Comp->mosnaxis2,
                                               sizeof(float *));

  if( AWAP_Comp->mos_pix_array == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not allocate %s\n",
            "memory for mos_pix_array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_comp_res_hires: allocated %f MB for %s\n",
            (AWAP_Comp->mosnaxis1*AWAP_Comp->mosnaxis2*
             sizeof(float)/1.0E+06),
             "output mosaic pixel array.");
    }
  }

  for( i = 0; i < AWAP_Comp->mosnaxis2; i++ ) {

    AWAP_Comp->mos_pix_array[i] = (float *) calloc(AWAP_Comp->mosnaxis1,
                                                   sizeof(float));

    if( AWAP_Comp->mos_pix_array[i] == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
              "allocate memory for mos_pix_array.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  /*----------*/
  /* Output mosaic coverage map at mosaic pixel scale: */

  AWAP_Comp->mos_cov_array = (float **) calloc(AWAP_Comp->mosnaxis2,
                                               sizeof(float *));

  if( AWAP_Comp->mos_cov_array == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not allocate %s\n",
            "memory for mos_cov_array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_comp_res_hires: allocated %f MB for %s\n",
            (AWAP_Comp->mosnaxis1*AWAP_Comp->mosnaxis2*
             sizeof(float)/1.0E+06),
             "output mosaic coverage array.");
    }
  }

  for( i = 0; i < AWAP_Comp->mosnaxis2; i++ ) {

    AWAP_Comp->mos_cov_array[i] = (float *) calloc(AWAP_Comp->mosnaxis1,
                                                   sizeof(float));

    if( AWAP_Comp->mos_cov_array[i] == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
              "allocate memory for mos_cov_array.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  /*----------*/
  /* Optional output uncertainty image at mosaic pixel scale. This
     output product only makes sense for Num_Iter = 1 mosaic. */

  if( strcmp(AWAP_Fnames->Filename_Output_Uncert,"") ) {

    AWAP_Comp->mos_sig_array = (float **) calloc(AWAP_Comp->mosnaxis2,
                                                 sizeof(float *));

    if( AWAP_Comp->mos_sig_array == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
              "allocate memory for mos_sig_array.");
      AWAP_Stat->I_status = 1;
      return 0;

    } else {

      if( AWAP_Stat->I_Verbose ) {
        printf("awaicgen_comp_res_hires: allocated %f MB for %s\n",
              (AWAP_Comp->mosnaxis1*AWAP_Comp->mosnaxis2*
               sizeof(float)/1.0E+06),
               "output uncert. image array.");
      }
    }

    for( i = 0; i < AWAP_Comp->mosnaxis2; i++ ) {

      AWAP_Comp->mos_sig_array[i] = (float *) calloc(AWAP_Comp->mosnaxis1,
                                                     sizeof(float));

      if( AWAP_Comp->mos_sig_array[i] == NULL ) {
        fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
                "allocate memory for mos_sig_array.");
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }
  }

  /*----------*/
  /* Optional output MCM correction-factor image at mosaic pixel scale.
     Only generated if output filename specified. */

  if( AWAP_Const->want_corr ) {

    AWAP_Comp->mos_cor_array = (float **) calloc(AWAP_Comp->mosnaxis2,
                                                 sizeof(float *));

    if( AWAP_Comp->mos_cor_array == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
              "allocate memory for mos_cor_array.");
      AWAP_Stat->I_status = 1;
      return 0;

    } else {

      if( AWAP_Stat->I_Verbose ) {
        printf("awaicgen_comp_res_hires: allocated %f MB for %s\n",
              (AWAP_Comp->mosnaxis1*AWAP_Comp->mosnaxis2*
               sizeof(float)/1.0E+06),
               "output correction-factor image array.");
      }
    }

    for( i = 0; i < AWAP_Comp->mosnaxis2; i++ ) {

      AWAP_Comp->mos_cor_array[i] = (float *) calloc(AWAP_Comp->mosnaxis1,
                                                     sizeof(float));

      if( AWAP_Comp->mos_cor_array[i] == NULL ) {
        fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
                "allocate memory for mos_cor_array.");
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }
  }

  /*----------*/
  /* Optional output data-derived MCM uncertainty image (from CFV) at mosaic
     pixel scale. Only generated if output filename specified. */

  if( AWAP_Const->want_cffv ) {

    AWAP_Comp->mos_cfv_array = (float **) calloc(AWAP_Comp->mosnaxis2,
                                                 sizeof(float *));

    if( AWAP_Comp->mos_cfv_array == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
              "allocate memory for mos_cfv_array.");
      AWAP_Stat->I_status = 1;
      return 0;

    } else {

      if( AWAP_Stat->I_Verbose ) {
        printf("awaicgen_comp_res_hires: allocated %f MB for %s\n",
              (AWAP_Comp->mosnaxis1*AWAP_Comp->mosnaxis2*
               sizeof(float)/1.0E+06),
               "output data-derived MCM uncert array.");
      }
    }

    for( i = 0; i < AWAP_Comp->mosnaxis2; i++ ) {

      AWAP_Comp->mos_cfv_array[i] = (float *) calloc(AWAP_Comp->mosnaxis1,
                                                     sizeof(float));

      if( AWAP_Comp->mos_cfv_array[i] == NULL ) {
        fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
                "allocate memory for mos_cfv_array.");
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }
  }

  /*----------*/
  /* Optional first MCM iteration intensity mosaic at mosaic pixel scale.
     Only generated if output filename specified and Num_Iter > 1. */

  if( strcmp(AWAP_Fnames->Filename_Output_MosaicFIter,"") &&
      (AWAP_Const->Num_Iter > 1) ) {

    AWAP_Comp->mos_fitr_array = (float **) calloc(AWAP_Comp->mosnaxis2,
                                                  sizeof(float *));

    if( AWAP_Comp->mos_fitr_array == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
              "allocate memory for mos_fitr_array.");
      AWAP_Stat->I_status = 1;
      return 0;

    } else {

      if( AWAP_Stat->I_Verbose ) {
        printf("awaicgen_comp_res_hires: allocated %f MB for %s\n",
              (AWAP_Comp->mosnaxis1*AWAP_Comp->mosnaxis2*
               sizeof(float)/1.0E+06),
               "output first MCM iteration intensity array.");
      }
    }

    for( i = 0; i < AWAP_Comp->mosnaxis2; i++ ) {

      AWAP_Comp->mos_fitr_array[i] = (float *) calloc(AWAP_Comp->mosnaxis1,
                                                      sizeof(float));

      if( AWAP_Comp->mos_fitr_array[i] == NULL ) {
        fprintf(stderr,"*** Error: awaicgen_comp_res_hires: could not %s\n",
                "allocate memory for mos_fitr_array.");
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }
  }


/*----------------------------------------------------------------------*/
/* Set-up for downsampling and re-sizing of cell-grid arrays. */

  x_scl = (int)((AWAP_Comp->moscdelt1/AWAP_Comp->cellcdelt1) + 0.5);

  y_scl = (int)((AWAP_Comp->moscdelt2/AWAP_Comp->cellcdelt2) + 0.5);

  xj_min = (long)((double)(0.5 * (AWAP_Comp->cellnaxis1 - (x_scl *
                                  AWAP_Comp->mosnaxis1))));

  yj_min = (long)((double)(0.5 * (AWAP_Comp->cellnaxis2 - (y_scl *
                                  AWAP_Comp->mosnaxis2))));

  outin_area_ratio = (AWAP_Comp->moscdelt1 * AWAP_Comp->moscdelt2) /
                     (AWAP_Comp->imgcdelt1 * AWAP_Comp->imgcdelt2);


/*----------------------------------------------------------------------*/
/* Downsample/re-size the cell grid mosaic array to desired pixel-scale
   and size. */

  if( AWAP_Stat->I_Verbose )
    printf("awaicgen_comp_res_hires: down-sampling/re-sizing %s\n",
           "intensity-mosaic cell array...");

  for( ii = 0; ii < AWAP_Comp->mosnaxis2; ii++ ) {
    for( i = 0; i < AWAP_Comp->mosnaxis1; i++ ) {

      AWAP_Comp->mos_pix_array[ii][i] = 0.0;

      for( jj = (yj_min + y_scl*ii); jj < (yj_min + y_scl*(ii + 1)); jj++ )
        for( j = (xj_min + x_scl*i); j < (xj_min + x_scl*(i + 1)); j++ )
          AWAP_Comp->mos_pix_array[ii][i] += AWAP_Impix->mos_cell_array[jj][j];

      /* Down-scale flux according to cell versus output pixel area. */

      AWAP_Comp->mos_pix_array[ii][i] /= (x_scl * y_scl);

      /* If warranted, scale flux according to input vs. output pixel area. */

      if( AWAP_Const->Flxscal_Flag )
        AWAP_Comp->mos_pix_array[ii][i] *= outin_area_ratio;

      /*
      printf("DBG:(%d,%d) %20.15f\n",i+1,ii+1,AWAP_Comp->mos_pix_array[ii][i]);
      */
    }
  }


/*----------------------------------------------------------------------*/
/* Downsample/re-size the cell grid coverage array to desired pixel-scale
   and size. */

  if( AWAP_Stat->I_Verbose )
    printf("awaicgen_comp_res_hires: down-sampling/re-sizing %s\n",
           "coverage cell array...");

  for( ii = 0; ii < AWAP_Comp->mosnaxis2; ii++ ) {
    for( i = 0; i < AWAP_Comp->mosnaxis1; i++ ) {

      AWAP_Comp->mos_cov_array[ii][i] = 0.0;

      for( jj = (yj_min + y_scl*ii); jj < (yj_min + y_scl*(ii + 1)); jj++ )
        for( j = (xj_min + x_scl*i); j < (xj_min + x_scl*(i + 1)); j++ )
          AWAP_Comp->mos_cov_array[ii][i] += AWAP_Impix->N_j[jj][j];

      /* Re-scale coverage according to input versus output pixel area. */

      AWAP_Comp->mos_cov_array[ii][i] /= outin_area_ratio;

      /*
      printf("DBG:(%d,%d) %20.15f\n",i+1,ii+1,AWAP_Comp->mos_cov_array[ii][i]);
      */
    }
  }


/*----------------------------------------------------------------------*/
/* Downsample/re-size the cell grid Num_Iter = 1 intensity image to desired
   pixel-scale and size. Only generate if output filename specified and in
   in MCM/HiRes mode: Num_Iter > 1. Note: this product is equivalent to -o1
   image output if input Num_Iter = 1. */

  if( strcmp(AWAP_Fnames->Filename_Output_MosaicFIter,"") &&
      (AWAP_Const->Num_Iter > 1) ) {

    if( AWAP_Stat->I_Verbose )
      printf("awaicgen_comp_res_hires: down-sampling/re-sizing %s\n",
             "intensity-mosaic cell array for first MCM iteration...");

    for( ii = 0; ii < AWAP_Comp->mosnaxis2; ii++ ) {
      for( i = 0; i < AWAP_Comp->mosnaxis1; i++ ) {

        AWAP_Comp->mos_fitr_array[ii][i] = 0.0;

        for( jj = (yj_min + y_scl*ii); jj < (yj_min + y_scl*(ii + 1)); jj++ )
          for( j = (xj_min + x_scl*i); j < (xj_min + x_scl*(i + 1)); j++ )
            AWAP_Comp->mos_fitr_array[ii][i] += fitr_cell_array[jj][j];

        /* Down-scale sigma according to cell versus output pixel area. */

        AWAP_Comp->mos_fitr_array[ii][i] /= (x_scl * y_scl);

        /* If warranted, scale sigma according to inp vs. out pixel area. */

        if( AWAP_Const->Flxscal_Flag )
          AWAP_Comp->mos_fitr_array[ii][i] *= outin_area_ratio;

        /*
        printf("DBG:(%d,%d) %20.15f\n",i+1,ii+1,
               AWAP_Comp->mos_fitr_array[ii][i]);
        */
      }
    }
  }


/*----------------------------------------------------------------------*/
/* Downsample/re-size the cell grid uncertainty array to desired pixel-scale
   and size. Only generate if output uncertainty filename specified. Also,
   this product only makes sense for a Num_Iter = 1 mosaic. */

  if( strcmp(AWAP_Fnames->Filename_Output_Uncert,"") ) {

    if( AWAP_Stat->I_Verbose )
      printf("awaicgen_comp_res_hires: down-sampling/re-sizing %s\n",
             "mosaic-uncertainty (Num_Iter=1) cell array...");

    for( ii = 0; ii < AWAP_Comp->mosnaxis2; ii++ ) {
      for( i = 0; i < AWAP_Comp->mosnaxis1; i++ ) {

        AWAP_Comp->mos_sig_array[ii][i] = 0.0;

        for( jj = (yj_min + y_scl*ii); jj < (yj_min + y_scl*(ii + 1)); jj++ )
          for( j = (xj_min + x_scl*i); j < (xj_min + x_scl*(i + 1)); j++ )
            AWAP_Comp->mos_sig_array[ii][i] += sig_cell_array[jj][j];

        /* Down-scale sigma according to cell versus output pixel area. */

        AWAP_Comp->mos_sig_array[ii][i] /= (x_scl * y_scl);

        /* If warranted, scale sigma according to inp vs. out pixel area. */

        if( AWAP_Const->Flxscal_Flag )
          AWAP_Comp->mos_sig_array[ii][i] *= outin_area_ratio;

        /*
        printf("DBG:(%d,%d) %20.15f\n",i+1,ii+1,
               AWAP_Comp->mos_sig_array[ii][i]);
        */
      }
    }
  }


/*----------------------------------------------------------------------*/
/* Downsample/re-size the MCM correction-factor array to desired pixel-scale
   and size. Only generate if output filename specified. */

  if( AWAP_Const->want_corr ) {

    if( AWAP_Stat->I_Verbose )
      printf("awaicgen_comp_res_hires: down-sampling/re-sizing %s\n",
             "MCM correction-factor cell array...");

    for( ii = 0; ii < AWAP_Comp->mosnaxis2; ii++ ) {
      for( i = 0; i < AWAP_Comp->mosnaxis1; i++ ) {

        AWAP_Comp->mos_cor_array[ii][i] = 0.0;

        for( jj = (yj_min + y_scl*ii); jj < (yj_min + y_scl*(ii + 1)); jj++ )
          for( j = (xj_min + x_scl*i); j < (xj_min + x_scl*(i + 1)); j++ )
            AWAP_Comp->mos_cor_array[ii][i] += CF_j[jj][j];

        /* Down-scale according to cell versus output pixel area. */

        AWAP_Comp->mos_cor_array[ii][i] /= (x_scl * y_scl);

        /*
        printf("DBG:(%d,%d) %20.15f\n",i+1,ii+1,
               AWAP_Comp->mos_cor_array[ii][i]);
        */
      }
    }
  }


/*----------------------------------------------------------------------*/
/* Downsample/re-size the MCM uncertainty array (from CFV) to desired
   pixel-scale and size. Only generate if output filename specified. */

  if( AWAP_Const->want_cffv ) {

    if( AWAP_Stat->I_Verbose )
      printf("awaicgen_comp_res_hires: down-sampling/re-sizing %s\n",
             "MCM uncertainty cell array...");

    for( ii = 0; ii < AWAP_Comp->mosnaxis2; ii++ ) {
      for( i = 0; i < AWAP_Comp->mosnaxis1; i++ ) {

        AWAP_Comp->mos_cfv_array[ii][i] = 0.0;

        for( jj = (yj_min + y_scl*ii); jj < (yj_min + y_scl*(ii + 1)); jj++ )
          for( j = (xj_min + x_scl*i); j < (xj_min + x_scl*(i + 1)); j++ )
            AWAP_Comp->mos_cfv_array[ii][i] += CFFVo_j[jj][j];

        /* Down-scale according to cell versus output pixel area. */

        AWAP_Comp->mos_cfv_array[ii][i] /= (x_scl * y_scl);

        /* Rescale due to the sqrt(CFV_j) that appears in the CFFVo_j[jj][j]
           equation since it applies to the cell-grid. */

        AWAP_Comp->mos_cfv_array[ii][i] /= sqrt(x_scl * y_scl);

        /* Rescale due to the sqrt(1/N_j) that appears in the CFFVo_j[jj][j]
           equation since it applies to the cell-grid. */

        AWAP_Comp->mos_cfv_array[ii][i] *= sqrt(outin_area_ratio);

        /* If warranted, scale according to inp vs. out pixel area. */

        if( AWAP_Const->Flxscal_Flag )
          AWAP_Comp->mos_cfv_array[ii][i] *= outin_area_ratio;

        /*
        printf("DBG:(%d,%d) %20.15f\n",i+1,ii+1,
               AWAP_Comp->mos_cfv_array[ii][i]);
        */
      }
    }
  }


/*----------------------------------------------------------------------*/
/* Free undesired memory. */

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ )
    free( AWAP_Impix->mos_cell_array[i] );

  free( AWAP_Impix->mos_cell_array );

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ )
    free( sig_cell_array[i] );

  free( sig_cell_array );

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ )
    free( AWAP_Impix->N_j[i] );

  free( AWAP_Impix->N_j );

  if( AWAP_Const->want_corr ) {
    for( i = 0; i < AWAP_Comp->cellnaxis2; i++ )
      free( CF_j[i] );

    free( CF_j );
  }

  if( AWAP_Const->want_cffv ) {
    for( i = 0; i < AWAP_Comp->cellnaxis2; i++ )
      free( CFFVo_j[i] );

    free( CFFVo_j );
  }

  if( strcmp(AWAP_Fnames->Filename_Output_MosaicFIter,"") &&
      (AWAP_Const->Num_Iter > 1) ) {
    for( i = 0; i < AWAP_Comp->cellnaxis2; i++ )
      free( fitr_cell_array[i] );

    free( fitr_cell_array );
  }

  return 0;
}
