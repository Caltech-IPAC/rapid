
/*********************************************** 
awaicgen.c

Overview

Program executive: calls initialization functions, main 
loop of program and output functions.

Dependencies (in execution order, [] are conditional).
  awaicgen.h
  awaicgen_defs.h
  awaicgen_synopsis.c
  awaicgen_init_constants.c
  awaicgen_parse_args.c
  awaicgen_store_img_fnames.c
  awaicgen_store_PRFs.c
  awaicgen_output_wcs.c
  [awaicgen_compute_results_simple.c]
     awaicgen_compute_simpcoadd.c
     awaicgen_overlap_area.c
  [awaicgen_compute_results.c]
     awaicgen_compute_prfcoadd.c
  [awaicgen_compute_results_hires.c]
     awaicgen_tophat_prior.c
     awaicgen_compute_hirespix.c
     awaicgen_write_mcmcf.c
     awaicgen_write_mcmcfv.c
     awaicgen_write_mcmimg.c
     awaicgen_write_mcmiter.c
  awaicgen_output.c
  awaicgen_log_writer.c

***********************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include "awaicgen.h"
#include "awaicgen_defs.h"

int main(int argc, char **argv)
{
  AWA_Constants		AWA_Const;
  AWA_Filenames		AWA_Fnames;
  AWA_Computation	AWA_Comp;
  AWA_Status		AWA_Stat;
  AWA_Impix             AWA_Impix;

  clock();


/* Program synopsis if executed with no command-line args. */

  awaicgen_synopsis( argc, argv, &AWA_Stat );

  if (AWA_Stat.I_status == 1) exit(0);


/* Set constants and default values in case not specified below. */

  awaicgen_init_constants( &AWA_Const, &AWA_Fnames, &AWA_Stat );


/* Parse the command line, replacing default values if specified. */

  awaicgen_parse_args( argc, argv, &AWA_Const, &AWA_Fnames, &AWA_Stat );


/* Store the input detector image, uncertainty and mask _filenames_ */

  awaicgen_store_img_fnames( &AWA_Const, &AWA_Fnames, &AWA_Comp, &AWA_Stat );


/* Store the input PRF pixel data, locations on FPA and sanity check. */

  awaicgen_store_PRFs( &AWA_Const, &AWA_Fnames, &AWA_Comp, &AWA_Stat );


/* Set up the output mosaic WCS structure for the fast projection. */

  awaicgen_output_wcs( &AWA_Const, &AWA_Comp, &AWA_Stat );


/* Main computational loops: request either a simple (area-weighted)
   co-add, a PRF interpolated co-add (-n = 1) with/without PRF pixel
   area-weighted interp or with/without rotation, or, a HiRes'd
   co-add (-n > 1). */

  if( AWA_Const.Simple_Flag ) {
    awaicgen_compute_results_simple(&AWA_Const,&AWA_Fnames,&AWA_Comp,
                                 &AWA_Impix,&AWA_Stat);

  } else if( !(AWA_Const.Simple_Flag) && 
              (AWA_Const.Num_Iter == 1) &&
              (AWA_Const.Interp_Method == 0) &&
             !(AWA_Const.want_corr) &&
             !(AWA_Const.want_cffv) ) {
    awaicgen_compute_results(&AWA_Const,&AWA_Fnames,&AWA_Comp,
                          &AWA_Impix,&AWA_Stat);

  } else if( (!(AWA_Const.Simple_Flag) &&
               (AWA_Const.Num_Iter > 1)) ||
              ((AWA_Const.Num_Iter == 1) &&
               (AWA_Const.Interp_Method == 1)) ||
              ((AWA_Const.Num_Iter == 1) &&
               (AWA_Const.RotPRF_Flag == 1)) ||
               (AWA_Const.want_corr) ||
               (AWA_Const.want_cffv) ) {
    awaicgen_compute_results_hires(&AWA_Const,&AWA_Fnames,&AWA_Comp,
                                &AWA_Impix,&AWA_Stat); 

  } else {
    AWA_Stat.I_status = 1;
  }


/* Write results to output file. */

  awaicgen_output( &AWA_Const, &AWA_Fnames, &AWA_Comp, &AWA_Impix, &AWA_Stat );


/* Summarize inputs/outputs, status, timing to standard output. */

  awaicgen_log_writer( argc, &AWA_Const, &AWA_Stat, &AWA_Fnames );


/* Send return value. */

  exit( AWA_Stat.I_status );

}
