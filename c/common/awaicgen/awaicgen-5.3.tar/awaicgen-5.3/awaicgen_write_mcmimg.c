
/***********************************************
awaicgen_write_mcmimg.c

Purpose

Write out 2D array: mos_cell_array to FITS format
following the Nth MCM iteration "iter". Iteration
number is appended to input base filename.

This image is really for diagnostic purposes and
optional input for further MCM iterations on subsequent
re-runs of AWAIC (i.e., starting model img). Note: This
image contains no WCS keywords.

***********************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "awaicgen.h"
#include "awaicgen_defs.h"
#include "fitsio.h"

int awaicgen_write_mcmimg(float             **mos_cell_array,
                   int               iter,
                   AWA_Computation   *AWAP_Comp,
                   AWA_Filenames     *AWAP_Fnames,
                   AWA_Status        *AWAP_Stat)
{
  char     iter_str[20];
  char     outfitsname[STRING_BUFFER_SIZE];
  long     fimgpix[2], naxis, naxes[2];
  int      status=0;

  fitsfile *ffp_FITS_Out;


  if(AWAP_Stat->I_status)
    return 0;

/*----------------------------------------------------------------------*/
/* Construct output FITS filename from "iter" and input basename. */

  sprintf(iter_str, "_iter%d", iter);
  strcpy(outfitsname, AWAP_Fnames->Filename_Output_MosaicCell);
  strcat(outfitsname, iter_str);


/*----------------------------------------------------------------------*/
/* Generate FITS image. */

  naxis = 2;
  naxes[0] = AWAP_Comp->cellnaxis1;
  naxes[1] = AWAP_Comp->cellnaxis2;
  fimgpix[0] = 1;
  fimgpix[1] = 1;

  if( AWAP_Stat->I_Verbose )
    printf("awaicgen_write_mcmimg: creating/writing FITS file %s: %s %s\n",
           "for output mosaic in cell grid frame", outfitsname, "...");

  fits_create_file(&ffp_FITS_Out, outfitsname, &status);

  if( status ) {
    fprintf(stderr,"*** Error: awaicgen_write_mcmimg: error %s %s; %s %d\n",
            "creating FITS file:", outfitsname, "FITS error code =", status);
    AWAP_Stat->I_status = 1;
    return 0;
  }

  fits_create_img(ffp_FITS_Out, FLOAT_IMG, naxis, naxes, &status);

  if( status ) {
    fprintf(stderr,"*** Error: awaicgen_write_mcmimg: error %s %s; %s %d\n",
            "creating FITS file image:", outfitsname, "FITS error code =",
            status);
    AWAP_Stat->I_status = 1;
    return 0;
  }

  for(fimgpix[1] = 1; fimgpix[1] <= naxes[1]; fimgpix[1]++) {

    fits_write_pix(ffp_FITS_Out, TFLOAT, fimgpix, naxes[0],
                   mos_cell_array[fimgpix[1] - 1], &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_write_mcmimg: error %s %s; %s %d\n",
              "writing pixels to:", outfitsname, "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  fits_close_file(ffp_FITS_Out, &status);

  if( status ) {
    fprintf(stderr,"*** Error: awaicgen_write_mcmimg: error %s %s; %s %d\n",
            "closing FITS file:", outfitsname, "FITS error code =", status);
    AWAP_Stat->I_status = 1;
    return 0;
  }

  return 0;
}
