
/***********************************************
awaicgen_store_PRFs.c

Purpose

Read and store the PRF pixel data from the input list
of PRF FITS images. Also store the x and y FPA locations
of each characteristic PRF if more than one PRF was
listed.

The above is only performed if no simple (area-weighted)
co-add was requested (-sc 0).

Input PRF postage stamp FITS images are expected to be
sampled at the mosaic sub-pixel (cell) scale:
Mosaic_PixFact * Mosaic_CellFact * inp_image_CDELT;
  or
Mosaic_PixScal * Mosaic_CellFact;
This is checked for below.

All input PRF images are expected to have same size,
i.e., NAXIS1,2 the same. This is not checked.

The number of input PRFs (in the input list) is
expected to be a perfect square, e.g., 1, 4, 9, 16...
If this is not true, the program will abort.

***********************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "awaicgen.h"
#include "awaicgen_defs.h"
#include "fitsio.h"

int awaicgen_store_PRFs(AWA_Constants     *AWAP_Const,
		 AWA_Filenames     *AWAP_Fnames,
		 AWA_Computation   *AWAP_Comp,
		 AWA_Status        *AWAP_Stat)
{
  char     prfimfile[STRING_BUFFER_SIZE];
  char     ctype1[9];

  double   intdiff;
  float    sum, minrawscale;
  float    cdelt1diff, cdelt2diff;
  long     fpixel[2];

  FILE     *fp_file;
  fitsfile *ffp_FITS_In;
  int      i, j, loc_i, loc_j, status=0;


  if(AWAP_Stat->I_status)
    return 0;

/*----------------------------------------------------------------------*/
/* Check that the ratio of internal cell grid pixel scale to output
   mosaic pixel scale (input parameter Mosaic_CellFact) is 1/integer.
   If not, abort. If close to 1/integer (within 0.1), force to 1/integer. */

  intdiff = fabs((1.0/AWAP_Const->Mosaic_CellFact) -
             (int)(1.0/AWAP_Const->Mosaic_CellFact));

  if( intdiff >= 0.1 ) {

    fprintf(stderr,"*** Error: awaicgen_store_PRFs: input ratio of %s %s\n",
            "internal cell grid pixel scale to output mosaic pixel scale",
            "(-pc <Mosaic_CellFact>) is not equal to 1/integer.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else if( intdiff < 0.1 ) {

      AWAP_Const->Mosaic_CellFact =
                  1.0 / ((int)(1.0/AWAP_Const->Mosaic_CellFact));
  }


/*----------------------------------------------------------------------*/
/* If input absolute output pixel scale (in arcsec) for mosaic was
   specified, check that this is in acceptable range before proceeding.
   Only checked for coadds involving PRF interpolation, not simple
   overlap-area weighting. */

  if( AWAP_Const->Mosaic_PixScal != -99.99 ) {

    AWAP_Const->Mosaic_PixScal = AWAP_Const->Mosaic_PixScal / 3600.0;

    minrawscale = fminf(fabsf(AWAP_Comp->imgcdelt1),
                        fabsf(AWAP_Comp->imgcdelt2));

    if( !AWAP_Const->Simple_Flag &&
       ((AWAP_Const->Mosaic_PixScal < (MINPIXFACT*minrawscale)) ||
        (AWAP_Const->Mosaic_PixScal > minrawscale)) ) {
      fprintf(stderr,"*** Error: %s %s %s %10.8f <= pa <= %10.8f %s\n",
              "awaicgen_store_PRFs:",
              "specified mosaic pixel size is out of range (-pa <input>).",
              "Allowed range is", 3600*MINPIXFACT*minrawscale,
              3600*minrawscale, "arcsec.");
      AWAP_Stat->I_status = 1;
    }
  }


/*----------------------------------------------------------------------*/
/* Pixel scales of mosaic "cell" grid (at its center) to compare with
   PRF pixel scales below. PRFs will be centered on this fine grid. */

  if( AWAP_Const->Mosaic_PixScal == -99.99 ) {

    AWAP_Comp->cellcdelt1 = AWAP_Comp->imgcdelt1 *
                            AWAP_Const->Mosaic_PixFact *
                            AWAP_Const->Mosaic_CellFact;

    AWAP_Comp->cellcdelt2 = AWAP_Comp->imgcdelt2 *
                            AWAP_Const->Mosaic_PixFact *
                            AWAP_Const->Mosaic_CellFact;
  } else {

    AWAP_Comp->cellcdelt1 = -1.0 * AWAP_Const->Mosaic_PixScal *
                            AWAP_Const->Mosaic_CellFact;

    AWAP_Comp->cellcdelt2 = AWAP_Const->Mosaic_PixScal *
                            AWAP_Const->Mosaic_CellFact;
  }


/*----------------------------------------------------------------------*/
/* Read each PRF image from input list, check keyword value existence and
   compatibility with input images, and count number of files for memory
   allocation below. Only performed if simple (area-weighted) co-add not
   requested. */

 if( !AWAP_Const->Simple_Flag ) {

  if((fp_file = fopen(AWAP_Fnames->Filename_FITS_PRF_List,"r")) == NULL) {
    fprintf(stderr,"*** Error: awaicgen_store_PRFs: input FITS PRF image %s\n",
            "list file could not be opened.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    i = 0;
    while( !feof(fp_file) ) {

      strcpy(prfimfile, "");

      fscanf(fp_file, "%s", prfimfile);

      if( strcmp(prfimfile,"") ) {

        if( AWAP_Stat->I_Verbose )
          printf("awaicgen_store_PRFs: reading/checking %s %d %s %s %s\n",
                 "keywords from PRF #", i+1, ":", prfimfile,"...");

        fits_open_file(&ffp_FITS_In, prfimfile, READONLY, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_store_PRFs: error %s %s; %s %d\n",
                  "opening FITS file:", prfimfile,
                  "FITS error code =", status);
          AWAP_Stat->I_status = 1;
          return 0;
        }

        /*---------------*/
        /* check CTYPE1 (don't worry about CTYPE2). */
        fits_read_key(ffp_FITS_In, TSTRING, "CTYPE1",
                      ctype1, (char *)NULL, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_store_PRFs: error reading %s\n",
                  "FITS keyword: CTYPE1");
          AWAP_Stat->I_status = 1;
          return 0;

        } else if( strcmp(AWAP_Comp->imgctype1, ctype1) ) {
          fprintf(stderr,"*** Error: awaicgen_store_PRFs: CTYPE1 keywords %s\n",
                  "in input PRF and first input image do not match.");
          AWAP_Stat->I_status = 1;
          return 0;
        }

        /*---------------*/
        /* check CDELT1. */
        fits_read_key(ffp_FITS_In, TFLOAT, "CDELT1",
                      &AWAP_Comp->prfcdelt1, (char *)NULL, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_store_PRFs: error reading %s\n",
                  "FITS keyword: CDELT1");
          AWAP_Stat->I_status = 1;
          return 0;
        }

        cdelt1diff = 3600.0*fabs(AWAP_Comp->cellcdelt1 - AWAP_Comp->prfcdelt1);

        if( cdelt1diff > AWAP_Const->PRFScal_Tol ) {

          fprintf(stderr,"*** Error: awaicgen_store_PRFs: %s %s %s %12.10f %s\n",
                  "CDELT1 keyword in input PRF does not match",
                  "sub-pixel (internal cell) size",
                  "to within", AWAP_Const->PRFScal_Tol, "arcsec.");

          printf("awaicgen_store_PRFs: cell-prf cdelt1 difference = %12.10f %s\n",
                 cdelt1diff, "arcsec.");

          AWAP_Stat->I_status = 1;
          return 0;
        }

        if( AWAP_Stat->I_Verbose )
          printf("awaicgen_store_PRFs: cell-prf cdelt1 difference = %12.10f %s\n",
                 cdelt1diff, "arcsec.");

        /*---------------*/
        /* check CDELT2. */
        fits_read_key(ffp_FITS_In, TFLOAT, "CDELT2",
                      &AWAP_Comp->prfcdelt2, (char *)NULL, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_store_PRFs: error reading %s\n",
                  "FITS keyword: CDELT2");
          AWAP_Stat->I_status = 1;
          return 0;
        }

        cdelt2diff = 3600.0*fabs(AWAP_Comp->cellcdelt2 - AWAP_Comp->prfcdelt2);

        if( cdelt2diff > AWAP_Const->PRFScal_Tol ) {

          fprintf(stderr,"*** Error: awaicgen_store_PRFs: %s %s %s %12.10f %s\n",
                  "CDELT2 keyword in input PRF does not match",
                  "sub-pixel (internal cell) size",
                  "to within", AWAP_Const->PRFScal_Tol, "arcsec.");

          printf("awaicgen_store_PRFs: cell-prf cdelt2 difference = %12.10f %s\n",
                 cdelt2diff, "arcsec.");

          AWAP_Stat->I_status = 1;
          return 0;
        }

        if( AWAP_Stat->I_Verbose )
          printf("awaicgen_store_PRFs: cell-prf cdelt2 difference = %12.10f %s\n",
                 cdelt2diff, "arcsec.");

        /*---------------*/
        /* check CRPIX1. */
        fits_read_key(ffp_FITS_In, TFLOAT, "CRPIX1",
                      &AWAP_Comp->prfcrpix1, (char *)NULL, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_store_PRFs: error reading %s\n",
                  "FITS keyword: CRPIX1");
          AWAP_Stat->I_status = 1;
          return 0;
        }

        /*---------------*/
        /* check CRPIX2. */
        fits_read_key(ffp_FITS_In, TFLOAT, "CRPIX2",
                      &AWAP_Comp->prfcrpix2, (char *)NULL, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_store_PRFs: error reading %s\n",
                  "FITS keyword: CRPIX2");
          AWAP_Stat->I_status = 1;
          return 0;
        }

        /*---------------*/
        /* check NAXIS1. */
        fits_read_key(ffp_FITS_In, TLONG, "NAXIS1",
                      &AWAP_Comp->prfnaxis1, (char *)NULL, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_store_PRFs: error reading %s\n",
                  "FITS keyword: NAXIS1");
          AWAP_Stat->I_status = 1;
          return 0;
        }

        /*---------------*/
        /* check NAXIS2. */
        fits_read_key(ffp_FITS_In, TLONG, "NAXIS2",
                      &AWAP_Comp->prfnaxis2, (char *)NULL, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_store_PRFs: error reading %s\n",
                  "FITS keyword: NAXIS2");
          AWAP_Stat->I_status = 1;
          return 0;
        }

        fits_close_file(ffp_FITS_In, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_store_PRFs: error %s %s; %s %d\n",
                  "closing FITS file:", prfimfile,
                  "FITS error code =", status);
          AWAP_Stat->I_status = 1;
          return 0;
        }

        i++;

      } else if( (i == 0) && !strcmp(prfimfile,"") ) {

        fprintf(stderr,"*** Error: awaicgen_store_PRFs: could not find %s\n",
                "image file in input PRF FITS image list.");
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }
  }

  if( fclose(fp_file) ) {
    fprintf(stderr,"*** Error: awaicgen_store_PRFs: input PRF FITS image %s\n",
            "list file could not be closed.");
    AWAP_Stat->I_status = 1;
    return 0;
  }

  AWAP_Comp->numprfs = i;


/*----------------------------------------------------------------------*/
/* Check that number of input PRFs is a perfect square to support
   FPA-location dependent picking. */

  if( sqrt(AWAP_Comp->numprfs) - (int)(sqrt(AWAP_Comp->numprfs)) ) {
    fprintf(stderr,"*** Error: awaicgen_store_PRFs: input number of PRFs %s\n",
            "does not form a perfect square; only square N x N grid allowed.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    AWAP_Comp->prfgriddim = (int)( sqrt(AWAP_Comp->numprfs) );

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_store_PRFs: input PRFs are defined on a %d x %d grid.\n",
             AWAP_Comp->prfgriddim, AWAP_Comp->prfgriddim);
    }
  }


/*----------------------------------------------------------------------*/
/* Store the FPA X, Y locations of each characteristic PRF and the
   pixel data from each in a 2D array: prfdata[0..numprfs][0..naxis1*naxis2]
   First allocate memory for 1D X,Y[0..numprfs] arrays and 2D data array. */

  /*----------*/
  /* Array storing X-locations of PRF. */

  AWAP_Comp->xprf = (float *) calloc(AWAP_Comp->numprfs, sizeof(float));

  if( AWAP_Comp->xprf == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_store_PRFs: could not allocate %s\n",
            "memory for xprf array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_store_PRFs: allocated %10.8f MB for %s\n",
             (AWAP_Comp->numprfs*sizeof(float)/1.0E+06),
             "xprf array.");
    }
  }

  /*----------*/
  /* Array storing Y-locations of PRF. */

  AWAP_Comp->yprf = (float *) calloc(AWAP_Comp->numprfs, sizeof(float));

  if( AWAP_Comp->yprf == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_store_PRFs: could not allocate %s\n",
            "memory for yprf array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_store_PRFs: allocated %10.8f MB for %s\n",
             (AWAP_Comp->numprfs*sizeof(float)/1.0E+06),
             "yprf array.");
    }
  }

  /*----------*/
  /* 2D array storing PRF data: prfdata[0..numprfs][0..naxis1*naxis2] */

  AWAP_Comp->prfdata = (float **) calloc(AWAP_Comp->numprfs, sizeof(float *));

  for( i = 0; i < AWAP_Comp->numprfs; i++ )
    AWAP_Comp->prfdata[i] = (float *) calloc((AWAP_Comp->prfnaxis1*
                                              AWAP_Comp->prfnaxis2),
                                              sizeof(float));

  if( AWAP_Comp->prfdata == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_store_PRFs: could not allocate %s\n",
            "memory for prfdata array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_store_PRFs: allocated %10.8f MB for %s\n",
             (AWAP_Comp->numprfs*AWAP_Comp->prfnaxis1*AWAP_Comp->prfnaxis2*
             sizeof(float)/1.0E+06), "prfdata 2D array.");
    }
  }

  /*----------*/
  /* 2D array storing PRF positions in list: prflistind[0..jloc][0..iloc],
     where iloc, jloc represent grid partition indices computed from the
     input FPALOCX, FPALOCY values in the input PRF headers. iloc, jloc
     starts at bottom left of grid and "fast" dimension is along X. */

  AWAP_Comp->prflistind = (int **) calloc(AWAP_Comp->prfgriddim,
                                          sizeof(int *));

  if( AWAP_Comp->prflistind == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_store_PRFs: could not allocate %s\n",
            "memory for prflistind array.");
    AWAP_Stat->I_status = 1;
    return 0;
  }

  for( i = 0; i < AWAP_Comp->prfgriddim; i++ ) {

    AWAP_Comp->prflistind[i] = (int *) calloc(AWAP_Comp->prfgriddim,
                                              sizeof(int));

    if( AWAP_Comp->prflistind[i] == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_store_PRFs: could not %s\n",
              "allocate memory for prflistind array.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  if( AWAP_Stat->I_Verbose )
    printf("awaicgen_store_PRFs: allocated %10.8f MB for %s\n",
           (AWAP_Comp->numprfs*sizeof(int)/1.0E+06),
           "prflistind 2D array.");

  /*----------*/
  /* Store the PRF data. */

  /* Initialize starting pixels in each dimension from which to read data: */

  fpixel[0] = 1;  /* column dim. */
  fpixel[1] = 1;  /* row dim.    */

  if((fp_file = fopen(AWAP_Fnames->Filename_FITS_PRF_List,"r")) == NULL) {
    fprintf(stderr,"*** Error: awaicgen_store_PRFs: input FITS PRF image %s\n",
            "list file could not be opened.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    /* define FPALOCX, FPALOCY values if only one PRF is in input list
       since for this case, we don't read them from the header. */

    if( AWAP_Comp->numprfs == 1 ) {
      AWAP_Comp->xprf[0] = 0.5 * AWAP_Comp->imgnaxis1;
      AWAP_Comp->yprf[0] = 0.5 * AWAP_Comp->imgnaxis2;
    }

    for( i = 0; i < AWAP_Comp->numprfs; i++ ) {

      strcpy(prfimfile, "");

      fscanf(fp_file, "%s", prfimfile);

      if( AWAP_Stat->I_Verbose )
        printf("awaicgen_store_PRFs: storing data %s %d %s %s %s\n",
               "from PRF #", i+1, ":", prfimfile,"...");

      fits_open_file(&ffp_FITS_In, prfimfile, READONLY, &status);
      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_store_PRFs: error %s %s; %s %d\n",
                "opening FITS file:", prfimfile, "FITS error code =", status);
        AWAP_Stat->I_status = 1;
        return 0;
      }

      /*---------------*/
      /* Store FPALOCX keyword value if multiple PRFs. */

      if( AWAP_Comp->numprfs > 1 ) {
        fits_read_key(ffp_FITS_In, TFLOAT, "FPALOCX",
                      &(AWAP_Comp->xprf[i]), (char *)NULL, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_store_PRFs: error reading FITS %s\n",
                  "keyword: FPALOCX");
          AWAP_Stat->I_status = 1;
          return 0;

        } else {

          if( AWAP_Comp->xprf[i] <= 0.0 ) {
            fprintf(stderr,"*** Error: awaicgen_store_PRFs: PRF X location %s\n",
                    "keyword value (FPALOCX) must be > 0.");
            AWAP_Stat->I_status = 1;
            return 0;
          }

          if( AWAP_Stat->I_Verbose ) {
            printf("awaicgen_store_PRFs: stored X location for PRF # %d : %f\n",
                   i+1, AWAP_Comp->xprf[i]);
          }
        }
      }

      /*---------------*/
      /* Store FPALOCY keyword value if multiple PRFs. */

      if( AWAP_Comp->numprfs > 1 ) {
        fits_read_key(ffp_FITS_In, TFLOAT, "FPALOCY",
                      &(AWAP_Comp->yprf[i]), (char *)NULL, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_store_PRFs: error reading FITS %s\n",
                  "keyword: FPALOCY");
          AWAP_Stat->I_status = 1;
          return 0;

        } else {

          if( AWAP_Comp->yprf[i] <= 0.0 ) {
            fprintf(stderr,"*** Error: awaicgen_store_PRFs: PRF Y location %s\n",
                    "keyword value (FPALOCY) must be > 0.");
            AWAP_Stat->I_status = 1;
            return 0;
          }

          if( AWAP_Stat->I_Verbose ) {
            printf("awaicgen_store_PRFs: stored Y location for PRF # %d : %f\n",
                   i+1, AWAP_Comp->yprf[i]);
          }
        }
      }

      /*---------------*/
      /* Compute PRF grid location array indices to use as indices in
         prflistind 2D array and store PRF file position in input list. */

      loc_i = (int)((AWAP_Comp->xprf[i] * ((float)(AWAP_Comp->prfgriddim)/
              (float)(AWAP_Comp->imgnaxis1))) + 0.5) - 1;

      loc_j = (int)((AWAP_Comp->yprf[i] * ((float)(AWAP_Comp->prfgriddim)/
              (float)(AWAP_Comp->imgnaxis2))) + 0.5) - 1;

      if( (loc_i < 0) ||
          (loc_j < 0) ||
          (loc_i >= AWAP_Comp->prfgriddim) ||
          (loc_j >= AWAP_Comp->prfgriddim) ) {

        fprintf(stderr,"*** Error: awaicgen_store_PRFs: either the %s %d %s\n",
                "FPALOCX or FPALOCY value is out of range for PRF", i,
                "(PRF grid array indices are out of bounds; please check)");
        AWAP_Stat->I_status = 1;
        return 0;
      }

      AWAP_Comp->prflistind[loc_j][loc_i] = i;

      if( AWAP_Stat->I_Verbose ) {
        printf("awaicgen_store_PRFs: grid location indices %s %d %s = %d,%d.\n",
               "(zero-based x,y) for PRF",i,"in input list",loc_i,loc_j);
      }

      /*---------------*/
      /* Store the pixel data for each PRF in 2D array. */

      fits_read_pix(ffp_FITS_In, TFLOAT, fpixel,
                   (AWAP_Comp->prfnaxis1*AWAP_Comp->prfnaxis2),
                    NULL, AWAP_Comp->prfdata[i], NULL, &status);
      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_store_PRFs: error storing %s %s\n",
                "pixel data from PRF:", prfimfile);
        AWAP_Stat->I_status = 1;
        return 0;

      } else {
        if( AWAP_Stat->I_Verbose ) {
          printf("awaicgen_store_PRFs: stored pixel data for PRF # %d : %s\n",
                 i+1, prfimfile);
        }
      }

      fits_close_file(ffp_FITS_In, &status);
      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_store_PRFs: error %s %s; %s %d\n",
                "closing FITS file:", prfimfile, "FITS error code =", status);
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }
  }

  if( fclose(fp_file) ) {
    fprintf(stderr,"*** Error: awaicgen_store_PRFs: input PRF FITS image %s\n",
            "list file could not be closed.");
    AWAP_Stat->I_status = 1;
    return 0;
  }


/*----------------------------------------------------------------------*/
/* Check that the pixel data in each PRF sums to unity. */

  for( i = 0; i < AWAP_Comp->numprfs; i++ ) {

    sum = 0.0;
    for(j = 0; j < (AWAP_Comp->prfnaxis1*AWAP_Comp->prfnaxis2); j++ )
      sum += AWAP_Comp->prfdata[i][j];

    if( fabs(sum - 1.0) > UNITSUMTOL ) {
      fprintf(stderr,"*** Error: awaicgen_store_PRFs: data %s %d %s %14.12f\n",
              "values in PRF #", i+1, "do not sum to unity within tolerance:",
              UNITSUMTOL);
      AWAP_Stat->I_status = 1;
      return 0;

    } else {
      if( AWAP_Stat->I_Verbose )
        printf("awaicgen_store_PRFs: data values in PRF # %d %s %s %14.12f\n",
               i+1, "sum to unity with accuracy", "(difference from unity):",
               fabs(sum - 1.0));
    }
  }

 } /* End of "if !AWAP_Const->Simple_Flag" statement. */

 return 0;
}
