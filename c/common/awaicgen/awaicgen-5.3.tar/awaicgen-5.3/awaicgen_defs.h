
/***********************************************
awaic_defs.h

Purpose
Define structures.

***********************************************/

#include "two_plane.h"

typedef struct {
  double Mosaic_SizeX;
  double Mosaic_SizeY;
  double RA_center;
  double Dec_center;
  double Mosaic_Rot;
  double Mosaic_PixScal;
  double Mosaic_PixFact;
  double Mosaic_CellFact;
  double PRFScal_Tol;
  double Ldriz;
  double CFVpctdiff;
  int    Simple_Flag;
  int    Flxscal_Flag;
  int    RotPRF_Flag;
  int    Weight_Flag;
  int    Interp_Method;
  int    Num_Iter;
  int    have_uncert;
  int    have_masks;
  int    want_corr;
  int    want_cffv;
  int    want_msk;
  int    Fatal_Bits;
  int    Sat_Bits;
  int    SigFig;
  int    TophatPrior;
  int    NumThreads;
} AWA_Constants;


typedef struct {
  char  Filename_FITS_Image_List[STRING_BUFFER_SIZE];
  char  Filename_FITS_Uncert_List[STRING_BUFFER_SIZE];
  char  Filename_FITS_Mask_List[STRING_BUFFER_SIZE];
  char  Filename_FITS_PRF_List[STRING_BUFFER_SIZE];
  char  Filename_Output_Mosaic[STRING_BUFFER_SIZE];
  char  Filename_Output_Coverage[STRING_BUFFER_SIZE];
  char  Filename_Output_Uncert[STRING_BUFFER_SIZE];
  char  Filename_Output_Stddev[STRING_BUFFER_SIZE];
  char  Filename_Output_Corr[STRING_BUFFER_SIZE];
  char  Filename_Output_CFVUncert[STRING_BUFFER_SIZE];
  char  Filename_Output_MosaicCell[STRING_BUFFER_SIZE];
  char  Filename_Output_MosaicCFV[STRING_BUFFER_SIZE];
  char  Filename_Output_MosaicCOR[STRING_BUFFER_SIZE];
  char  Filename_Output_MosaicMsk[STRING_BUFFER_SIZE];
  char  Filename_Output_MosaicIter[STRING_BUFFER_SIZE];
  char  Filename_Output_MosaicFIter[STRING_BUFFER_SIZE];
  char  Filename_Input_MosaicCell[STRING_BUFFER_SIZE];
  char  (*Filename_FITS_Image)[STRING_BUFFER_SIZE];
  char  (*Filename_FITS_Uncert)[STRING_BUFFER_SIZE];
  char  (*Filename_FITS_Mask)[STRING_BUFFER_SIZE];
} AWA_Filenames;


typedef struct {
  int  I_status;
  int  I_Debug;
  int  I_Verbose;
} AWA_Status;


typedef struct {
  char   *outwcsheader;
  char   *outrwcsheader;
  char   imgctype1[9];
  char   imgctype2[9]; 
  float  imgequinox;
  float  imgcdelt1;
  float  imgcdelt2;
  float  cellcrpix1;
  float  cellcrpix2;
  float  cellcdelt1;
  float  cellcdelt2;
  float  moscdelt1;
  float  moscdelt2;
  float  moscrpix1;
  float  moscrpix2;
  float  prfcdelt1;
  float  prfcdelt2;
  float  prfcrpix1;
  float  prfcrpix2;
  float  *xprf;
  float  *yprf;
  float  **prfdata;
  float  **mos_pix_array;
  float  **mos_cov_array;
  float  **mos_sig_array;
  float  **mos_std_array;
  float  **mos_cor_array;
  float  **mos_cfv_array;
  float  **mos_fitr_array;
  long   imgnaxis1;
  long   imgnaxis2;
  long   prfnaxis1;
  long   prfnaxis2;
  long   cellnaxis1;
  long   cellnaxis2;
  long   mosnaxis1;
  long   mosnaxis2;
  int    **prflistind;
  int    numprfs;
  int    prfgriddim;
  int    numimages;
  int    numuncerts;
  int    nummasks;
} AWA_Computation;


typedef struct {
  AWA_Computation cp;
  AWA_Constants co;
  AWA_Filenames fn;
  AWA_Status st;
  struct TwoPlane twoplane;
  struct TwoPlane rtwoplane;
  float  theta_m;
  long   kstart;
  long   kend;
  long   iistart;
  long   iiend;
  int    threadid;
  int    NumGoodD_i;
  int    ProjectionStatus;
  char   **mos_msk_array;
  float  chisq_m;
  float  **mos_cell_array;
  float  **Cnum_j;
  float  **Vnum_j;
  float  **CFFV_j;
  float  **NSV_j;
  float  **NV_j;
  float  **N_j;
  float  **imgdata;
  float  **uncdata;
  long   **mskdata;
  double Fdriz;
} AWA_Impix;


/* Prototypes. */

int awaicgen_synopsis(int           argc,
                      char          **argv,
                      AWA_Status    *AWAP_Stat);

int awaicgen_init_constants(AWA_Constants    *AWAP_Const,
                            AWA_Filenames    *AWAP_Fnames,
                            AWA_Status       *AWAP_Stat);

int awaicgen_parse_args(int            argc,
                        char           **argv,
                        AWA_Constants  *AWAP_Const,
                        AWA_Filenames  *AWAP_Fnames,
                        AWA_Status     *AWAP_Stat);

int awaicgen_store_img_fnames(AWA_Constants    *AWAP_Const,
                              AWA_Filenames    *AWAP_Fnames,
                              AWA_Computation  *AWAP_Comp,
                              AWA_Status       *AWAP_Stat);

int awaicgen_store_PRFs(AWA_Constants     *AWAP_Const,
                        AWA_Filenames     *AWAP_Fnames,
                        AWA_Computation   *AWAP_Comp,
                        AWA_Status        *AWAP_Stat);

int awaicgen_output_wcs(AWA_Constants     *AWAP_Const,
                        AWA_Computation   *AWAP_Comp,
                        AWA_Status        *AWAP_Stat);

int awaicgen_compute_results(AWA_Constants     *AWAP_Const,
                             AWA_Filenames     *AWAP_Fnames,
                             AWA_Computation   *AWAP_Comp,
                             AWA_Impix         *AWAP_Impix,
                             AWA_Status        *AWAP_Stat);

int awaicgen_compute_results_hires(AWA_Constants     *AWAP_Const,
                                   AWA_Filenames     *AWAP_Fnames,
                                   AWA_Computation   *AWAP_Comp,
                                   AWA_Impix         *AWAP_Impix,
                                   AWA_Status        *AWAP_Stat);

int awaicgen_compute_results_simple(AWA_Constants     *AWAP_Const,
                                    AWA_Filenames     *AWAP_Fnames,
                                    AWA_Computation   *AWAP_Comp,
                                    AWA_Impix         *AWAP_Impix,
                                    AWA_Status        *AWAP_Stat);

int awaicgen_output(AWA_Constants     *AWAP_Const,
                    AWA_Filenames     *AWAP_Fnames,
                    AWA_Computation   *AWAP_Comp,
                    AWA_Impix         *AWAP_Impix,
                    AWA_Status        *AWAP_Stat);

int awaicgen_log_writer(int            argc,
                        AWA_Constants  *AWAP_Const,
                        AWA_Status     *AWAP_Stat,
                        AWA_Filenames  *AWAP_Fnames);

int stradd(char *header, char *card);

int awaicgen_write_mcmimg(float             **mos_cell_array,
                          int               iter,
                          AWA_Computation   *AWAP_Comp,
                          AWA_Filenames     *AWAP_Fnames,
                          AWA_Status        *AWAP_Stat);

int awaicgen_tophat_prior(float             **mos_cell_array,
                          AWA_Constants     *AWAP_Const,
                          AWA_Filenames     *AWAP_Fnames,
                          AWA_Computation   *AWAP_Comp,
                          AWA_Status        *AWAP_Stat);

int awaicgen_write_mcmcf(float             **CF_j,
                         int               iter,
                         AWA_Computation   *AWAP_Comp,
                         AWA_Filenames     *AWAP_Fnames,
                         AWA_Status        *AWAP_Stat);

int awaicgen_write_mcmcfv(float             **CFVo_j,
                          int               iter,
                          AWA_Computation   *AWAP_Comp,
                          AWA_Filenames     *AWAP_Fnames,
                          AWA_Status        *AWAP_Stat);


int awaicgen_write_mcmiter(short int         **NlastIter_j,
                           AWA_Computation   *AWAP_Comp,
                           AWA_Filenames     *AWAP_Fnames,
                           AWA_Status        *AWAP_Stat);
