
/***********************************************
awaicgen_compute_prfcoadd.c

Purpose

Contains function to support multi-threading for
co-add creation using PRF as interpolation kernel
called from awaicgen_compute_results.c. Threading is
performed over detector pixels of an input image,
with implicit use of PRF as interpolation kernel.

***********************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "awaicgen.h"
#include "awaicgen_defs.h"
#include "wcs.h"
#include "two_plane.h"
#include "distort.h"

void awaicgen_compute_prfcoadd(AWA_Impix     *AWAP_Impix)
{
  float   **Cnum_j;
  float   **NV_j;
  float   **NSV_j;
  float   **N_j;
  float   **imgdata;
  float   **uncdata;
  long    **mskdata;
  char    **mos_msk_array;

  float   D_i, D_x, D_y, M_i, V_i, S_i;
  float   prf_x, prf_y, prf, outin_area_ratio;
  double  CD_x, CD_y;

  long    i, ii, j, jj, k, po;
  long    C_PRF_x, C_PRF_y, M_x, M_y;

  int     n, p, pp, offscl;
  int     loc_i, loc_j, locindex;
  int     maxoffset=0;

  /* Store global/structure variables into local variables. */

  mos_msk_array = AWAP_Impix->mos_msk_array;
  Cnum_j = AWAP_Impix->Cnum_j;
  NV_j = AWAP_Impix->NV_j;
  NSV_j = AWAP_Impix->NSV_j;
  N_j = AWAP_Impix->N_j;
  imgdata = AWAP_Impix->imgdata;
  uncdata = AWAP_Impix->uncdata;
  mskdata = AWAP_Impix->mskdata;

  if( AWAP_Impix->st.I_Verbose )
    printf("awaicgen_compute_prfcoadd: thread %d: %s %ld <= k <= %ld\n",
           AWAP_Impix->threadid,"1D pixel index range to process:",
           AWAP_Impix->kstart,AWAP_Impix->kend);

/*----------------------------------------------------------------------*/
/* For each detector pixel (D_x, D_y) in input image m, transform to
   mosaic cell grid frame =(CD_x, CD_y) using fast WCS projection.
   Then transform native PRF coords centered at this pixel to mosaic
   cell grid using linear transformation and round to nearest integer
   cell pixel. Beware that PRF is not transformed using full non-linear
   WCS transformation from input image to mosaic plane. For large
   mosaics, there could be an inaccurate representation of the PRF
   flux distribution towards mosaic edges. */

  /* initalize number of input image pixels processed. */

  po = 0;

  for(ii = AWAP_Impix->iistart; ii <= AWAP_Impix->iiend; ii++) {
    for(i = 0; i < AWAP_Impix->cp.imgnaxis1; i++) {

     k = (ii * AWAP_Impix->cp.imgnaxis1) + i;
     if( (k >= AWAP_Impix->kstart) && (k <= AWAP_Impix->kend) ) {

      po++;

      /* measured flux in detector pixel at (x,y) = (i+1,ii+1). */

      D_i = imgdata[ii][i];

      /* use appropriate FPA-position dependent PRF from input list
         according to x,y location of detector pixel. */

      locindex = 0;

      if( AWAP_Impix->cp.numprfs > 1 ) {
        loc_i = (int)(i * (float)(AWAP_Impix->cp.prfgriddim)/
                (float)(AWAP_Impix->cp.imgnaxis1));

        loc_j = (int)(ii * (float)(AWAP_Impix->cp.prfgriddim)/
                (float)(AWAP_Impix->cp.imgnaxis2));

        locindex = AWAP_Impix->cp.prflistind[loc_j][loc_i];
      }

      /*
      printf("DBG: Using PRF %d for image pixel x,y = %ld,%ld (val = %f)\n",
             locindex, i+1, ii+1, D_i);
      */

      /* initialize variances to 1 in case input uncertainties
         not given, otherwise use input for detector pixel at
         (x,y) = (i+1,ii+1). */

      V_i = 1.0;
      S_i = 1.0;

      if( AWAP_Impix->co.have_uncert && AWAP_Impix->co.Weight_Flag )
        V_i = uncdata[ii][i] * uncdata[ii][i];

      /* Following is for n = 1 uncertainty estimation with no
         inverse variance weighting, i.e., Weight_Flag = 0. */

      if( AWAP_Impix->co.have_uncert && !AWAP_Impix->co.Weight_Flag )
        S_i = uncdata[ii][i] * uncdata[ii][i];

      /* initialize mask value to "not masked", otherwise, if input
         masks specified, use specific mask value for detector pixel
         at (x,y) = (i+1,ii+1). */

      M_i = 0.0;

      if( AWAP_Impix->co.have_masks )
        if( mskdata[ii][i] & AWAP_Impix->co.Fatal_Bits )
          M_i = 1.0;

      /* if input pixel D_i or variances V_i, S_i are NaNs or zero
         (regardless if input masks were specified), mask it! */

      if( (D_i != D_i) || (V_i != V_i) || (V_i == 0.0) || (S_i != S_i) )
        M_i = 1.0;

      /* only reproject and co-add input pixel D_i if it is not masked
         and not NaN'd. */

      if( M_i != 1.0 ) {

        D_x = i + 1.0;
        D_y = ii + 1.0;

        /* Project (D_x, D_y) to mosaic cell frame: out = (CD_x, CD_y). */

        offscl = plane1_to_plane2_transform(D_x, D_y, &CD_x, &CD_y,
                                            &AWAP_Impix->twoplane);

        if( !offscl ) {

          AWAP_Impix->ProjectionStatus = 1;

          for( pp = 0; pp < AWAP_Impix->cp.prfnaxis2; pp++ ) {
            for( p = 0; p < AWAP_Impix->cp.prfnaxis1; p++ ) {

              prf_x = p + 1.0;
              prf_y = pp + 1.0;

              prf = AWAP_Impix->cp.prfdata[locindex]
                                          [(pp*AWAP_Impix->cp.prfnaxis1)+p];

              /* Transform PRF coords to mosaic cell coords using local
                 Cartesian transformation and round to nearest integer. */

                C_PRF_x = (long)(CD_x + (prf_x - AWAP_Impix->cp.prfcrpix1)
                                 + 0.5);

                C_PRF_y = (long)(CD_y + (prf_y - AWAP_Impix->cp.prfcrpix2)
                                 + 0.5);

              /* For detector pixel D_i, increment the average flux
                 <f_j> arrays for cells j "touched" by D_i where
                 <f_j> = Cnum_j / NV_j and NV_j = sum of inverse
                 variance weighted responses. Coverage contribution = N_j.
                 NSV_j = array for computing uncertainties. */

              if( (C_PRF_x - maxoffset >= 1) &&
                  (C_PRF_y - maxoffset >= 1) &&
                  (C_PRF_x + maxoffset <= AWAP_Impix->cp.cellnaxis1) &&
                  (C_PRF_y + maxoffset <= AWAP_Impix->cp.cellnaxis2) ) {

                Cnum_j[C_PRF_y - 1][C_PRF_x - 1] += ((prf * D_i) / V_i);
                NSV_j[C_PRF_y - 1][C_PRF_x - 1] += ((prf * prf * S_i) / V_i);
                NV_j[C_PRF_y - 1][C_PRF_x - 1] += (prf / V_i);
                N_j[C_PRF_y - 1][C_PRF_x - 1] += prf;

              } /* end of "if PRF pixel coords are on cell grid". */

            }  /* end of loop for x pos. of PRF cell corres. to D_i
                  and incrementing <f_j> component arrays. */

          }  /* end of loop for y pos. of PRF cell corres. to D_i
                and incrementing <f_j> component arrays. */

        }  /* end of "if not offscale" statement. */

      }  /* end of "if not masked pixel" statement. */

      /* If input pixel is masked (hence omitted from processing), set
         specific flavor in output mosaic mask if product requested. Note
         that this mask shows the locations of bad and saturated pixels
         that occur at least once in the frame stack, and the projection
         from input to output mask maps to the nearest output pixel. */

      else if( M_i == 1.0 && AWAP_Impix->co.want_msk ) {

        D_x = i + 1.0;
        D_y = ii + 1.0;

        /* Project (D_x, D_y) to real mosaic frame: out = (CD_x, CD_y). */

        offscl = plane1_to_plane2_transform( D_x, D_y, &CD_x, &CD_y,
                                             &AWAP_Impix->rtwoplane );

        if( !offscl ) {

          /* Transform coords to real output mosaic pixel coords. */

          M_x = (long)(CD_x + 0.5);
          M_y = (long)(CD_y + 0.5);

          if( (M_x - maxoffset >= 1) &&
              (M_y - maxoffset >= 1) &&
              (M_x + maxoffset <= AWAP_Impix->cp.mosnaxis1) &&
              (M_y + maxoffset <= AWAP_Impix->cp.mosnaxis2) ) {

            /* Assign mask value according to bad-pixel flavor as defined
               in awaicgen.h. For omitted (M_i=1) pixels which are not
               associated with input masked pixels (e.g., rogue NaNs),
               set these as OUTMSKBAD. */

            if( (mskdata[ii][i] & AWAP_Impix->co.Fatal_Bits) &&
                !(mskdata[ii][i] & AWAP_Impix->co.Sat_Bits) )
              mos_msk_array[M_y - 1][M_x - 1] = OUTMSKBAD;
            else if( mskdata[ii][i] & AWAP_Impix->co.Sat_Bits )
              mos_msk_array[M_y - 1][M_x - 1] = OUTMSKSAT;
            else
              mos_msk_array[M_y - 1][M_x - 1] = OUTMSKBAD;
          }

        } /* end of "if not offscale" statement for masked pixel case. */

      } /* end of "if masked pixel" & output mask specified statement. */

     } /* end of "k>=kstart && k<=kend" statement. */

    } /* end of loop for x pos. of D_i pixel. */

  } /* end of loop for y pos. of D_i pixel. */

  if( AWAP_Impix->st.I_Verbose )
    printf("awaicgen_compute_prfcoadd: thread %d: %s %ld\n", AWAP_Impix->threadid,
           "number of input image pixels processed =",po);

  /* Store updated outputs back into global/structure variables. */

  AWAP_Impix->mos_msk_array = mos_msk_array;
  AWAP_Impix->Cnum_j = Cnum_j;
  AWAP_Impix->NV_j = NV_j;
  AWAP_Impix->NSV_j = NSV_j;
  AWAP_Impix->N_j = N_j;

}
