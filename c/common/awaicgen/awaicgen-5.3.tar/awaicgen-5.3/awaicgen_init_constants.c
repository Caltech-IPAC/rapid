
/***********************************************
awaicgen_init_constants.c

Purpose

Initialize constant values and defaults in case not specified on input
in awaicgen_parse_args subroutine.

***********************************************/

#include <stdio.h>
#include "awaicgen.h"
#include "awaicgen_defs.h"

int awaicgen_init_constants(AWA_Constants    *AWAP_Const,
		     AWA_Filenames    *AWAP_Fnames,
		     AWA_Status       *AWAP_Stat)
{
  if(AWAP_Stat->I_status)
    return 0;

/* Initialize status flags. */

   AWAP_Stat->I_status = 0;
   AWAP_Stat->I_Debug = 0;
   AWAP_Stat->I_Verbose = 0;

/* Set defaults for optional inputs:*/

   AWAP_Const->Simple_Flag = 0;
   AWAP_Const->Flxscal_Flag = 0;
   AWAP_Const->RotPRF_Flag = 0;
   AWAP_Const->Weight_Flag = 0;
   AWAP_Const->Interp_Method = 0;
   AWAP_Const->PRFScal_Tol = 0.0001; /* arcsec */
   AWAP_Const->Mosaic_Rot = 0.0;     /* degree */
   AWAP_Const->Mosaic_PixScal = -99.99;
   AWAP_Const->Mosaic_PixFact = 0.5;
   AWAP_Const->Mosaic_CellFact = 0.5;
   AWAP_Const->Num_Iter = 1;
   AWAP_Const->have_uncert = 0;
   AWAP_Const->have_masks = 0;
   AWAP_Const->want_corr = 0;
   AWAP_Const->want_cffv = 0;
   AWAP_Const->Fatal_Bits = 0;
   AWAP_Const->Sat_Bits = 0;
   AWAP_Const->SigFig = 0;
   AWAP_Const->TophatPrior = 0;
   AWAP_Const->Ldriz = 1.0;
   AWAP_Const->CFVpctdiff = 0.0;
   AWAP_Const->NumThreads = 1;

/* Put in stdio defaults in case filenames not specified later. */

   sprintf(AWAP_Fnames->Filename_FITS_Image_List, "%s", "");
   sprintf(AWAP_Fnames->Filename_FITS_Uncert_List, "%s", "");
   sprintf(AWAP_Fnames->Filename_FITS_Mask_List, "%s", "");
   sprintf(AWAP_Fnames->Filename_FITS_PRF_List, "%s", "");
   sprintf(AWAP_Fnames->Filename_Output_Mosaic, "%s", "");
   sprintf(AWAP_Fnames->Filename_Output_Coverage, "%s", "");
   sprintf(AWAP_Fnames->Filename_Output_Uncert, "%s", "");
   sprintf(AWAP_Fnames->Filename_Output_Stddev, "%s", "");
   sprintf(AWAP_Fnames->Filename_Output_Corr, "%s", "");
   sprintf(AWAP_Fnames->Filename_Output_CFVUncert, "%s", "");
   sprintf(AWAP_Fnames->Filename_Output_MosaicCell, "%s", "");
   sprintf(AWAP_Fnames->Filename_Output_MosaicCFV, "%s", "");
   sprintf(AWAP_Fnames->Filename_Output_MosaicCOR, "%s", "");
   sprintf(AWAP_Fnames->Filename_Output_MosaicMsk, "%s", "");
   sprintf(AWAP_Fnames->Filename_Output_MosaicIter, "%s", "");
   sprintf(AWAP_Fnames->Filename_Output_MosaicFIter, "%s", "");
   sprintf(AWAP_Fnames->Filename_Input_MosaicCell, "%s", "");

   return 0;
}
