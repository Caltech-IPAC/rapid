
/***********************************************
awaicgen_output_wcs.c

Purpose

Define WCS keyword values for the internal "fine-sampled"
mosaic _cell_ grid to support the "fast" plane-to-plane
reprojection. Also define some WCS keyword values for
the final output mosaic (and ancillary products).

***********************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "awaicgen.h"
#include "awaicgen_defs.h"

int awaicgen_output_wcs(AWA_Constants     *AWAP_Const,
		 AWA_Computation   *AWAP_Comp,
		 AWA_Status        *AWAP_Stat)
{
  char     line[STRING_BUFFER_SIZE];
  int      numwcslines;
  double   pad1, pad2;


  if(AWAP_Stat->I_status)
    return 0;

/*----------------------------------------------------------------------*/
/* Assign mosaic "cell" WCS parameters to support the fast projection only,
   not the final mosaic WCS. Lien: the cdelts pertain to the plane center,
   not extremities. Therefore, calculation of NAXISs needs to account for
   the geometric projection. SIN gives effectively smaller NAXIS values,
   while TAN gives larger values than if assume tangent point cdelts for
   computing NAXIS using "linear_size_sky/cdelt". For all projections,
   assume a 1-to-1 linear projection from sky to plane => for SIN, will
   get "more sky" projected than asked for; for TAN, mosaic plane will
   not be big enough to project desired sky. Also, we need to pad the
   border of the nominal mosaic "cell" region with additional pixels
   equal to the PRF width to avoid edge anomalies affecting the nominal
   mosaic region. If simple area-weighted co-add requested, simply pad
   by a factor of 4x inp/out pixel ratio. */

  if( !AWAP_Const->Simple_Flag ) {

    pad1 = 2.0 * AWAP_Comp->prfnaxis1;
    pad2 = 2.0 * AWAP_Comp->prfnaxis2;

  } else {

    pad1 = 4 * (int)(fabs(AWAP_Comp->imgcdelt1)/ fabs(AWAP_Comp->cellcdelt1));
    pad2 = 4 * (int)(fabs(AWAP_Comp->imgcdelt2)/ fabs(AWAP_Comp->cellcdelt2));
  }

  AWAP_Comp->cellnaxis1 = (long)((AWAP_Const->Mosaic_SizeX /
                                  fabs(AWAP_Comp->cellcdelt1)) +
                                  pad1);

  AWAP_Comp->cellnaxis2 = (long)((AWAP_Const->Mosaic_SizeY /
                                  fabs(AWAP_Comp->cellcdelt2)) +
                                  pad2);

  AWAP_Comp->cellcrpix1 = 0.5 * (AWAP_Comp->cellnaxis1 + 1.0);

  AWAP_Comp->cellcrpix2 = 0.5 * (AWAP_Comp->cellnaxis2 + 1.0);


/*----------------------------------------------------------------------*/
/* Assign some of the real output mosaic WCS parameters. Only used for
   writing final output mosaic arrays later. */

  if( AWAP_Const->Mosaic_PixScal == -99.99 ) {

    AWAP_Comp->moscdelt1 = AWAP_Comp->imgcdelt1 * AWAP_Const->Mosaic_PixFact;

    AWAP_Comp->moscdelt2 = AWAP_Comp->imgcdelt2 * AWAP_Const->Mosaic_PixFact;

  } else {

    AWAP_Comp->moscdelt1 = -1.0 * AWAP_Const->Mosaic_PixScal;

    AWAP_Comp->moscdelt2 = AWAP_Const->Mosaic_PixScal;
  }

  AWAP_Comp->mosnaxis1 = (long)((AWAP_Const->Mosaic_SizeX /
                                 fabs(AWAP_Comp->moscdelt1)));

  AWAP_Comp->mosnaxis2 = (long)((AWAP_Const->Mosaic_SizeY /
                                 fabs(AWAP_Comp->moscdelt2)));

  AWAP_Comp->moscrpix1 = 0.5 * (AWAP_Comp->mosnaxis1 + 1.0);

  AWAP_Comp->moscrpix2 = 0.5 * (AWAP_Comp->mosnaxis2 + 1.0);


/*----------------------------------------------------------------------*/
/* Construct the output WCS header template for the mosaic cell grid as
   required by the two_plane initialization routine later. This is
   represented as a long string containing keywords and values in 80
   character blocks, just like in a regular FITS header. */

  if( AWAP_Stat->I_Verbose )
    printf("awaicgen_output_wcs: setting up the output WCS header %s\n",
           "template for the internal \"cell\" mosaic...");

  numwcslines = 15;

  AWAP_Comp->outwcsheader = (char *) calloc((numwcslines*80), sizeof(char));

  sprintf(line, "NAXIS   = %d", 2);
    stradd(AWAP_Comp->outwcsheader, line);
  sprintf(line, "NAXIS1  = %ld", AWAP_Comp->cellnaxis1);
    stradd(AWAP_Comp->outwcsheader, line);
  sprintf(line, "NAXIS2  = %ld", AWAP_Comp->cellnaxis2);
    stradd(AWAP_Comp->outwcsheader, line);
  sprintf(line, "CRVAL1  = %f", AWAP_Const->RA_center);
    stradd(AWAP_Comp->outwcsheader, line);
  sprintf(line, "CRVAL2  = %f", AWAP_Const->Dec_center);
    stradd(AWAP_Comp->outwcsheader, line);
  sprintf(line, "EQUINOX = %f", AWAP_Comp->imgequinox);
    stradd(AWAP_Comp->outwcsheader, line);
  sprintf(line, "CTYPE1  = %s", AWAP_Comp->imgctype1);
    stradd(AWAP_Comp->outwcsheader, line);
  sprintf(line, "CTYPE2  = %s", AWAP_Comp->imgctype2);
    stradd(AWAP_Comp->outwcsheader, line);
  sprintf(line, "CRPIX1  = %f", AWAP_Comp->cellcrpix1);
    stradd(AWAP_Comp->outwcsheader, line);
  sprintf(line, "CRPIX2  = %f", AWAP_Comp->cellcrpix2);
    stradd(AWAP_Comp->outwcsheader, line);
  sprintf(line, "CDELT1  = %20.16f", AWAP_Comp->cellcdelt1);
    stradd(AWAP_Comp->outwcsheader, line);
  sprintf(line, "CDELT2  = %20.16f", AWAP_Comp->cellcdelt2);
    stradd(AWAP_Comp->outwcsheader, line);
  sprintf(line, "CROTA2  = %f", AWAP_Const->Mosaic_Rot);
    stradd(AWAP_Comp->outwcsheader, line);
  sprintf(line, "END");
    stradd(AWAP_Comp->outwcsheader, line);

  if( AWAP_Stat->I_Verbose )
    printf("awaicgen_output_wcs: output WCS header structure for %s:\n %s\n",
           "reprojection onto upsampled cell grid", AWAP_Comp->outwcsheader);


/*----------------------------------------------------------------------*/
/* Construct the output WCS header template for the real mosaic grid (the
   output mask if specified) as required by the two_plane initialization
   routine later. This is represented as a long string containing keywords
   and values in 80 character blocks, just like in a regular FITS header. */

  if( AWAP_Const->want_msk ) {

    if( AWAP_Stat->I_Verbose )
      printf("awaicgen_output_wcs: setting up the output WCS header %s\n",
             "template for the real mosaic (specifically the output mask)...");

    numwcslines = 15;

    AWAP_Comp->outrwcsheader = (char *) calloc((numwcslines*80), sizeof(char));

    sprintf(line, "NAXIS   = %d", 2);
      stradd(AWAP_Comp->outrwcsheader, line);
    sprintf(line, "NAXIS1  = %ld", AWAP_Comp->mosnaxis1);
      stradd(AWAP_Comp->outrwcsheader, line);
    sprintf(line, "NAXIS2  = %ld", AWAP_Comp->mosnaxis2);
      stradd(AWAP_Comp->outrwcsheader, line);
    sprintf(line, "CRVAL1  = %f", AWAP_Const->RA_center);
      stradd(AWAP_Comp->outrwcsheader, line);
    sprintf(line, "CRVAL2  = %f", AWAP_Const->Dec_center);
      stradd(AWAP_Comp->outrwcsheader, line);
    sprintf(line, "EQUINOX = %f", AWAP_Comp->imgequinox);
      stradd(AWAP_Comp->outrwcsheader, line);
    sprintf(line, "CTYPE1  = %s", AWAP_Comp->imgctype1);
      stradd(AWAP_Comp->outrwcsheader, line);
    sprintf(line, "CTYPE2  = %s", AWAP_Comp->imgctype2);
      stradd(AWAP_Comp->outrwcsheader, line);
    sprintf(line, "CRPIX1  = %f", AWAP_Comp->moscrpix1);
      stradd(AWAP_Comp->outrwcsheader, line);
    sprintf(line, "CRPIX2  = %f", AWAP_Comp->moscrpix2);
      stradd(AWAP_Comp->outrwcsheader, line);
    sprintf(line, "CDELT1  = %20.16f", AWAP_Comp->moscdelt1);
      stradd(AWAP_Comp->outrwcsheader, line);
    sprintf(line, "CDELT2  = %20.16f", AWAP_Comp->moscdelt2);
      stradd(AWAP_Comp->outrwcsheader, line);
    sprintf(line, "CROTA2  = %f", AWAP_Const->Mosaic_Rot);
      stradd(AWAP_Comp->outrwcsheader, line);
    sprintf(line, "END");
      stradd(AWAP_Comp->outrwcsheader, line);

    if( AWAP_Stat->I_Verbose )
      printf("awaicgen_output_wcs: output WCS header structure for %s:\n %s\n",
             "the real (mask) mosaic grid", AWAP_Comp->outrwcsheader);
  }

  return 0;
}


/*----------------------------------------------------------------------*/
/* Subroutine to pad and concatenate strings for output WCS header
   template. */

  int stradd(char *header, char *card)
  {
    int i;
    int hlen = strlen(header);
    int clen = strlen(card);

    for(i=0; i<clen; ++i)
      header[hlen+i] = card[i];

    if(clen < 80)
      for(i=clen; i<80; ++i)
        header[hlen+i] = ' ';

    header[hlen+80] = '\0';

    return(strlen(header));
  }

