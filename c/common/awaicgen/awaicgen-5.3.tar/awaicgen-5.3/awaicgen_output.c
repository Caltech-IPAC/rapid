
/***********************************************
awaicgen_output.c

Purpose

Write the mosaic image products to FITS files.
Attach simple FITS headers (mainly WCS keywords)
written to / read from a temporary keywords file.
Free memory in output arrays at end.

***********************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include "fitsio.h"
#include "awaicgen.h"
#include "awaicgen_defs.h"

int awaicgen_output(AWA_Constants     *AWAP_Const,
             AWA_Filenames     *AWAP_Fnames,
             AWA_Computation   *AWAP_Comp,
             AWA_Impix         *AWAP_Impix,
             AWA_Status        *AWAP_Stat)
{
  char     comment[STRING_BUFFER_SIZE];
  char     keysfile[STRING_BUFFER_SIZE];
  FILE     *tmp;

  long     naxis, naxes[2];
  long     i, fimgpix[2];
  int      status=0;
  extern int errno;

  fitsfile *ffp_FITS_Out;


  if(AWAP_Stat->I_status)
    return 0;

/*----------------------------------------------------------------------*/
/* Construct a simple FITS header template file containing main WCS
   keywords. Write as a text file and delete at end. */

  strcpy(keysfile,AWAP_Fnames->Filename_Output_Mosaic);
  strcat(keysfile,"_keywords.txt");
  if(keysfile[0] == '!')
    memmove(keysfile, keysfile+1, strlen(keysfile));

  if( (tmp = fopen(keysfile,"w")) == NULL) {
    fprintf(stderr,"*** Error: awaicgen_output: could not create %s; %s\n",
            keysfile, "quitting...");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose )
      printf("awaicgen_output: created FITS header template file: %s\n",
             keysfile);
  }


/*----------------------------------------------------------------------*/
/* Write FITS keywords/comments to keywords template file. */

  sprintf(comment, "%s, J%6.1f (deg)",
                   "RA at CRPIX1,CRPIX2", AWAP_Comp->imgequinox);
  fprintf(tmp, "CRVAL1  = %f / %s\n", AWAP_Const->RA_center, comment);

  sprintf(comment, "%s, J%6.1f (deg)",
                   "Dec at CRPIX1,CRPIX2", AWAP_Comp->imgequinox);
  fprintf(tmp, "CRVAL2  = %f / %s\n", AWAP_Const->Dec_center, comment);

  sprintf(comment, "%s, (%s)", "Equinox of WCS", "year");
  fprintf(tmp, "EQUINOX = %6.1f / %s\n", AWAP_Comp->imgequinox, comment);

  sprintf(comment, "%s", "Projection type for axis 1");
  fprintf(tmp, "CTYPE1  = %s / %s\n", AWAP_Comp->imgctype1, comment);

  sprintf(comment, "%s", "Projection type for axis 2");
  fprintf(tmp, "CTYPE2  = %s / %s\n", AWAP_Comp->imgctype2, comment);

  sprintf(comment, "%s", "Axis 1 reference pixel at CRVAL1,CRVAL2");
  fprintf(tmp, "CRPIX1  = %f / %s\n", AWAP_Comp->moscrpix1, comment);

  sprintf(comment, "%s", "Axis 2 reference pixel at CRVAL1,CRVAL2");
  fprintf(tmp, "CRPIX2  = %f / %s\n", AWAP_Comp->moscrpix2, comment);

  sprintf(comment, "%s", "Axis 1 scale at CRPIX1,CRPIX2 (deg/pix)");
  fprintf(tmp, "CDELT1  = %20.16f / %s\n", AWAP_Comp->moscdelt1, comment);

  sprintf(comment, "%s", "Axis 2 scale at CRPIX1,CRPIX2 (deg/pix)");
  fprintf(tmp, "CDELT2  = %20.16f / %s\n", AWAP_Comp->moscdelt2, comment);

  sprintf(comment, "%s, J%6.1f (deg)",
                   "Image twist: +axis2 W of N", AWAP_Comp->imgequinox);
  fprintf(tmp, "CROTA2  = %f / %s\n", AWAP_Const->Mosaic_Rot, comment);

  sprintf(comment, "%s", "Fatal bitstring mask template");
  fprintf(tmp, "BITMASK = %d / %s\n", AWAP_Const->Fatal_Bits, comment);

  fprintf(tmp, "HISTORY %s, v%2.1f\n", PURPOSE, VERSN);
  fprintf(tmp, "HISTORY %s\n", PERSON);

  if( fclose(tmp) ) {
    fprintf(stderr,"*** Error: awaicgen_output: keywords file %s; error: %s\n",
            "could not be closed", strerror(errno));
    AWAP_Stat->I_status = 1;
    return 0;
  }


/*----------------------------------------------------------------------*/
/* Initializations and set-up for all output FITS images. */

  naxis = 2;

  naxes[0] = AWAP_Comp->mosnaxis1;

  naxes[1] = AWAP_Comp->mosnaxis2;

  fimgpix[0] = 1;  /* starting pixel in column dim. to write out. */

  fimgpix[1] = 1;  /* starting pixel in row dim. to write out.    */


/*----------------------------------------------------------------------*/
/* Create and write out the main mosaic image in FITS file format. */

  if( AWAP_Stat->I_Verbose )
    printf("awaicgen_output: creating/writing FITS file for output %s: %s %s\n",
           "mosaic image", AWAP_Fnames->Filename_Output_Mosaic, "...");

  fits_create_file(&ffp_FITS_Out, AWAP_Fnames->Filename_Output_Mosaic,
                   &status);

  if( status ) {
    fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
            "creating FITS file:", AWAP_Fnames->Filename_Output_Mosaic,
            "FITS error code =", status);
    AWAP_Stat->I_status = 1;
    return 0;
  }

  fits_create_img(ffp_FITS_Out, FLOAT_IMG, naxis, naxes, &status);

  if( status ) {
    fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
            "creating FITS file image:", AWAP_Fnames->Filename_Output_Mosaic,
            "FITS error code =", status);
    AWAP_Stat->I_status = 1;
    return 0;
  }

  fits_write_key_template(ffp_FITS_Out, keysfile, &status);

  if( status ) {
    fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
            "writing keywords from template file:", keysfile,
            "FITS error code =", status);
    AWAP_Stat->I_status = 1;
    return 0;
  }

  for(fimgpix[1] = 1; fimgpix[1] <= naxes[1]; fimgpix[1]++) {

    fits_write_pix(ffp_FITS_Out, TFLOAT, fimgpix, naxes[0],
                   AWAP_Comp->mos_pix_array[fimgpix[1] - 1], &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "writing pixels to:", AWAP_Fnames->Filename_Output_Mosaic,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  fits_write_date(ffp_FITS_Out, &status);

  if( status ) {
    fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
            "writing date to FITS file:", AWAP_Fnames->Filename_Output_Mosaic,
            "FITS error code =", status);
    AWAP_Stat->I_status = 1;
    return 0;
  }

  fits_close_file(ffp_FITS_Out, &status);

  if( status ) {
    fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
            "closing FITS file:", AWAP_Fnames->Filename_Output_Mosaic,
            "FITS error code =", status);
    AWAP_Stat->I_status = 1;
    return 0;
  }


/*----------------------------------------------------------------------*/
/* Create and write out the mosaic coverage-map in FITS file format. */

if( strcmp(AWAP_Fnames->Filename_Output_Coverage,"") ) {

  if( AWAP_Stat->I_Verbose )
    printf("awaicgen_output: creating/writing FITS file for output %s: %s %s\n",
           "coverage image", AWAP_Fnames->Filename_Output_Coverage, "...");

  fits_create_file(&ffp_FITS_Out, AWAP_Fnames->Filename_Output_Coverage,
                   &status);

  if( status ) {
    fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
            "creating FITS file:", AWAP_Fnames->Filename_Output_Coverage,
            "FITS error code =", status);
    AWAP_Stat->I_status = 1;
    return 0;
  }

  fits_create_img(ffp_FITS_Out, FLOAT_IMG, naxis, naxes, &status);

  if( status ) {
    fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
            "creating FITS file image:", AWAP_Fnames->Filename_Output_Coverage,
            "FITS error code =", status);
    AWAP_Stat->I_status = 1;
    return 0;
  }

  fits_write_key_template(ffp_FITS_Out, keysfile, &status);

  if( status ) {
    fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
            "writing keywords from template file:", keysfile,
            "FITS error code =", status);
    AWAP_Stat->I_status = 1;
    return 0;
  }

  for(fimgpix[1] = 1; fimgpix[1] <= naxes[1]; fimgpix[1]++) {

    fits_write_pix(ffp_FITS_Out, TFLOAT, fimgpix, naxes[0],
                   AWAP_Comp->mos_cov_array[fimgpix[1] - 1], &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "writing pixels to:", AWAP_Fnames->Filename_Output_Coverage,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  fits_write_date(ffp_FITS_Out, &status);

  if( status ) {
    fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
            "writing date to FITS file:", AWAP_Fnames->Filename_Output_Mosaic,
            "FITS error code =", status);
    AWAP_Stat->I_status = 1;
    return 0;
  }

  fits_close_file(ffp_FITS_Out, &status);

  if( status ) {
    fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
            "closing FITS file:", AWAP_Fnames->Filename_Output_Coverage,
            "FITS error code =", status);
    AWAP_Stat->I_status = 1;
    return 0;
  }
}

/*----------------------------------------------------------------------*/
/* Create and write out the mosaic uncertainty image in FITS file format
   if filename was specified on input (NB: this product is only valid
   for Num_Iter = 1 mosaic/co-add). */

  if( strcmp(AWAP_Fnames->Filename_Output_Uncert,"") ) {

    if( AWAP_Stat->I_Verbose )
      printf("awaicgen_output: creating/writing FITS file for output %s: %s %s\n",
             "mosaic uncertainty image",
             AWAP_Fnames->Filename_Output_Uncert, "...");

    fits_create_file(&ffp_FITS_Out, AWAP_Fnames->Filename_Output_Uncert,
                     &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "creating FITS file:", AWAP_Fnames->Filename_Output_Uncert,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    fits_create_img(ffp_FITS_Out, FLOAT_IMG, naxis, naxes, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "creating FITS file image:", AWAP_Fnames->Filename_Output_Uncert,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    fits_write_key_template(ffp_FITS_Out, keysfile, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "writing keywords from template file:", keysfile,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    for(fimgpix[1] = 1; fimgpix[1] <= naxes[1]; fimgpix[1]++) {

      fits_write_pix(ffp_FITS_Out, TFLOAT, fimgpix, naxes[0],
                     AWAP_Comp->mos_sig_array[fimgpix[1] - 1], &status);

      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
                "writing pixels to:", AWAP_Fnames->Filename_Output_Uncert,
                "FITS error code =", status);
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }

    fits_write_date(ffp_FITS_Out, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "writing date to FITS file:",
              AWAP_Fnames->Filename_Output_Uncert,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    fits_close_file(ffp_FITS_Out, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "closing FITS file:", AWAP_Fnames->Filename_Output_Uncert,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }


/*----------------------------------------------------------------------*/
/* Create and write out the standard-deviation mosaic in FITS format if
   output filename and simple-coadd creation flag was specified on input. */

  if( strcmp(AWAP_Fnames->Filename_Output_Stddev,"") &&
      AWAP_Const->Simple_Flag ) {

    if( AWAP_Stat->I_Verbose )
      printf("awaicgen_output: creating/writing FITS file for output %s: %s %s\n",
             "mosaic uncertainty image",
             AWAP_Fnames->Filename_Output_Stddev, "...");

    fits_create_file(&ffp_FITS_Out, AWAP_Fnames->Filename_Output_Stddev,
                     &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "creating FITS file:", AWAP_Fnames->Filename_Output_Stddev,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    fits_create_img(ffp_FITS_Out, FLOAT_IMG, naxis, naxes, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "creating FITS file image:", AWAP_Fnames->Filename_Output_Stddev,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    fits_write_key_template(ffp_FITS_Out, keysfile, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "writing keywords from template file:", keysfile,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    for(fimgpix[1] = 1; fimgpix[1] <= naxes[1]; fimgpix[1]++) {

      fits_write_pix(ffp_FITS_Out, TFLOAT, fimgpix, naxes[0],
                     AWAP_Comp->mos_std_array[fimgpix[1] - 1], &status);

      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
                "writing pixels to:", AWAP_Fnames->Filename_Output_Stddev,
                "FITS error code =", status);
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }

    fits_write_date(ffp_FITS_Out, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "writing date to FITS file:",
              AWAP_Fnames->Filename_Output_Stddev,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    fits_close_file(ffp_FITS_Out, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "closing FITS file:", AWAP_Fnames->Filename_Output_Stddev,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }


/*----------------------------------------------------------------------*/
/* Create and write out the MCM correction-factor mosaic in FITS format if
   output filename was specified. */

  if( AWAP_Const->want_corr ) {

    if( AWAP_Stat->I_Verbose )
      printf("awaicgen_output: creating/writing FITS file for output %s: %s %s\n",
             "MCM correction-factor image",
             AWAP_Fnames->Filename_Output_Corr, "...");

    fits_create_file(&ffp_FITS_Out, AWAP_Fnames->Filename_Output_Corr,
                     &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "creating FITS file:", AWAP_Fnames->Filename_Output_Corr,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    fits_create_img(ffp_FITS_Out, FLOAT_IMG, naxis, naxes, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "creating FITS file image:", AWAP_Fnames->Filename_Output_Corr,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    fits_write_key_template(ffp_FITS_Out, keysfile, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "writing keywords from template file:", keysfile,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    for(fimgpix[1] = 1; fimgpix[1] <= naxes[1]; fimgpix[1]++) {

      fits_write_pix(ffp_FITS_Out, TFLOAT, fimgpix, naxes[0],
                     AWAP_Comp->mos_cor_array[fimgpix[1] - 1], &status);

      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
                "writing pixels to:", AWAP_Fnames->Filename_Output_Corr,
                "FITS error code =", status);
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }

    fits_write_date(ffp_FITS_Out, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "writing date to FITS file:",
              AWAP_Fnames->Filename_Output_Corr,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    fits_close_file(ffp_FITS_Out, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "closing FITS file:", AWAP_Fnames->Filename_Output_Corr,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }


/*----------------------------------------------------------------------*/
/* Create and write out the MCM uncertainty mosaic (from CFV) in FITS format
   if output filename was specified. */

  if( AWAP_Const->want_cffv ) {

    if( AWAP_Stat->I_Verbose )
      printf("awaicgen_output: creating/writing FITS file for output %s: %s %s\n",
             "MCM uncertainty mosaic (from CFV)",
             AWAP_Fnames->Filename_Output_CFVUncert, "...");

    fits_create_file(&ffp_FITS_Out, AWAP_Fnames->Filename_Output_CFVUncert,
                     &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "creating FITS file:", AWAP_Fnames->Filename_Output_CFVUncert,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    fits_create_img(ffp_FITS_Out, FLOAT_IMG, naxis, naxes, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "creating FITS file image:",
              AWAP_Fnames->Filename_Output_CFVUncert,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    fits_write_key_template(ffp_FITS_Out, keysfile, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "writing keywords from template file:", keysfile,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    for(fimgpix[1] = 1; fimgpix[1] <= naxes[1]; fimgpix[1]++) {

      fits_write_pix(ffp_FITS_Out, TFLOAT, fimgpix, naxes[0],
                     AWAP_Comp->mos_cfv_array[fimgpix[1] - 1], &status);

      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
                "writing pixels to:", AWAP_Fnames->Filename_Output_CFVUncert,
                "FITS error code =", status);
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }

    fits_write_date(ffp_FITS_Out, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "writing date to FITS file:",
              AWAP_Fnames->Filename_Output_CFVUncert,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    fits_close_file(ffp_FITS_Out, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "closing FITS file:", AWAP_Fnames->Filename_Output_CFVUncert,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }


/*----------------------------------------------------------------------*/
/* Create and write out the first iteration intensity mosaic in FITS format
   if output filename specified and n_iter > 1. */

  if( strcmp(AWAP_Fnames->Filename_Output_MosaicFIter,"") &&
      (AWAP_Const->Num_Iter > 1) ) {

    if( AWAP_Stat->I_Verbose )
      printf("awaicgen_output: creating/writing FITS file for output %s: %s %s\n",
             "MCM first iteration intensity mosaic",
             AWAP_Fnames->Filename_Output_MosaicFIter, "...");

    fits_create_file(&ffp_FITS_Out, AWAP_Fnames->Filename_Output_MosaicFIter,
                     &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "creating FITS file:", AWAP_Fnames->Filename_Output_MosaicFIter,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    fits_create_img(ffp_FITS_Out, FLOAT_IMG, naxis, naxes, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "creating FITS file image:",
              AWAP_Fnames->Filename_Output_MosaicFIter,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    fits_write_key_template(ffp_FITS_Out, keysfile, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "writing keywords from template file:", keysfile,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    for(fimgpix[1] = 1; fimgpix[1] <= naxes[1]; fimgpix[1]++) {

      fits_write_pix(ffp_FITS_Out, TFLOAT, fimgpix, naxes[0],
                     AWAP_Comp->mos_fitr_array[fimgpix[1] - 1], &status);

      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
                "writing pixels to:", AWAP_Fnames->Filename_Output_MosaicFIter,
                "FITS error code =", status);
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }

    fits_write_date(ffp_FITS_Out, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "writing date to FITS file:",
              AWAP_Fnames->Filename_Output_MosaicFIter,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    fits_close_file(ffp_FITS_Out, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "closing FITS file:", AWAP_Fnames->Filename_Output_MosaicFIter,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }


/*----------------------------------------------------------------------*/
/* Create and write out the mask mosaic in FITS format for n_iter = 1 and
  if output filename was specified. */

  if( AWAP_Const->want_msk ) {

    if( AWAP_Stat->I_Verbose )
      printf("awaicgen_output: creating/writing FITS file for output %s: %s %s\n",
             "mask mosaic",
             AWAP_Fnames->Filename_Output_MosaicMsk, "...");

    fits_create_file(&ffp_FITS_Out, AWAP_Fnames->Filename_Output_MosaicMsk,
                     &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "creating FITS file:", AWAP_Fnames->Filename_Output_MosaicMsk,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    fits_create_img(ffp_FITS_Out, BYTE_IMG, naxis, naxes, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "creating FITS file image:",
              AWAP_Fnames->Filename_Output_MosaicMsk,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    fits_write_key_template(ffp_FITS_Out, keysfile, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "writing keywords from template file:", keysfile,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    for(fimgpix[1] = 1; fimgpix[1] <= naxes[1]; fimgpix[1]++) {

      fits_write_pix(ffp_FITS_Out, TBYTE, fimgpix, naxes[0],
                     AWAP_Impix->mos_msk_array[fimgpix[1] - 1], &status);

      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
                "writing pixels to:", AWAP_Fnames->Filename_Output_MosaicMsk,
                "FITS error code =", status);
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }

    fits_write_date(ffp_FITS_Out, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "writing date to FITS file:",
              AWAP_Fnames->Filename_Output_MosaicMsk,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }

    fits_close_file(ffp_FITS_Out, &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_output: error %s %s; %s %d\n",
              "closing FITS file:", AWAP_Fnames->Filename_Output_MosaicMsk,
              "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }


/*----------------------------------------------------------------------*/
/* Delete the keywords header template file and free remaining memory. */

  if( unlink(keysfile) ) {
    fprintf(stderr,"*** Error: awaicgen_output: keywords file (%s) %s\n",
            keysfile, "could not be deleted; quitting...");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose )
      printf("awaicgen_output: deleted keywords FITS header template file: %s\n",
             keysfile);
  }

  for( i = 0; i < AWAP_Comp->mosnaxis2; i++ )
    free( AWAP_Comp->mos_pix_array[i] );

  free( AWAP_Comp->mos_pix_array );

  for( i = 0; i < AWAP_Comp->mosnaxis2; i++ )
    free( AWAP_Comp->mos_cov_array[i] );

  free( AWAP_Comp->mos_cov_array );

  if( strcmp(AWAP_Fnames->Filename_Output_Uncert,"") ) {
    for( i = 0; i < AWAP_Comp->mosnaxis2; i++ )
      free( AWAP_Comp->mos_sig_array[i] );

    free( AWAP_Comp->mos_sig_array );
  }

  if( strcmp(AWAP_Fnames->Filename_Output_Stddev,"") &&
      AWAP_Const->Simple_Flag ) {
    for( i = 0; i < AWAP_Comp->mosnaxis2; i++ )
      free( AWAP_Comp->mos_std_array[i] );

    free( AWAP_Comp->mos_std_array );
  }

  if( AWAP_Const->want_corr ) {
    for( i = 0; i < AWAP_Comp->mosnaxis2; i++ )
      free( AWAP_Comp->mos_cor_array[i] );

    free( AWAP_Comp->mos_cor_array );
  }

  if( AWAP_Const->want_cffv ) {
    for( i = 0; i < AWAP_Comp->mosnaxis2; i++ )
      free( AWAP_Comp->mos_cfv_array[i] );

    free( AWAP_Comp->mos_cfv_array );
  }

  if( AWAP_Const->want_msk ) {
    for( i = 0; i < AWAP_Comp->mosnaxis2; i++ )
      free( AWAP_Impix->mos_msk_array[i] );

    free( AWAP_Impix->mos_msk_array );
  }

  if( strcmp(AWAP_Fnames->Filename_Output_MosaicFIter,"") &&
      (AWAP_Const->Num_Iter > 1) ) {
    for( i = 0; i < AWAP_Comp->mosnaxis2; i++ )
      free( AWAP_Comp->mos_fitr_array[i] );

    free( AWAP_Comp->mos_fitr_array );
  }

  return 0;
}
