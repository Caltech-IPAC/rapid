
/***********************************************
awaicgen_compute_hirespix.c

Purpose

Contains function to support multi-threading for
HiRes processing called from awaicgen_compute_results_hires.c
Threading is performed over detector pixels of an
input image, with implicit use of PRF as interpolation
kernel.

***********************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "awaicgen.h"
#include "awaicgen_defs.h"
#include "wcs.h"
#include "two_plane.h"
#include "distort.h"

void awaicgen_compute_hirespix(AWA_Impix         *AWAP_Impix)
{
  float   **mos_cell_array;
  float   **Cnum_j;
  float   **NV_j;
  float   **NSV_j;
  float   **N_j;
  float   **CFFV_j;
  float   **imgdata;
  float   **uncdata;
  long    **mskdata;

  float   D_i, D_x, D_y, M_i, V_i, S_i, ChiVar_i;
  float   F_i, C_i, PRF_i;
  float   prf_x, prf_y, prf, outin_area_ratio;
  float   prf_x1, prf_y1, prf_x2, prf_y2;
  float   prf_x3, prf_y3, prf_x4, prf_y4;

  double  Corn_Ax, Corn_Bx, Corn_Cx, Corn_Dx;
  double  Corn_Ay, Corn_By, Corn_Cy, Corn_Dy;
  double  C_Node_x, C_Node_y, Area_A, Area_B, Area_C, Area_D, checksum;
  double  CD_x, CD_y, cos_theta, sin_theta;

  long    i, ii, j, jj, k, po;
  long    C_PRF_x, C_PRF_y;
  long    C_PRF_x1, C_PRF_y1, C_PRF_x2, C_PRF_y2;
  long    C_PRF_x3, C_PRF_y3, C_PRF_x4, C_PRF_y4;
  long    C_PRF_xA, C_PRF_xB, C_PRF_xC, C_PRF_xD;
  long    C_PRF_yA, C_PRF_yB, C_PRF_yC, C_PRF_yD;

  int     n, p, pp, offscl;
  int     loc_i, loc_j, locindex;
  int     Off_Ax, Off_Bx, Off_Cx, Off_Dx;
  int     Off_Ay, Off_By, Off_Cy, Off_Dy;
  int     maxoffset=0;

  /* Store global/structure variables into local variables. */

  mos_cell_array = AWAP_Impix->mos_cell_array;
  Cnum_j = AWAP_Impix->Cnum_j;
  NV_j = AWAP_Impix->NV_j;
  NSV_j = AWAP_Impix->NSV_j;
  N_j = AWAP_Impix->N_j;
  CFFV_j = AWAP_Impix->CFFV_j;
  imgdata = AWAP_Impix->imgdata;
  uncdata = AWAP_Impix->uncdata;
  mskdata = AWAP_Impix->mskdata;

  if( AWAP_Impix->st.I_Verbose )
    printf("awaicgen_compute_hirespix: thread %d: %s %ld <= k <= %ld\n",
           AWAP_Impix->threadid,"1D pixel index range to process:",
           AWAP_Impix->kstart,AWAP_Impix->kend);

/*----------------------------------------------------------------------*/
/* For each detector pixel (D_x, D_y) in input image m, transform to
   mosaic cell grid frame =(CD_x, CD_y) using fast WCS projection.
   Then transform native PRF coords centered at this pixel to mosaic
   cell grid using linear transformation and round to nearest integer
   cell pixel. Beware that PRF is not transformed using full non-linear
   WCS transformation from input image to mosaic plane. For large
   mosaics, there could be an inaccurate representation of the PRF
   flux distribution towards mosaic edges. */

  cos_theta = cos(AWAP_Impix->theta_m);
  sin_theta = sin(AWAP_Impix->theta_m);

  /* initialize counter for number of good (unmasked and on-footprint)
     detector pixels used from image m. Also initialize chi-square
     metric for image m, iteration Num_Iter and number of input image
     pixels processed. */

  AWAP_Impix->NumGoodD_i = 0;
  AWAP_Impix->chisq_m = 0;
  po = 0;

  for(ii = AWAP_Impix->iistart; ii <= AWAP_Impix->iiend; ii++) {
    for(i = 0; i < AWAP_Impix->cp.imgnaxis1; i++) {

     k = (ii * AWAP_Impix->cp.imgnaxis1) + i;
     if( (k >= AWAP_Impix->kstart) && (k <= AWAP_Impix->kend) ) {

      po++;

      /* measured flux in detector pixel at (x,y) = (i+1,ii+1). */

      D_i = imgdata[ii][i];

      /* use appropriate FPA-position dependent PRF from input list
         according to x,y location of detector pixel. */

      locindex = 0;

      if( AWAP_Impix->cp.numprfs > 1 ) {
        loc_i = (int)(i * (float)(AWAP_Impix->cp.prfgriddim)/
                (float)(AWAP_Impix->cp.imgnaxis1));

        loc_j = (int)(ii * (float)(AWAP_Impix->cp.prfgriddim)/
                (float)(AWAP_Impix->cp.imgnaxis2));

        locindex = AWAP_Impix->cp.prflistind[loc_j][loc_i];
      }

      /*
      printf("DBG: Using PRF %d for image pixel x,y = %ld,%ld (val = %f)\n",
             locindex, i+1, ii+1, D_i);
      */

      /* initialize variances to 1 in case input uncertainties
         not given, otherwise use input for detector pixel at
         (x,y) = (i+1,ii+1). */

      V_i = 1.0;
      S_i = 1.0;

      if( AWAP_Impix->co.have_uncert && AWAP_Impix->co.Weight_Flag )
        V_i = uncdata[ii][i] * uncdata[ii][i];

      /* Following is for n = 1 uncertainty estimation with no
         inverse variance weighting, i.e., Weight_Flag = 0. */

      if( AWAP_Impix->co.have_uncert && !AWAP_Impix->co.Weight_Flag )
        S_i = uncdata[ii][i] * uncdata[ii][i];

      /* initialize mask value to "not masked", otherwise, if input
         masks specified, use specific mask value for detector pixel
         at (x,y) = (i+1,ii+1). */

      M_i = 0.0;

      if( AWAP_Impix->co.have_masks )
        if( mskdata[ii][i] & AWAP_Impix->co.Fatal_Bits )
          M_i = 1.0;

      /* if input pixel D_i or variances V_i, S_i are NaNs or zero
         (regardless if input masks were specified), mask it! */

      if( (D_i != D_i) || (V_i != V_i) || (V_i == 0.0) || (S_i != S_i) )
        M_i = 1.0;

      /* only reproject and co-add input pixel D_i if it is not masked
         and not NaN'd. */

      if( M_i != 1.0 ) {

        D_x = i + 1.0;
        D_y = ii + 1.0;

        /* Project (D_x, D_y) to mosaic cell frame: out = (CD_x, CD_y). */

        offscl = plane1_to_plane2_transform(D_x, D_y, &CD_x, &CD_y,
                                            &AWAP_Impix->twoplane);

        /*
        printf("DBG: offscl=%d, D_x=%f,D_y=%f CD_x=%f, CD_y=%f\n",
               offscl,D_x,D_y,CD_x,CD_y);
        */

        if( !offscl ) {

          AWAP_Impix->ProjectionStatus = 1;

          /* initialize simulated detector flux. Set F_i = 1 if we are
             only after simple N_iter = 1 co-add so that C_i = D_i below
             and bypass computation of "predicted" detector pixel
             flux F_i. But if non-flat prior input specified, compute F_i
             if N_iter = 1. Sum the contributing PRF values that fall
             inside cell-grid, and renormalize F_i at end to account
             for detector pixels whose PRFs overlap with cell boundary. */

          F_i = 1.0;

          if( (AWAP_Impix->co.Num_Iter > 1) ||
              (strcmp(AWAP_Impix->fn.Filename_Input_MosaicCell,"") &&
              (AWAP_Impix->co.Num_Iter == 1)) ) {

            F_i = 0.0;

            PRF_i = 0.0;

            for( pp = 0; pp < AWAP_Impix->cp.prfnaxis2; pp++ ) {
              for( p = 0; p < AWAP_Impix->cp.prfnaxis1; p++ ) {

                prf_x = p + 1.0;
                prf_y = pp + 1.0;

                prf = AWAP_Impix->cp.prfdata[locindex]
                                            [(pp*AWAP_Impix->cp.prfnaxis1)+p];

                /* Transform PRF coords to mosaic cell coords using local
                   Cartesian transformation and round to nearest integer.
                   If RotPRF_Flag = 1 use full rotation matrix, otherwise
                   use default nearest neighbor interpolation with no
                   rotation and PRF pixels aligned with cell grid.
                   Since rotation will spread out PRF pixels in cell grid
                   (target) frame, a straight nearest neighbor match will
                   miss some target pixels. Hence, divide PRF pixels into
                   2 x 2 sub-pixels and then transform these. */

                if( AWAP_Impix->co.RotPRF_Flag ) {

                  prf_x1 = prf_x - 0.25; prf_y1 = prf_y - 0.25;
                  prf_x2 = prf_x1;       prf_y2 = prf_y + 0.25;
                  prf_x3 = prf_x + 0.25; prf_y3 = prf_y2;
                  prf_x4 = prf_x3;       prf_y4 = prf_y1;

                  C_PRF_x = (long)(CD_x +
                            (prf_x - AWAP_Impix->cp.prfcrpix1)*cos_theta -
                            (prf_y - AWAP_Impix->cp.prfcrpix2)*sin_theta
                             + 0.5);

                  C_PRF_y = (long)(CD_y +
                            (prf_x - AWAP_Impix->cp.prfcrpix1)*sin_theta +
                            (prf_y - AWAP_Impix->cp.prfcrpix2)*cos_theta
                             + 0.5);

                  C_PRF_x = (long)(CD_x +
                            (prf_x - AWAP_Impix->cp.prfcrpix1)*cos_theta -
                            (prf_y - AWAP_Impix->cp.prfcrpix2)*sin_theta
                             + 0.5);

                  C_PRF_y = (long)(CD_y +
                            (prf_x - AWAP_Impix->cp.prfcrpix1)*sin_theta +
                            (prf_y - AWAP_Impix->cp.prfcrpix2)*cos_theta
                             + 0.5);

                  C_PRF_x1 = (long)(CD_x +
                             (prf_x1 - AWAP_Impix->cp.prfcrpix1)*cos_theta -
                             (prf_y1 - AWAP_Impix->cp.prfcrpix2)*sin_theta
                              + 0.5);

                  C_PRF_y1 = (long)(CD_y +
                             (prf_x1 - AWAP_Impix->cp.prfcrpix1)*sin_theta +
                             (prf_y1 - AWAP_Impix->cp.prfcrpix2)*cos_theta
                              + 0.5);

                  C_PRF_x2 = (long)(CD_x +
                             (prf_x2 - AWAP_Impix->cp.prfcrpix1)*cos_theta -
                             (prf_y2 - AWAP_Impix->cp.prfcrpix2)*sin_theta
                              + 0.5);

                  C_PRF_y2 = (long)(CD_y +
                             (prf_x2 - AWAP_Impix->cp.prfcrpix1)*sin_theta +
                             (prf_y2 - AWAP_Impix->cp.prfcrpix2)*cos_theta
                              + 0.5);

                  C_PRF_x3 = (long)(CD_x +
                             (prf_x3 - AWAP_Impix->cp.prfcrpix1)*cos_theta -
                             (prf_y3 - AWAP_Impix->cp.prfcrpix2)*sin_theta
                              + 0.5);

                  C_PRF_y3 = (long)(CD_y +
                             (prf_x3 - AWAP_Impix->cp.prfcrpix1)*sin_theta +
                             (prf_y3 - AWAP_Impix->cp.prfcrpix2)*cos_theta
                              + 0.5);

                  C_PRF_x4 = (long)(CD_x +
                             (prf_x4 - AWAP_Impix->cp.prfcrpix1)*cos_theta -
                             (prf_y4 - AWAP_Impix->cp.prfcrpix2)*sin_theta
                              + 0.5);

                  C_PRF_y4 = (long)(CD_y +
                             (prf_x4 - AWAP_Impix->cp.prfcrpix1)*sin_theta +
                             (prf_y4 - AWAP_Impix->cp.prfcrpix2)*cos_theta
                              + 0.5);

                  maxoffset = 1;

                } else {

                  /* No rotation of PRF. Always aligned with cell grid. */

                  C_PRF_x = (long)(CD_x + (prf_x - AWAP_Impix->cp.prfcrpix1) +
                                   0.5);

                  C_PRF_y = (long)(CD_y + (prf_y - AWAP_Impix->cp.prfcrpix2) +
                                   0.5);
                }

                /* multiply PRF value in mosaic cell j with overlapping
                   model (coadd) flux f_j and increment sum to compute
                   "simulated" detector flux. */

                if( (C_PRF_x - maxoffset >= 1) &&
                    (C_PRF_y - maxoffset >= 1) &&
                    (C_PRF_x + maxoffset <= AWAP_Impix->cp.cellnaxis1) &&
                    (C_PRF_y + maxoffset <= AWAP_Impix->cp.cellnaxis2) ) {

                  if( !AWAP_Impix->co.RotPRF_Flag ) {

                    F_i += prf * mos_cell_array[C_PRF_y - 1][C_PRF_x - 1];

                  } else {

                    /* Under PRF rotation case, PRF subpixels have an
                       effective response of a quarter of originals. */

                    F_i += 0.25 * prf *
                          (mos_cell_array[C_PRF_y1 - 1][C_PRF_x1 - 1] +
                           mos_cell_array[C_PRF_y2 - 1][C_PRF_x2 - 1] +
                           mos_cell_array[C_PRF_y3 - 1][C_PRF_x3 - 1] +
                           mos_cell_array[C_PRF_y4 - 1][C_PRF_x4 - 1]);
                  }

                  PRF_i += prf;
                }

              } /* end of loop for x pos. of PRF cell corres. to D_i. */

            } /* end of loop for y pos. of PRF cell corres. to D_i. */

            /* Renormalize predicted flux due to possibility of PRF
               falling outside cell-grid boundary. */

            F_i /= PRF_i;

          } /* end of if( Num_Iter > 1 ) statement. */

          /*----------*/
          /* Correction factor for detector pixel:
             C_i = measured flux / simulated flux.
             Note, C_i = D_i if Num_Iter = 1 => simple co-add. */

          C_i = D_i / F_i;

          /*----------*/
          /* Set-up for area-overlap interpolation method for use in
             PRF pixel looping below. These quantities are generic
             to all PRF pixels for a given projected detector pixel.
             Under this method, PRF and cell pixels are always aligned. */

          if( AWAP_Impix->co.Interp_Method == 1 ) {

            /* True coords of the PRF corners in cell grid. */

            Corn_Ax = CD_x - 0.5; Corn_Ay = CD_y - 0.5;
            Corn_Bx = CD_x + 0.5; Corn_By = CD_y - 0.5;
            Corn_Cx = CD_x - 0.5; Corn_Cy = CD_y + 0.5;
            Corn_Dx = CD_x + 0.5; Corn_Dy = CD_y + 0.5;

            /* Offsets in integer cell pixels where corners fall relative
               to primary integer cell pixel containing CD_x, CD_y.
               These offsets will apply to all PRF pixels relative to
               their underlying cell grid pixels for a given detector
               pixel. Will be different for other detector pixels due
               to distortion. */

            Off_Ax = (long)(CD_x + 0.5) - (long)(Corn_Ax + 0.5);
            Off_Ay = (long)(CD_y + 0.5) - (long)(Corn_Ay + 0.5);

            Off_Bx = (long)(CD_x + 0.5) - (long)(Corn_Bx + 0.5);
            Off_By = (long)(CD_y + 0.5) - (long)(Corn_By + 0.5);

            Off_Cx = (long)(CD_x + 0.5) - (long)(Corn_Cx + 0.5);
            Off_Cy = (long)(CD_y + 0.5) - (long)(Corn_Cy + 0.5);

            Off_Dx = (long)(CD_x + 0.5) - (long)(Corn_Dx + 0.5);
            Off_Dy = (long)(CD_y + 0.5) - (long)(Corn_Dy + 0.5);

            maxoffset = 1;

            /* Coords of the (cross) node separating the
               four neighboring cell pixels. */

            C_Node_x = fmin(fmin((long)(Corn_Ax + 0.5),
                                 (long)(Corn_Bx + 0.5)),
                            fmin((long)(Corn_Cx + 0.5),
                                 (long)(Corn_Dx + 0.5))) + 0.5;

            C_Node_y = fmin(fmin((long)(Corn_Ay + 0.5),
                                 (long)(Corn_By + 0.5)),
                            fmin((long)(Corn_Cy + 0.5),
                                 (long)(Corn_Dy + 0.5))) + 0.5;

            /* Overlap areas (unit normalized) between input
               PRF pixel and four neighboring cell grid pixels. */

            Area_A = fabs(Corn_Ax - C_Node_x) * fabs(Corn_Ay - C_Node_y);
            Area_B = fabs(Corn_Bx - C_Node_x) * fabs(Corn_By - C_Node_y);
            Area_C = fabs(Corn_Cx - C_Node_x) * fabs(Corn_Cy - C_Node_y);
            Area_D = fabs(Corn_Dx - C_Node_x) * fabs(Corn_Dy - C_Node_y);
          }

          /*----------*/
          /* Cycle through PRF pixels again for detector pixel D_i (and
             corr. factor C_i) for purpose of incrementing the <C_j>
             component arrays. Note, for simple Num_Iter = 1 co-add,
             above PRF looping was bypassed since C_i = D_i. */

          for( pp = 0; pp < AWAP_Impix->cp.prfnaxis2; pp++ ) {
            for( p = 0; p < AWAP_Impix->cp.prfnaxis1; p++ ) {

              prf_x = p + 1.0;
              prf_y = pp + 1.0;

              prf = AWAP_Impix->cp.prfdata[locindex]
                                          [(pp*AWAP_Impix->cp.prfnaxis1)+p];

              /* Transform PRF coords to mosaic cell coords using local
                 Cartesian transformation and round to nearest integer.
                 If RotPRF_Flag = 1 use full rotation matrix, otherwise
                 either use simple nearest neighbor interpolation, or,
                 overlap-area weighting interpolation. */

              if( AWAP_Impix->co.RotPRF_Flag ) {

                /* Since rotation will spread out PRF pixels in cell grid
                   (target) frame, a straight nearest neighbor match will
                   miss some target pixels. Hence, divide PRF pixels into
                   2 x 2 sub-pixels and then transform these. */

                prf_x1 = prf_x - 0.25; prf_y1 = prf_y - 0.25;
                prf_x2 = prf_x1;       prf_y2 = prf_y + 0.25;
                prf_x3 = prf_x + 0.25; prf_y3 = prf_y2;
                prf_x4 = prf_x3;       prf_y4 = prf_y1;

                C_PRF_x = (long)(CD_x +
                          (prf_x - AWAP_Impix->cp.prfcrpix1)*cos_theta -
                          (prf_y - AWAP_Impix->cp.prfcrpix2)*sin_theta
                           + 0.5);

                C_PRF_y = (long)(CD_y +
                          (prf_x - AWAP_Impix->cp.prfcrpix1)*sin_theta +
                          (prf_y - AWAP_Impix->cp.prfcrpix2)*cos_theta
                           + 0.5);

                C_PRF_x1 = (long)(CD_x +
                           (prf_x1 - AWAP_Impix->cp.prfcrpix1)*cos_theta -
                           (prf_y1 - AWAP_Impix->cp.prfcrpix2)*sin_theta
                            + 0.5);

                C_PRF_y1 = (long)(CD_y +
                           (prf_x1 - AWAP_Impix->cp.prfcrpix1)*sin_theta +
                           (prf_y1 - AWAP_Impix->cp.prfcrpix2)*cos_theta
                            + 0.5);

                C_PRF_x2 = (long)(CD_x +
                           (prf_x2 - AWAP_Impix->cp.prfcrpix1)*cos_theta -
                           (prf_y2 - AWAP_Impix->cp.prfcrpix2)*sin_theta
                            + 0.5);

                C_PRF_y2 = (long)(CD_y +
                           (prf_x2 - AWAP_Impix->cp.prfcrpix1)*sin_theta +
                           (prf_y2 - AWAP_Impix->cp.prfcrpix2)*cos_theta
                            + 0.5);

                C_PRF_x3 = (long)(CD_x +
                           (prf_x3 - AWAP_Impix->cp.prfcrpix1)*cos_theta -
                           (prf_y3 - AWAP_Impix->cp.prfcrpix2)*sin_theta
                            + 0.5);

                C_PRF_y3 = (long)(CD_y +
                           (prf_x3 - AWAP_Impix->cp.prfcrpix1)*sin_theta +
                           (prf_y3 - AWAP_Impix->cp.prfcrpix2)*cos_theta
                            + 0.5);

                C_PRF_x4 = (long)(CD_x +
                           (prf_x4 - AWAP_Impix->cp.prfcrpix1)*cos_theta -
                           (prf_y4 - AWAP_Impix->cp.prfcrpix2)*sin_theta
                            + 0.5);

                C_PRF_y4 = (long)(CD_y +
                           (prf_x4 - AWAP_Impix->cp.prfcrpix1)*sin_theta +
                           (prf_y4 - AWAP_Impix->cp.prfcrpix2)*cos_theta
                            + 0.5);

                maxoffset = 1;

              } else {

                /* No rotation of PRF. Always aligned with cell grid. */

                C_PRF_x = (long)(CD_x + (prf_x - AWAP_Impix->cp.prfcrpix1) +
                                 0.5);

                C_PRF_y = (long)(CD_y + (prf_y - AWAP_Impix->cp.prfcrpix2) +
                                 0.5);

                /* More refined overlap-area weighted interpolation.
                   Under this method, PRF and cell pixels are always
                   aligned.*/

                if( AWAP_Impix->co.Interp_Method == 1 ) {

                  /* Physical (integral) coords of the four neighboring
                     cell pixels. */

                  C_PRF_xA = C_PRF_x - Off_Ax;
                  C_PRF_yA = C_PRF_y - Off_Ay;

                  C_PRF_xB = C_PRF_x - Off_Bx;
                  C_PRF_yB = C_PRF_y - Off_By;

                  C_PRF_xC = C_PRF_x - Off_Cx;
                  C_PRF_yC = C_PRF_y - Off_Cy;

                  C_PRF_xD = C_PRF_x - Off_Dx;
                  C_PRF_yD = C_PRF_y - Off_Dy;

                  /*
                  checksum = Area_A + Area_B + Area_C + Area_D;
                  printf("DBG: %d: %d %d %d %d : %f %f %f %f : sum = %f\n",
                          n, C_PRF_xA, C_PRF_yA, C_PRF_xD,
                          C_PRF_yD, Area_A, Area_B, Area_C,
                          Area_D, checksum);
                  */
                }
              }

              /* For detector pixel D_i, corr. factor C_i (= D_i for
                 Num_Iter = 1), increment the average correction factor
                 <C_j> component arrays for cells j "touched" by D_i
                 where C_j = Cnum_j / NV_j and NV_j = sum of inverse
                 variance weighted responses. Coverage contribution = N_j.
                 NSV_j = array for computing Num_Iter=1 uncertainties. */

              if( (C_PRF_x - maxoffset >= 1) &&
                  (C_PRF_y - maxoffset >= 1) &&
                  (C_PRF_x + maxoffset <= AWAP_Impix->cp.cellnaxis1) &&
                  (C_PRF_y + maxoffset <= AWAP_Impix->cp.cellnaxis2) ) {

                if( AWAP_Impix->co.Interp_Method == 0 ) {

                  if( !AWAP_Impix->co.RotPRF_Flag ) {

                    Cnum_j[C_PRF_y - 1][C_PRF_x - 1] += ((prf * C_i) / V_i);

                    if( AWAP_Impix->co.want_cffv ) {
                      CFFV_j[C_PRF_y - 1][C_PRF_x - 1] += ((prf*C_i*C_i)/V_i);
                    }

                    NSV_j[C_PRF_y - 1][C_PRF_x - 1] += ((prf*prf*S_i)/V_i);
                    NV_j[C_PRF_y - 1][C_PRF_x - 1] += (prf / V_i);
                    N_j[C_PRF_y - 1][C_PRF_x - 1] += prf;

                  } else {

                    /* Under PRF rotation case, PRF subpixels have an
                       effective response of a quarter of originals. */

                    prf *= 0.25;

                    /*--------*/

                    Cnum_j[C_PRF_y1 - 1][C_PRF_x1 - 1] += ((prf * C_i) / V_i);
                    Cnum_j[C_PRF_y2 - 1][C_PRF_x2 - 1] += ((prf * C_i) / V_i);
                    Cnum_j[C_PRF_y3 - 1][C_PRF_x3 - 1] += ((prf * C_i) / V_i);
                    Cnum_j[C_PRF_y4 - 1][C_PRF_x4 - 1] += ((prf * C_i) / V_i);

                    /*--------*/

                    if( AWAP_Impix->co.want_cffv ) {

                      CFFV_j[C_PRF_y1 - 1][C_PRF_x1 - 1] +=
                                                ((prf * C_i * C_i) / V_i);

                      CFFV_j[C_PRF_y2 - 1][C_PRF_x2 - 1] +=
                                                ((prf * C_i * C_i) / V_i);

                      CFFV_j[C_PRF_y3 - 1][C_PRF_x3 - 1] +=
                                                ((prf * C_i * C_i) / V_i);

                      CFFV_j[C_PRF_y4 - 1][C_PRF_x4 - 1] +=
                                                ((prf * C_i * C_i) / V_i);
                    }

                    /*--------*/
                    /* Following used to estimate uncertainty in f_j based
                       on input priors. Only applicable to Num_Iter = 1
                       co-add. Need to x 4 to get final uncert right. */

                    NSV_j[C_PRF_y1 - 1][C_PRF_x1 - 1] +=
                                          4.0 * ((prf * prf * S_i) / V_i);

                    NSV_j[C_PRF_y2 - 1][C_PRF_x2 - 1] +=
                                          4.0 * ((prf * prf * S_i) / V_i);

                    NSV_j[C_PRF_y3 - 1][C_PRF_x3 - 1] +=
                                          4.0 * ((prf * prf * S_i) / V_i);

                    NSV_j[C_PRF_y4 - 1][C_PRF_x4 - 1] +=
                                          4.0 * ((prf * prf * S_i) / V_i);

                    /*--------*/

                    NV_j[C_PRF_y1 - 1][C_PRF_x1 - 1] += (prf / V_i);
                    NV_j[C_PRF_y2 - 1][C_PRF_x2 - 1] += (prf / V_i);
                    NV_j[C_PRF_y3 - 1][C_PRF_x3 - 1] += (prf / V_i);
                    NV_j[C_PRF_y4 - 1][C_PRF_x4 - 1] += (prf / V_i);

                    /*--------*/

                    N_j[C_PRF_y1 - 1][C_PRF_x1 - 1] += prf;
                    N_j[C_PRF_y2 - 1][C_PRF_x2 - 1] += prf;
                    N_j[C_PRF_y3 - 1][C_PRF_x3 - 1] += prf;
                    N_j[C_PRF_y4 - 1][C_PRF_x4 - 1] += prf;
                  }

                } else if( AWAP_Impix->co.Interp_Method == 1 ) {

                  /* Here, four neighboring cell pixels need updating.
                     Under this method, PRF and cell pixels are always
                     aligned. */

                  Cnum_j[C_PRF_yA - 1][C_PRF_xA - 1] +=
                                     ((Area_A * prf * C_i) / V_i);

                  Cnum_j[C_PRF_yB - 1][C_PRF_xB - 1] +=
                                     ((Area_B * prf * C_i) / V_i);

                  Cnum_j[C_PRF_yC - 1][C_PRF_xC - 1] +=
                                     ((Area_C * prf * C_i) / V_i);

                  Cnum_j[C_PRF_yD - 1][C_PRF_xD - 1] +=
                                     ((Area_D * prf * C_i) / V_i);

                  /*--------*/

                  if( AWAP_Impix->co.want_cffv ) {

                    CFFV_j[C_PRF_yA - 1][C_PRF_xA - 1] +=
                                     ((Area_A * prf * C_i * C_i) / V_i);

                    CFFV_j[C_PRF_yB - 1][C_PRF_xB - 1] +=
                                     ((Area_B * prf * C_i * C_i) / V_i);

                    CFFV_j[C_PRF_yC - 1][C_PRF_xC - 1] +=
                                     ((Area_C * prf * C_i * C_i) / V_i);

                    CFFV_j[C_PRF_yD - 1][C_PRF_xD - 1] +=
                                     ((Area_D * prf * C_i * C_i) / V_i);
                  }

                  /*--------*/
                  /* Following is used for uncertainty estimation and
                     is a good approximation for the area-overlap
                     interpolation method. Too messy to implement exact
                     formulation. This is the same as nearest neighbor. */

                  NSV_j[C_PRF_y - 1][C_PRF_x - 1] += ((prf * prf * S_i) / V_i);

                  /*--------*/

                  NV_j[C_PRF_yA - 1][C_PRF_xA - 1] += (Area_A * prf / V_i);
                  NV_j[C_PRF_yB - 1][C_PRF_xB - 1] += (Area_B * prf / V_i);
                  NV_j[C_PRF_yC - 1][C_PRF_xC - 1] += (Area_C * prf / V_i);
                  NV_j[C_PRF_yD - 1][C_PRF_xD - 1] += (Area_D * prf / V_i);

                  /*--------*/

                  N_j[C_PRF_yA - 1][C_PRF_xA - 1] += (Area_A * prf);
                  N_j[C_PRF_yB - 1][C_PRF_xB - 1] += (Area_B * prf);
                  N_j[C_PRF_yC - 1][C_PRF_xC - 1] += (Area_C * prf);
                  N_j[C_PRF_yD - 1][C_PRF_xD - 1] += (Area_D * prf);

                } /* end of "if area-overlap interpolation". */

              } /* end of "if PRF pixel coords are on cell grid". */

            }  /* end of loop for x pos. of PRF cell corres. to D_i
                  and incrementing <C_j> component arrays. */

          }  /* end of loop for y pos. of PRF cell corres. to D_i
                and incrementing <C_j> component arrays. */

          /* increment number of unmasked and on-footprint pixels
             and reduced chi-square metric for image m. */

          AWAP_Impix->NumGoodD_i++;

          if( AWAP_Impix->co.have_uncert ) {
            ChiVar_i = uncdata[ii][i] * uncdata[ii][i];
            AWAP_Impix->chisq_m += ((D_i - F_i) * (D_i - F_i)) / ChiVar_i;
          }

        } /* end of "if not offscale" statement. */

      } /* end of "if not masked pixel" statement. */

     } /* end of "k>=kstart && k<=kend" statement. */

    } /* end of loop for x pos. of D_i pixel. */

  } /* end of loop for y pos. of D_i pixel. */

  if( AWAP_Impix->st.I_Verbose )
    printf("awaicgen_compute_hirespix: thread %d: %s %ld\n", AWAP_Impix->threadid,
           "number of input image pixels processed =",po);

  /* Store updated outputs back into global/structure variables. */

  AWAP_Impix->mos_cell_array = mos_cell_array;
  AWAP_Impix->Cnum_j = Cnum_j;
  AWAP_Impix->NV_j = NV_j;
  AWAP_Impix->NSV_j = NSV_j;
  AWAP_Impix->N_j = N_j;
  AWAP_Impix->CFFV_j = CFFV_j;

}
