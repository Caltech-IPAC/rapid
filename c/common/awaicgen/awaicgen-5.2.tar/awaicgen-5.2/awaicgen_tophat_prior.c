
/*********************************************** 
awaicgen_tophat_prior.c

Purpose

Generate overlap area-weighted (top-hat PRF) intensity
co-add for use as prior in HiRes/MCM. Alternative is to
use flat (=1) input prior image for HiRes.

Called in awaicgen_compute_results_hires.c

***********************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "awaicgen.h"
#include "awaicgen_defs.h"
#include "fitsio.h"
#include "wcs.h"
#include "two_plane.h"
#include "distort.h"

double overlap_area(double *, double *,
                    double, double, double, double, double);

awaicgen_tophat_prior(float             **mos_cell_array,
                   AWA_Constants     *AWAP_Const,
                   AWA_Filenames     *AWAP_Fnames,
                   AWA_Computation   *AWAP_Comp,
                   AWA_Status        *AWAP_Stat)
{
  struct   WorldCoor *wcsoutput;
  struct   TwoPlane twoplane;
  char     *inheaderfits;

  float    **thCnum_j;
  float    **thN_j;
  float    **imgdata;
  float    D_i, M_i;
  float    outin_area_ratio;

  double   D0_x, D0_y, D1_x, D1_y;
  double   D2_x, D2_y, D3_x, D3_y;
  double   CD0_x, CD0_y, CD1_x, CD1_y;
  double   CD2_x, CD2_y, CD3_x, CD3_y;
  double   CD_x[4], CD_y[4], area;
  double   Xj_min, Xj_max, Yj_min, Yj_max;

  long     i, ii, j, jj, p;
  long     fimgpix[2], xj_min, yj_min;
  long     **mskdata;

  int      m, status=0, ProjectionStatus, nkeys;
  int      offscl0, offscl1, offscl2, offscl3;
  int      Xmin, Xmax, Ymin, Ymax;  

  fitsfile *ffp_FITS_In;
  fitsfile *ffp_FITS_Msk;
  fitsfile *ffp_FITS_Unc;


  if(AWAP_Stat->I_status)
    return 0;

/*----------------------------------------------------------------------*/
/* Allocate memory to internal working arrays. */

  /* Internal thCnum_j (flux cell pixel grid). */

  thCnum_j = (float **) calloc(AWAP_Comp->cellnaxis2, sizeof(float *));

  if( thCnum_j == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_tophat_prior: could not %s\n",
            "allocate memory for thCnum_j array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_tophat_prior: allocated %f MB for %s\n",
             (AWAP_Comp->cellnaxis1*
             AWAP_Comp->cellnaxis2*sizeof(float)/1.0E+06),
             "internal thCnum_j array.");
    }
  }

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ ) {

    thCnum_j[i] = (float *) calloc(AWAP_Comp->cellnaxis1, sizeof(float));

    if( thCnum_j[i] == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_tophat_prior: could not %s\n",
              "allocate memory for thCnum_j array.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  /*----------*/
  /* Internal thN_j (cell pixel grid) array. */

  thN_j = (float **) calloc(AWAP_Comp->cellnaxis2, sizeof(float *));

  if( thN_j == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_tophat_prior: could not %s\n",
            "allocate memory for thN_j array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_tophat_prior: allocated %f MB for %s\n",
             (AWAP_Comp->cellnaxis1*
             AWAP_Comp->cellnaxis2*sizeof(float)/1.0E+06),
             "internal thN_j array.");
    }
  }

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ ) {

    thN_j[i] = (float *) calloc(AWAP_Comp->cellnaxis1, sizeof(float));

    if( thN_j[i] == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_tophat_prior: could not %s\n",
              "allocate memory for thN_j array.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }


/*----------------------------------------------------------------------*/
/* Initialize the component arrays: thCnum_j, thN_j, where mos_cell_array
    = thCnum_j / thN_j. */

  for( jj = 0; jj < AWAP_Comp->cellnaxis2; jj++ ) {
    for( j = 0; j < AWAP_Comp->cellnaxis1; j++ ) {
      thCnum_j[jj][j] = 0.0;
      thN_j[jj][j] = 0.0;
    }
  }


/*----------------------------------------------------------------------*/
/* Loop over detector images and pixels there-in and project to output grid.
   First initialize projection flag. */

    ProjectionStatus = 0;

    for( m = 0; m < AWAP_Comp->numimages; m++ ) {

      fits_open_file(&ffp_FITS_In, AWAP_Fnames->Filename_FITS_Image[m],
                     READONLY, &status);
      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_tophat_prior: %s %s; %s %d\n",
                "error opening FITS file:", 
                AWAP_Fnames->Filename_FITS_Image[m], 
                "FITS error code =", status);
        AWAP_Stat->I_status = 1;
        return 0;
      }

      /*----------*/
      /* store pixel data from detector image m in 2D dynamic array. */

      imgdata = (float **) calloc(AWAP_Comp->imgnaxis2, sizeof(float *));

      for( p = 0; p < AWAP_Comp->imgnaxis2; p++ )
        imgdata[p] = (float *) calloc(AWAP_Comp->imgnaxis1, sizeof(float)); 

      if( imgdata == NULL ) {
        fprintf(stderr,"*** Error: awaicgen_tophat_prior: %s\n",
                "could not allocate memory for imgdata array.");
        AWAP_Stat->I_status = 1;
        return 0;
      }

      fimgpix[0] = 1;  /* column dim. in input image. */
      fimgpix[1] = 1;  /* row dim. in input image.    */

      /* pixel data is stored as: imgdata[y_pix-1][x_pix-1] where
         y_pix = 1..naxis2; x_pix = 1..naxis1. */

      for(fimgpix[1] = 1; fimgpix[1] <= AWAP_Comp->imgnaxis2; fimgpix[1]++) {

        fits_read_pix(ffp_FITS_In, TFLOAT, fimgpix, AWAP_Comp->imgnaxis1, 
                      NULL, imgdata[fimgpix[1] - 1], NULL, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_tophat_prior: %s %s\n",
                  "error storing pixel data from image", 
                  AWAP_Fnames->Filename_FITS_Image[m]);
          AWAP_Stat->I_status = 1;
          return 0;
        }
      }

      printf("awaicgen_tophat_prior: %s #%d of %d: %s %s\n",
             "processing image", m+1, AWAP_Comp->numimages, 
             AWAP_Fnames->Filename_FITS_Image[m],"...");

      /*----------*/
      /* get the WCS keywords from image m to use in projection below. */

      ffhdr2str(ffp_FITS_In, 1, NULL, 0, &inheaderfits, &nkeys, &status);
      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_tophat_prior: %s %s; %s %d\n",
                "error reading FITS header:", 
                AWAP_Fnames->Filename_FITS_Image[m],
                "FITS error code =", status);
        AWAP_Stat->I_status = 1;
        return 0;
      }

      fits_close_file(ffp_FITS_In, &status);
      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_tophat_prior: %s %s; %s %d\n",
                "error closing FITS file:", 
                AWAP_Fnames->Filename_FITS_Image[m],
                "FITS error code =", status);
        AWAP_Stat->I_status = 1;
        return 0;
      }

      /*----------*/
      /* read/store pixel mask data (if specified) for detector image m
         in 2D dynamic array. Assumes good pixels have value 0; "bad" pixels
         have integer values > 0 up to integer +2^31. */

      if( AWAP_Const->have_masks ) {

        if( AWAP_Stat->I_Verbose )
          printf("awaicgen_tophat_prior: reading/storing mask #%d: %s %s\n",
                 m+1, AWAP_Fnames->Filename_FITS_Mask[m],"...");

        fits_open_file(&ffp_FITS_Msk, AWAP_Fnames->Filename_FITS_Mask[m],
                       READONLY, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_tophat_prior: %s %s; %s %d\n",
                  "error opening FITS file:", 
                  AWAP_Fnames->Filename_FITS_Mask[m],
                  "FITS error code =", status);
          AWAP_Stat->I_status = 1;
          return 0;
        }

        mskdata = (long **) calloc(AWAP_Comp->imgnaxis2, sizeof(long));

        for( p = 0; p < AWAP_Comp->imgnaxis2; p++ )
          mskdata[p] = (long *) calloc(AWAP_Comp->imgnaxis1, sizeof(long));

        if( mskdata == NULL ) {
          fprintf(stderr,"*** Error: awaicgen_tophat_prior: could %s\n",
                  "not allocate memory for mskdata array.");
          AWAP_Stat->I_status = 1;
          return 0;
        }

        /* mask data is stored as: mskdata[y_pix-1][x_pix-1] where
           y_pix = 1..naxis2; x_pix = 1..naxis1. */

        for(fimgpix[1] = 1; fimgpix[1] <= AWAP_Comp->imgnaxis2; fimgpix[1]++) {

          fits_read_pix(ffp_FITS_Msk, TLONG, fimgpix, AWAP_Comp->imgnaxis1,
                        NULL, mskdata[fimgpix[1] - 1], NULL, &status);
          if( status ) {
            fprintf(stderr,"*** Error: awaicgen_tophat_prior: %s %s\n",
                    "error storing pixel data from mask:",
                    AWAP_Fnames->Filename_FITS_Mask[m]);
            AWAP_Stat->I_status = 1;
            return 0;
          }
        }

        fits_close_file(ffp_FITS_Msk, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_tophat_prior: %s %s; %s %d\n",
                  "error closing FITS file:", 
                  AWAP_Fnames->Filename_FITS_Mask[m],
                  "FITS error code =", status);
          AWAP_Stat->I_status = 1;
          return 0;
        }
      }

      /*----------*/
      /* set-up the structure for the plane-to-plane WCS transform:
         image m to output mosaic cell grid. */

      wcsoutput = wcsinit(AWAP_Comp->outwcsheader);

      status = Initialize_TwoPlane_FirstDistort(&twoplane,
                                                inheaderfits,
                                                wcsoutput);

      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_tophat_prior: could %s\n",
                "not set-up plane-to-plane transform.");
        AWAP_Stat->I_status = 1;
        return 0;
      }

      wcsfree(wcsoutput);

      free(inheaderfits);

      /*----------*/
      /* Transform each detector pixel in image m to cell grid
         frame using fast WCS projection and compute its exact
         fractional areal overlap with the output grid pixels. */

      for(ii = 0; ii < AWAP_Comp->imgnaxis2; ii++) {
        for(i = 0; i < AWAP_Comp->imgnaxis1; i++) {

          /* measured flux in detector pixel at (x,y) = (i+1,ii+1). */

          D_i = imgdata[ii][i];

          /* initialize mask value to "not masked", otherwise, if input
             masks specified, use specific mask value for detector pixel
             at (x,y) = (i+1,ii+1). */

          M_i = 0.0;

          if( AWAP_Const->have_masks )
            if( mskdata[ii][i] & AWAP_Const->Fatal_Bits )
              M_i = 1.0;

          /* if input pixel D_i is NaN, mask it! */

          if( (D_i != D_i) )
            M_i = 1.0;

          /* only reproject and co-add input pixel D_i if it is not masked
             and not NaN'd. */

          if( M_i != 1.0 ) {

            /* Coords of the four corners of the input pixel. Starting at
               top right and going counter-clockwise (assumes the
               CDELT1 < 0 & CDELT2 > 0 convention). */

            D0_x = i  + 1.5;
            D0_y = ii + 1.5;

            D1_x = i  + 0.5;
            D1_y = ii + 1.5;

            D2_x = i  + 0.5;
            D2_y = ii + 0.5;

            D3_x = i  + 1.5;
            D3_y = ii + 0.5;

            /*----------*/
            /* Project these corners to cell grid frame. Note: faster method
               used in AWOD module gives artifacts here, hence not
               appropriate. */

            offscl0 = plane1_to_plane2_transform( D0_x, D0_y, &CD0_x, &CD0_y,
                                                 &twoplane );

            offscl1 = plane1_to_plane2_transform( D1_x, D1_y, &CD1_x, &CD1_y,
                                                 &twoplane );

            offscl2 = plane1_to_plane2_transform( D2_x, D2_y, &CD2_x, &CD2_y,
                                                 &twoplane );

            offscl3 = plane1_to_plane2_transform( D3_x, D3_y, &CD3_x, &CD3_y,
                                                 &twoplane );

            /* Store output corner coordinates in arrays. */
            
            CD_x[0] = CD0_x; CD_y[0] = CD0_y; 
            CD_x[1] = CD1_x; CD_y[1] = CD1_y;
            CD_x[2] = CD2_x; CD_y[2] = CD2_y;
            CD_x[3] = CD3_x; CD_y[3] = CD3_y;

            if( !offscl0 && !offscl1 && !offscl2 && !offscl3 ) {

              ProjectionStatus = 1;

              /* Find the integral x, y coordinate range of the output (grid 
                 frame) pixels overlapping with this input pixel. These are
                 in zero-based array coordinates. */

              Xmin = (int)(fmin(fmin(CD0_x, CD1_x),fmin(CD2_x, CD3_x)) 
                           + 0.5) - 1;

              Xmax = (int)(fmax(fmax(CD0_x, CD1_x),fmax(CD2_x, CD3_x))
                           + 0.5) - 1;

              Ymin = (int)(fmin(fmin(CD0_y, CD1_y),fmin(CD2_y, CD3_y))
                           + 0.5) - 1;

              Ymax = (int)(fmax(fmax(CD0_y, CD1_y),fmax(CD2_y, CD3_y))
                           + 0.5) - 1;

              /*----------*/
              /* For this detector pixel and all overlapping output pixels,
                 compute the (unit-normalized) area overlaps, and update the
                 output cell grid array values. */ 

              if( (Xmin >= 0) && (Xmax < AWAP_Comp->cellnaxis1) &&
                  (Ymin >= 0) && (Ymax < AWAP_Comp->cellnaxis2) ) {

                for( jj = Ymin; jj <= Ymax; jj++ ) {
                  for( j = Xmin; j <= Xmax; j++ ) {

                    /* Bounding box for each cell grid pixel. */

                    Xj_min = j  + 0.5; 
                    Xj_max = j  + 1.5;
                    Yj_min = jj + 0.5;
                    Yj_max = jj + 1.5;

                    /* Compute exact overlap area. */

                    area = overlap_area(CD_x, CD_y, Xj_min, Xj_max,
                                        Yj_min, Yj_max, 1);

                    thCnum_j[jj][j] += area * D_i;

                    thN_j[jj][j] += area;
                  }
                }

              } /* end of "if output pixels fall in cell grid" statement. */

            }  /* end of "if not offscale" statement. */

          }  /* end of "if not masked pixel" statement. */

        }  /* end of loop for x pos. of D_i pixel. */

      }  /* end of loop for y pos. of D_i pixel. */

      /*----------*/
      /* free memory in 2D pixel data array for image m. */

      for( p = 0; p < AWAP_Comp->imgnaxis2; p++ )
        free( imgdata[p] );

      free( imgdata );

      /*----------*/
      /* free memory in 2D pixel mask array for image m if masks
         were specified. */

      if( AWAP_Const->have_masks ) {

        for( p = 0; p < AWAP_Comp->imgnaxis2; p++ )
          free( mskdata[p] );

        free( mskdata );
      }

    }  /* end of loop for detector image m. */

    /*----------*/
    /* compute the area-weighted average cell-grid fluxes. */

    for( jj = 0; jj < AWAP_Comp->cellnaxis2; jj++ )
      for( j = 0; j < AWAP_Comp->cellnaxis1; j++ )
        mos_cell_array[jj][j] = thCnum_j[jj][j] / thN_j[jj][j];


/*----------------------------------------------------------------------*/
/* Check projection status flag to ensure some of the input pixels 
   were projected. If not, abort with error message. */

  if( !ProjectionStatus ) { 

    fprintf(stderr,"*** Error: awaicgen_tophat_prior: %s; %s\n",
            "none of the input pixels fell onto the WCS grid",
            "quitting...");
    AWAP_Stat->I_status = 1;
    return 0;
  }


/*----------------------------------------------------------------------*/
/* Free some undesired memory. */

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ )
    free( thCnum_j[i] );

  free( thCnum_j );

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ )
    free( thN_j[i] );

  free( thN_j );

}
