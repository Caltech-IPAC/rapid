
/*********************************************** 
awaicgen_parse_args.c

Purpose

Parse the command line to get input and output
file names, processing parameters and flags.
Check their validity and if within range.

***********************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>
#include "awaicgen.h"
#include "awaicgen_defs.h"

awaicgen_parse_args(int            argc,
		 char           **argv,
		 AWA_Constants  *AWAP_Const,
		 AWA_Filenames  *AWAP_Fnames,
		 AWA_Status     *AWAP_Stat)
{
  int   i, reset_interp_meth;
  char  CP_Value[STRING_BUFFER_SIZE];


  if(AWAP_Stat->I_status)
    return 0;

  /* initialize arg counter. */
  i = 1;

  while( i < argc ) {

    if( argv[i][0] == '-' ) {

      switch( argv[i][1] ) {

        case 'f':
          if( ++i >= argc )
            printf("awaicgen_parse_args: -f[1-5 or p] <input_filename> %s",
                   "missing argument\n");
          else
          if(argv[i-1][2] == '1')
            if(AWAP_Fnames->Filename_FITS_Image_List)
              sscanf(argv[i], "%s", AWAP_Fnames->Filename_FITS_Image_List);
          if(argv[i-1][2] == '2')
            if(AWAP_Fnames->Filename_FITS_Mask_List)
              sscanf(argv[i], "%s", AWAP_Fnames->Filename_FITS_Mask_List);
          if(argv[i-1][2] == '3')
            if(AWAP_Fnames->Filename_FITS_Uncert_List)
              sscanf(argv[i], "%s", AWAP_Fnames->Filename_FITS_Uncert_List);
          if(argv[i-1][2] == '4')
            if(AWAP_Fnames->Filename_FITS_PRF_List)
              sscanf(argv[i], "%s", AWAP_Fnames->Filename_FITS_PRF_List);
          if(argv[i-1][2] == '5')
            if(AWAP_Fnames->Filename_Input_MosaicCell)
              sscanf(argv[i], "%s", AWAP_Fnames->Filename_Input_MosaicCell);
          if(argv[i-1][2] == 'p') {
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->TophatPrior = atoi(CP_Value);
          }
          break;

        case 'm':
          if( ++i >= argc )
            printf("awaicgen_parse_args: -m[s] <inp_fatalmask_bits> %s",
                   "missing argument\n");
          else
          if(argv[i-1][2] == '\0') {
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->Fatal_Bits = atoi(CP_Value);
          }
          if(argv[i-1][2] == 's') {
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->Sat_Bits = atoi(CP_Value);
          }
          break;

        case 'X':
          if( ++i >= argc )
            printf("awaicgen_parse_args: -X <mosaic_size_x> %s",
                   "missing argument\n"); 
          else
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->Mosaic_SizeX = atof(CP_Value);
          break;              

        case 'Y':
          if( ++i >= argc )
            printf("awaicgen_parse_args: -Y <mosaic_size_y> %s", 
                   "missing argument\n"); 
          else
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->Mosaic_SizeY = atof(CP_Value);
          break;

        case 'R':
          if( ++i >= argc )
            printf("awaicgen_parse_args: -R <RA_center> %s",
                   "missing argument\n"); 
          else
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->RA_center = atof(CP_Value);
          break;

        case 'D':
          if( ++i >= argc )
            printf("awaicgen_parse_args: -D <Dec_center> %s",
                   "missing argument\n"); 
          else
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->Dec_center = atof(CP_Value);
          break;

        case 'C':
          if( ++i >= argc )
            printf("awaicgen_parse_args: -C <mosaic_rotation> %s",
                   "missing argument\n"); 
          else
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->Mosaic_Rot = atof(CP_Value);
          break;

        case 'p':
          if( ++i >= argc )
            printf("awaicgen_parse_args: -p[s,a,c] <pix_scales> %s",
                   "missing argument\n");
          else
          if(argv[i-1][2] == 's') {
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->Mosaic_PixFact = atof(CP_Value);
          }
          if(argv[i-1][2] == 'a') {
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->Mosaic_PixScal = atof(CP_Value);
          }
          if(argv[i-1][2] == 'c') {
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->Mosaic_CellFact = atof(CP_Value);
          }
          break;

        case 'd':
          if( ++i >= argc )
            printf("awaicgen_parse_args: -d <drizzle_factor> %s",
                   "missing argument\n");
          else
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->Ldriz = atof(CP_Value);
          break;

        case 'w':
          if( ++i >= argc )
            printf("awaicgen_parse_args: -wf <inv_var_weight_flag> %s",
                   "missing argument\n");
          else
          if(argv[i-1][2] == 'f') {
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->Weight_Flag = atoi(CP_Value);
          }
          break;

        case 's':
          if( ++i >= argc )
            printf("awaicgen_parse_args: -sf <pixflux_scale_flag> %s",
                   "or -sc <simple_coadd_flag> missing argument\n");
          else
          if(argv[i-1][2] == 'f') {
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->Flxscal_Flag = atoi(CP_Value);
          }
          if(argv[i-1][2] == 'c') {
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->Simple_Flag = atoi(CP_Value);
          }
          break;

        case 'n':
          if( ++i >= argc )
            printf("awaicgen_parse_args: -n[t] <num_iterations [num_threads]> %s",
                   "missing argument\n"); 
          else
          if(argv[i-1][2] == '\0') {
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->Num_Iter = atoi(CP_Value);
          }
          if(argv[i-1][2] == 't') {
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->NumThreads = atoi(CP_Value);
          }
          break;

        case 'r':
          if( ++i >= argc )
            printf("awaicgen_parse_args: -rf <rotate_prf_proj_flag> %s",
                   "missing argument\n");
          else
          if(argv[i-1][2] == 'f') {
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->RotPRF_Flag = atoi(CP_Value);
          }
          break;

        case 't':
          if( ++i >= argc )
            printf("awaicgen_parse_args: -t <unc_sigfigs_retained> %s",
                   "missing argument\n");
          else
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->SigFig = atoi(CP_Value);
          break;

        case 'h':
          if( ++i >= argc )
            printf("awaicgen_parse_args: -h <cfv_pctdiff_thres> %s",
                   "missing argument\n");
          else
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->CFVpctdiff = atof(CP_Value);
          break;

        case 'c':
          if( ++i >= argc )
            printf("awaicgen_parse_args: -ct <prf_cell_size_tol> %s",
                   "missing argument\n");
          else
          if(argv[i-1][2] == 't') {
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->PRFScal_Tol = atof(CP_Value);
          }
          break;

        case 'i':
          if( ++i >= argc )
            printf("awaicgen_parse_args: -if <interpolation_option> %s",
                   "missing argument\n");
          else
          if(argv[i-1][2] == 'f') {
            sscanf(argv[i], "%s", CP_Value);
            AWAP_Const->Interp_Method = atoi(CP_Value);
          }
          break;

        case 'o':
          if( ++i >= argc )
            printf("awaicgen_parse_args: -o[1-9,i,f,m] <output_filename> %s",
                   "missing argument\n");
          else
          if(argv[i-1][2] == '1')  
            if(AWAP_Fnames->Filename_Output_Mosaic) {
              sscanf("!", "%c", AWAP_Fnames->Filename_Output_Mosaic);
              sscanf(argv[i], "%s",
                     &(AWAP_Fnames->Filename_Output_Mosaic[1]));
            }
          if(argv[i-1][2] == '2')
            if(AWAP_Fnames->Filename_Output_Coverage) {
              sscanf("!", "%c", AWAP_Fnames->Filename_Output_Coverage);
              sscanf(argv[i], "%s",
                     &(AWAP_Fnames->Filename_Output_Coverage[1]));
            }
          if(argv[i-1][2] == '3')
            if(AWAP_Fnames->Filename_Output_Uncert) {
              sscanf("!", "%c", AWAP_Fnames->Filename_Output_Uncert);
              sscanf(argv[i], "%s", 
                     &(AWAP_Fnames->Filename_Output_Uncert[1]));
            }
          if(argv[i-1][2] == '4')
            if(AWAP_Fnames->Filename_Output_Stddev) {
              sscanf("!", "%c", AWAP_Fnames->Filename_Output_Stddev);
              sscanf(argv[i], "%s",
                     &(AWAP_Fnames->Filename_Output_Stddev[1]));
            }
          if(argv[i-1][2] == '5')
            if(AWAP_Fnames->Filename_Output_Corr) {
              sscanf("!", "%c", AWAP_Fnames->Filename_Output_Corr);
              sscanf(argv[i], "%s",
                     &(AWAP_Fnames->Filename_Output_Corr[1]));
            }
          if(argv[i-1][2] == '6')
            if(AWAP_Fnames->Filename_Output_CFVUncert) {
              sscanf("!", "%c", AWAP_Fnames->Filename_Output_CFVUncert);
              sscanf(argv[i], "%s",
                     &(AWAP_Fnames->Filename_Output_CFVUncert[1]));
            }
          if(argv[i-1][2] == '7')
            if(AWAP_Fnames->Filename_Output_MosaicCell) {
              sscanf("!", "%c", AWAP_Fnames->Filename_Output_MosaicCell);
              sscanf(argv[i], "%s",
                     &(AWAP_Fnames->Filename_Output_MosaicCell[1]));
            }
          if(argv[i-1][2] == '8')
            if(AWAP_Fnames->Filename_Output_MosaicCFV) {
              sscanf("!", "%c", AWAP_Fnames->Filename_Output_MosaicCFV);
              sscanf(argv[i], "%s",
                     &(AWAP_Fnames->Filename_Output_MosaicCFV[1]));
            }
          if(argv[i-1][2] == '9')
            if(AWAP_Fnames->Filename_Output_MosaicCOR) {
              sscanf("!", "%c", AWAP_Fnames->Filename_Output_MosaicCOR);
              sscanf(argv[i], "%s",
                     &(AWAP_Fnames->Filename_Output_MosaicCOR[1]));
            }
          if(argv[i-1][2] == 'i')
            if(AWAP_Fnames->Filename_Output_MosaicIter) {
              sscanf("!", "%c", AWAP_Fnames->Filename_Output_MosaicIter);
              sscanf(argv[i], "%s",
                     &(AWAP_Fnames->Filename_Output_MosaicIter[1]));
            }
          if(argv[i-1][2] == 'f')
            if(AWAP_Fnames->Filename_Output_MosaicFIter) {
              sscanf("!", "%c", AWAP_Fnames->Filename_Output_MosaicFIter);
              sscanf(argv[i], "%s",
                     &(AWAP_Fnames->Filename_Output_MosaicFIter[1]));
            }
          if(argv[i-1][2] == 'm')
            if(AWAP_Fnames->Filename_Output_MosaicMsk) {
              sscanf("!", "%c", AWAP_Fnames->Filename_Output_MosaicMsk);
              sscanf(argv[i], "%s",
                     &(AWAP_Fnames->Filename_Output_MosaicMsk[1]));
            }
          break;

        case 'g':
          if(argv[i][2] != 'g')
            AWAP_Stat->I_Debug = 1 - AWAP_Stat->I_Debug;
          break;

        case 'v':
          if(argv[i][2] != 'v')
            AWAP_Stat->I_Verbose = 1 - AWAP_Stat->I_Verbose;
          break;

        default:
          fprintf(stderr,"*** Error: awaicgen_parse_args: unknown argument.\n");
        }

    } else {
        fprintf(stderr,"*** Error: awaicgen_parse_args: %s\n",
                "command-line syntax error.");
        AWAP_Stat->I_status = 1;
    }

    i++;
  }

  if(AWAP_Stat->I_status)
    return 0;


/*----------------------------------------------------------------------*/
/* Print program name and version number to stdout. */

  if(AWAP_Stat->I_Verbose) 
    printf("\nawaicgen_parse_args: %s, Version %2.1f\n", PURPOSE, VERSN);


/*----------------------------------------------------------------------*/
/* Check existence/validity of inputs. Echo to stdout if verbose 
   switch is set. */ 

  if( strcmp(AWAP_Fnames->Filename_FITS_Image_List,"") ) {
    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: Input image list = %s\n", 
             AWAP_Fnames->Filename_FITS_Image_List);
  } else {
      fprintf(stderr,"*** Error: awaicgen_parse_args: Missing input FITS %s\n",
              "image list filename (-f1 <input>).");
      AWAP_Stat->I_status = 1;
  }


  if( !AWAP_Const->Simple_Flag )
    if( strcmp(AWAP_Fnames->Filename_FITS_PRF_List,"") ) {
      if(AWAP_Stat->I_Verbose)
        printf("awaicgen_parse_args: Input PRF image list = %s\n", 
               AWAP_Fnames->Filename_FITS_PRF_List);
    } else {
        fprintf(stderr,"*** Error: awaicgen_parse_args: Missing input PRF %s\n",
                "image list filename (-f4 <input>).");
        AWAP_Stat->I_status = 1;
    }


  if( strcmp(AWAP_Fnames->Filename_FITS_Uncert_List,"") ) {
    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: Input uncertainty image list = %s\n", 
             AWAP_Fnames->Filename_FITS_Uncert_List);

    AWAP_Const->have_uncert = 1;

  }


  if( strcmp(AWAP_Fnames->Filename_FITS_Mask_List,"") ) {
    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: Input mask image list = %s\n",             
             AWAP_Fnames->Filename_FITS_Mask_List);

    AWAP_Const->have_masks = 1;

  } /* else {
    fprintf(stderr,"=== Warning: awaicgen_parse_args: input mask image %s\n",
            "list not specified.");
  } */


  if( strcmp(AWAP_Fnames->Filename_Output_Mosaic,"") ) {
    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: Output mosaic image filename = %s\n",
             AWAP_Fnames->Filename_Output_Mosaic);
  } else {
      fprintf(stderr,"*** Error: awaicgen_parse_args: Missing output mosaic %s\n",
              "image filename (-o1 <input>).");
      AWAP_Stat->I_status = 1;
  }


  if( strcmp(AWAP_Fnames->Filename_Output_Coverage,"") ) {
    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: Output mosaic coverage map filename = %s\n",
             AWAP_Fnames->Filename_Output_Coverage);
  } /*else {
      fprintf(stderr,"*** Error: awaicgen_parse_args: Missing output mosaic %s\n",
              "coverage map filename (-o2 <input>).");
      AWAP_Stat->I_status = 1;
  } */


  if( strcmp(AWAP_Fnames->Filename_Output_Uncert,"") ) {
    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: Output mosaic uncert. image filename = %s\n",
             AWAP_Fnames->Filename_Output_Uncert);
  } else if( !strcmp(AWAP_Fnames->Filename_Output_Uncert,"") && 
             AWAP_Const->have_uncert ) {
      fprintf(stderr,"=== Warning: awaicgen_parse_args: Output %s\n",
              "uncertainty mosaic filename not specified.");
  }


  if( strcmp(AWAP_Fnames->Filename_Output_Uncert,"") &&
      !AWAP_Const->have_uncert ) {
    fprintf(stderr,"*** Error: awaicgen_parse_args: Output mosaic %s %s\n",
            "uncert. image filename was specified, but have no input",
            "uncertainty list (-f3 <input>).");
    AWAP_Stat->I_status = 1;
  }


  if( AWAP_Const->Weight_Flag && !AWAP_Const->have_uncert ) {
    fprintf(stderr,"*** Error: awaicgen_parse_args: Inverse variance %s %s\n",
            "weighting was specified (-wf 1), but have no input",
            "uncertainty list (-f3 <input>).");
    AWAP_Stat->I_status = 1;
  }


/*****
  if( strcmp(AWAP_Fnames->Filename_Output_Uncert,"") &&
      (AWAP_Const->Num_Iter > 1) ) {
    fprintf(stderr,"=== Warning: awaicgen_parse_args: Output %s %s %s %s\n",
            "uncertainty image:", AWAP_Fnames->Filename_Output_Uncert,
            "will not be appropriate for a co-add created from >1 MCM",
            "iterations");
  }
*****/


  if( strcmp(AWAP_Fnames->Filename_Output_Corr,"") &&
      !AWAP_Const->Simple_Flag ) {

    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: Output mosaic of MCM correction %s = %s\n",
             "factors filename",AWAP_Fnames->Filename_Output_Corr);

    AWAP_Const->want_corr = 1;
  }


  if( strcmp(AWAP_Fnames->Filename_Output_Corr,"") &&
      (AWAP_Const->Num_Iter == 1) &&
      !AWAP_Const->Simple_Flag ) {

      fprintf(stderr,"=== Warning: awaicgen_parse_args: Output mosaic of %s\n",
              "MCM correction factors won't make much sense for -n = 1.");
  }


  AWAP_Const->want_msk = 0;

  if( strcmp(AWAP_Fnames->Filename_Output_MosaicMsk,"") ) {

    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: Output mosaic mask = %s\n",
             AWAP_Fnames->Filename_Output_MosaicMsk);

    AWAP_Const->want_msk = 1;
  }


  if( strcmp(AWAP_Fnames->Filename_Output_MosaicMsk,"") &&
      ((AWAP_Const->Num_Iter > 1) ||
        AWAP_Const->Simple_Flag ||
        strcmp(AWAP_Fnames->Filename_Output_CFVUncert,"") ||
        strcmp(AWAP_Fnames->Filename_Output_MosaicCOR,"") ||
        AWAP_Const->Interp_Method ||
        AWAP_Const->RotPRF_Flag) ) {

      fprintf(stderr,"=== Warning: awaicgen_parse_args: Output %s %s %s %s %s\n",
              "mask mosaic cannot be made for -n > 1 (hires); or simple",
              "(area-weighted) co-add (-sc 1); or if -o5,-o6 (hires-related)",
              "products desired; or if PRF-to-cell grid interpolation",
              "option 1 (-if 1) is specified; or with rotation of input PRFs",
              "(-rf 1); turning off mask creation...");

      AWAP_Const->want_msk = 0;
  }


  if( strcmp(AWAP_Fnames->Filename_Output_CFVUncert,"") &&
      !AWAP_Const->Simple_Flag ) {

    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: Output mosaic of data-derived MCM %s = %s\n",
             "variances filename",AWAP_Fnames->Filename_Output_CFVUncert);

    AWAP_Const->want_cffv = 1;
  }


  if( strcmp(AWAP_Fnames->Filename_Output_CFVUncert,"") &&
      (AWAP_Const->Num_Iter == 1) &&
      !AWAP_Const->Simple_Flag ) {

      fprintf(stderr,"=== Warning: awaicgen_parse_args: Output mosaic of %s\n",
              "data-derived MCM variances won't make much sense for -n = 1.");
  }


  if( strcmp(AWAP_Fnames->Filename_Output_MosaicCell,"") ) {
  
    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: Output mosaic base filename in %s = %s\n",
             "internal cell-grid frame",
             AWAP_Fnames->Filename_Output_MosaicCell);
  }


  if( strcmp(AWAP_Fnames->Filename_Output_MosaicCOR,"") ) {
            
    if(AWAP_Stat->I_Verbose) 
      printf("awaicgen_parse_args: Output mosaic correction-factor %s = %s\n",
             "base filename in internal cell-grid frame",
             AWAP_Fnames->Filename_Output_MosaicCOR);
  }

  
  if( strcmp(AWAP_Fnames->Filename_Output_MosaicCFV,"") &&
      !AWAP_Const->want_cffv &&
      !AWAP_Const->Simple_Flag ) {

    fprintf(stderr,"*** Error: awaicgen_parse_args: output base %s %s\n",
            "filename for CFV cell-mosaics (-o8) was specified without",
            "output CFVuncert filename (-o6); must specify together.");
    AWAP_Stat->I_status = 1;

  } else if( strcmp(AWAP_Fnames->Filename_Output_MosaicCFV,"") &&
             AWAP_Const->want_cffv &&
             !AWAP_Const->Simple_Flag ) {

    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: Output CFV mosaic base filename in %s = %s\n",
             "internal cell-grid frame",
             AWAP_Fnames->Filename_Output_MosaicCFV);
  }


  if( strcmp(AWAP_Fnames->Filename_Input_MosaicCell,"") ) {

    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: Input starting model mosaic for MCM = %s\n",
             AWAP_Fnames->Filename_Input_MosaicCell);
  }


  if( (AWAP_Const->CFVpctdiff > 0.0) && 
      (!AWAP_Const->want_cffv ||
       !AWAP_Const->want_corr)) {

    fprintf(stderr,"*** Error: awaicgen_parse_args: CFV percentage %s\n",
            "difference threshold (-h) > 0 but -o5 and/or -o6 unspecified.");
    AWAP_Stat->I_status = 1;

  } else if( (AWAP_Const->CFVpctdiff > 0.0) &&
             (AWAP_Const->Num_Iter == 1) ) {

    fprintf(stderr,"*** Error: awaicgen_parse_args: CFV percentage %s %s\n",
            "difference threshold (-h) > 0 but number of MCM",
            "iterations (-n) not > 1.");
    AWAP_Stat->I_status = 1;

  } else {

    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: CFV percentage-difference threshold = %f%%\n",
             AWAP_Const->CFVpctdiff);
  }


  if( strcmp(AWAP_Fnames->Filename_Output_MosaicIter,"") &&
      (!AWAP_Const->want_cffv || 
       !AWAP_Const->want_corr) ) {

    fprintf(stderr,"*** Error: awaicgen_parse_args: out filename for %s %s %s\n",
            "position-dependent iteration number image was specified (-oi)",
            "without the -o5 and -o6 ancillary outputs; must specify all",
            "together.");
    AWAP_Stat->I_status = 1;

  } else {

    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: Output position-dependent iteration %s = %s\n",
             "numbers filename", AWAP_Fnames->Filename_Output_MosaicIter);
  }


  if( strcmp(AWAP_Fnames->Filename_Output_MosaicFIter,"") &&
      (AWAP_Const->Num_Iter == 1) ) {

    fprintf(stderr,"*** Error: awaicgen_parse_args: out filename for %s %s\n",
            "first iteration intensity image was specified (-of) with -n = 1;",
            "can only generate for -n > 1; please omit \"-of\".");
    AWAP_Stat->I_status = 1;

  } else {

    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: Output first iteration intensity %s = %s\n",
             "image filename in down-sampled frame",
             AWAP_Fnames->Filename_Output_MosaicIter);
  }


  if( (AWAP_Const->TophatPrior == 0) ||
      (AWAP_Const->TophatPrior == 1) ) {
    if(AWAP_Stat->I_Verbose) {
      printf("awaicgen_parse_args: flag to create/use area-weighted %s = %d\n",
             "co-add for MCM starting model", AWAP_Const->TophatPrior);
    }     
  } else {  
    fprintf(stderr,"*** Error: awaicgen_parse_args: flag to create/use %s\n",
            "area-weighted co-add for MCM is out of range (-fp <0 or 1>).");
    AWAP_Stat->I_status = 1;
  }


  if( (AWAP_Const->TophatPrior == 1) &&
      strcmp(AWAP_Fnames->Filename_Input_MosaicCell,"") ) {

    fprintf(stderr,"=== Warning: awaicgen_parse_args: both %s %s\n",
            "-f5 and -fp were specified for prior MCM model; former will",
            "over-ride latter");

    AWAP_Const->TophatPrior = 0;
  }


  /* Note in following: if Fatal_Bits > 2**31 (INT_MAX), then it's internally
     wrapped-around to a negative num. and program aborts. */ 

  if( AWAP_Const->Fatal_Bits >= 0 ) {
    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: fatal mask-bitstring template = %d\n",
             AWAP_Const->Fatal_Bits);
  } else {
      fprintf(stderr,"*** Error: awaicgen_parse_args: fatal %s %s %d and %d\n",
              "bitstring template is outside allowed integer range",
              "(-m <input>); must be between", 0, INT_MAX);
      AWAP_Stat->I_status = 1;
  }


  if( AWAP_Const->Sat_Bits >= 0 ) {
    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: fatal saturation mask-bitstring %s = %d\n",
             "template", AWAP_Const->Sat_Bits);
  } else {
      fprintf(stderr,"*** Error: awaicgen_parse_args: fatal %s %s %d and %d\n",
              "sat. bitstring template is outside allowed integer range",
              "(-ms <input>); must be between", 0, INT_MAX);
      AWAP_Stat->I_status = 1; 
  }

  
  /* Check the saturation bitstring is included in the fatal bitstring. */

  if( !(AWAP_Const->Fatal_Bits & AWAP_Const->Sat_Bits) &&
       (AWAP_Const->Sat_Bits > 0) && (AWAP_Const->Fatal_Bits > 0) ) {
    fprintf(stderr,"*** Error: awaicgen_parse_args: %s (-ms %d) %s (-m %d)\n",
            "the saturation bitstring", AWAP_Const->Sat_Bits,
            "must be included in the full fatal bitstring",
            AWAP_Const->Fatal_Bits);
    AWAP_Stat->I_status = 1;

  }


  if( AWAP_Const->SigFig >= 0 ) {
    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: number of signif. figures to %s %d %s\n",
             "retain in cov (-o2) and unc (-o3) outputs =",
             AWAP_Const->SigFig,
             "(0 => no loss in precision)");
  } else {
      fprintf(stderr,"*** Error: awaicgen_parse_args: number of %s %s\n", 
              "signif. figs to retain in cov (-o2) and unc (-o3) outputs",
              "(-t <input>) must be >= 0; 0 => no loss in precision");
      AWAP_Stat->I_status = 1;
  }


  if( (AWAP_Const->Mosaic_SizeX > 0.0) && 
      (AWAP_Const->Mosaic_SizeX <= MAXMOSAICDIM) ) {
    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: mosaic linear dimension %s = %f\n",
             "(unrotated along E-W)",AWAP_Const->Mosaic_SizeX);
  } else {
      fprintf(stderr,"*** Error: awaicgen_parse_args: mosaic linear %s %s\n", 
              "dimension (unrotated along E-W) is out of range",
              "or missing (-X <input>).");
      AWAP_Stat->I_status = 1;
  }


  if( (AWAP_Const->Mosaic_SizeY > 0.0) &&
      (AWAP_Const->Mosaic_SizeY <= MAXMOSAICDIM) ) {
    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: mosaic linear dimension %s = %f\n",
             "(unrotated along N-S)",AWAP_Const->Mosaic_SizeY);
  } else {
      fprintf(stderr,"*** Error: awaicgen_parse_args: mosaic linear %s %s\n",
              "dimension (unrotated along N-S) is out of range",
              "or missing (-Y <input>).");
      AWAP_Stat->I_status = 1;
  }


  if( (AWAP_Const->RA_center >= 0.0) &&
      (AWAP_Const->RA_center <= 360.0) ) {
    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: RA of mosaic center = %f\n",
             AWAP_Const->RA_center);
  } else {
      fprintf(stderr,"*** Error: awaicgen_parse_args: RA of mosaic center %s\n",
              "is out of range or missing (-R <input>).");
      AWAP_Stat->I_status = 1;
  }


  if( fabs(AWAP_Const->Dec_center) <= 90.0 ) {
    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: Dec of mosaic center = %f\n",
             AWAP_Const->Dec_center);
  } else {
      fprintf(stderr,"*** Error: awaicgen_parse_args: Dec of mosaic center %s\n",
              "is out of range or missing (-D <input>).");
      AWAP_Stat->I_status = 1;
  }


  if( (AWAP_Const->Mosaic_Rot >= 0.0) &&
      (AWAP_Const->Mosaic_Rot <= 360.0) ) {
    if(AWAP_Stat->I_Verbose) {
      printf("awaicgen_parse_args: CROTA2 about mosaic center = %f\n",
             AWAP_Const->Mosaic_Rot);
    }
  } else {
    fprintf(stderr,"*** Error: awaicgen_parse_args: CROTA2 about mosaic %s\n",
            "center is out of range (-C <input>).");
    AWAP_Stat->I_status = 1;
  }


  if( (AWAP_Const->Simple_Flag == 0) ||
      (AWAP_Const->Simple_Flag == 1) ) {
    if(AWAP_Stat->I_Verbose) {
      printf("awaicgen_parse_args: simple (area-weighted) co-add %s = %d\n",
             "creation flag", AWAP_Const->Simple_Flag);
    }       
  } else {  
    fprintf(stderr,"*** Error: awaicgen_parse_args: simple co-add %s\n",
            "creation flag is out of range (-sc <input>).");
    AWAP_Stat->I_status = 1;
  }


  if( (AWAP_Const->Weight_Flag == 0) ||
      (AWAP_Const->Weight_Flag == 1) ) {
    if(AWAP_Stat->I_Verbose) {
      printf("awaicgen_parse_args: Inverse variance weighting flag = %d\n",
             AWAP_Const->Weight_Flag);
    }
  } else {
    fprintf(stderr,"*** Error: awaicgen_parse_args: Inverse variance %s\n",
            "weighting flag is out of range (-wf <input>).");
    AWAP_Stat->I_status = 1;
  }


  if( strcmp(AWAP_Fnames->Filename_Output_Stddev,"") &&
      !AWAP_Const->Simple_Flag ) {
    fprintf(stderr,"*** Error: awaicgen_parse_args: Output %s %s %s %s\n",
            "standard-deviation image:", AWAP_Fnames->Filename_Output_Stddev,
            "is only allowed if simple co-add flag was specified",
            "(-sc 1).");
    AWAP_Stat->I_status = 1;
  } else {
    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: Output standard-deviation %s = %s\n",
             "mosaic filename", AWAP_Fnames->Filename_Output_Stddev);
  }


  /* Force cell-grid pixel size to final output mosaic pixel size if
     simple (area-weighted) co-add requested. */

  if( AWAP_Const->Simple_Flag )
    AWAP_Const->Mosaic_CellFact = 1.0;


  if( AWAP_Const->Simple_Flag && (AWAP_Const->Mosaic_PixScal == -99.99) ) {
    fprintf(stderr,"*** Error: awaicgen_parse_args: simple co-add %s %s\n",
            "creation flag was set (-sc 1), but no output mosaic pixel size",
            "was specified (-pa <input>).");
    AWAP_Stat->I_status = 1;
  }


  if( AWAP_Const->Mosaic_PixScal == -99.99 ) {
    if( (AWAP_Const->Mosaic_PixFact >= MINPIXFACT) &&
        (AWAP_Const->Mosaic_PixFact <= 1.0) ) {
      if(AWAP_Stat->I_Verbose) {
        printf("awaicgen_parse_args: mosaic pixel scale factor = %f\n",
               AWAP_Const->Mosaic_PixFact);
      }
    } else {
      fprintf(stderr,"*** Error: awaicgen_parse_args: %s %s %f <= ps <= 1.0\n",
              "mosaic pixel scale factor is out of range (-ps <input>).",
              "Allowed range is", MINPIXFACT);
      AWAP_Stat->I_status = 1;
    }
  } else {
    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: mosaic pixel size = %f %s\n",
             AWAP_Const->Mosaic_PixScal, "arcsec");
  }


  if( (AWAP_Const->Mosaic_CellFact >= MINCELLFACT) &&
      (AWAP_Const->Mosaic_CellFact <= 1.0) ) {
    if(AWAP_Stat->I_Verbose) {
      printf("awaicgen_parse_args: mosaic sub-pixel scale factor = %f\n",
             AWAP_Const->Mosaic_CellFact);
    }
  } else {
    fprintf(stderr,"*** Error: awaicgen_parse_args: %s %s %f <= pc <= 1.0\n",
            "mosaic cell-pixel scale factor is out of range (-pc <input>).",
            "Allowed range is", MINCELLFACT);
    AWAP_Stat->I_status = 1;
  }

  
  if( !AWAP_Const->Simple_Flag && (AWAP_Const->Ldriz != 1.0) ) {
    fprintf(stderr,"*** Error: awaicgen_parse_args: drizzling of input %s %s\n",
            "pixels only possible for simple (overlap-area weighted)",
            "coadds where -sc 1 needs to be set.");
    AWAP_Stat->I_status = 1;
  }


  if( AWAP_Const->Ldriz > 1.0 ) {
    fprintf(stderr,"*** Error: awaicgen_parse_args: linear drizzle factor %s\n",
            "must be <= 1.");
    AWAP_Stat->I_status = 1;
  } else {
    if( AWAP_Const->Simple_Flag )
      if(AWAP_Stat->I_Verbose)
        printf("awaicgen_parse_args: linear drizzle factor = %f\n",  
               AWAP_Const->Ldriz);
  }


  if( !AWAP_Const->Simple_Flag )
    if( (AWAP_Const->PRFScal_Tol > 0.0) &&
        (AWAP_Const->PRFScal_Tol <= 0.1) ) {
      if(AWAP_Stat->I_Verbose) {
        printf("awaicgen_parse_args: PRF to cell-grid pixel %s = %f\n",
               "difference tolerance", AWAP_Const->PRFScal_Tol);
      }
    } else {
      fprintf(stderr,"*** Error: awaicgen_parse_args: PRF to cell-grid %s %s\n",
              "pixel difference tolerance is out of range (-ct <input>).",
              "Must be <= 0.1.");
      AWAP_Stat->I_status = 1;
    }


  if( (AWAP_Const->Flxscal_Flag == 0) ||
      (AWAP_Const->Flxscal_Flag == 1) ) {
    if(AWAP_Stat->I_Verbose) {
      printf("awaicgen_parse_args: pixel flux scale flag = %d\n",
             AWAP_Const->Flxscal_Flag);
    }
  } else {
    fprintf(stderr,"*** Error: awaicgen_parse_args: pixel flux scaling %s\n",
            "option flag is out of range (-sf <input>).");
    AWAP_Stat->I_status = 1;
  }


  if( !AWAP_Const->Simple_Flag )
    if( AWAP_Const->Num_Iter >= 1 ) {
      if(AWAP_Stat->I_Verbose) {
        printf("awaicgen_parse_args: Number of MCM iterations = %d\n",
               AWAP_Const->Num_Iter);
      }
    } else {
      fprintf(stderr,"*** Error: awaicgen_parse_args: Number of MCM %s\n",
              "iterations is out of range (-n <input>).");
      AWAP_Stat->I_status = 1;
    }


  if( !AWAP_Const->Simple_Flag )
    if( (AWAP_Const->RotPRF_Flag == 0) ||
        (AWAP_Const->RotPRF_Flag == 1) ) {
      if(AWAP_Stat->I_Verbose) {
        printf("awaicgen_parse_args: rotate PRF flag = %d\n",
               AWAP_Const->RotPRF_Flag);
      }
    } else {
      fprintf(stderr,"*** Error: awaicgen_parse_args: rotate PRF %s\n",
              "option flag is out of range (-rf <input>).");
      AWAP_Stat->I_status = 1;
    }


  if( !AWAP_Const->Simple_Flag )
    if( (AWAP_Const->Interp_Method == 0) ||
        (AWAP_Const->Interp_Method == 1) ) {
      if(AWAP_Stat->I_Verbose) {
        printf("awaicgen_parse_args: interpolation method = %d\n",
               AWAP_Const->Interp_Method);
      }
    } else {
      fprintf(stderr,"*** Error: awaicgen_parse_args: interpolation method %s\n",
              "option is out of range (-if <input>).");
      AWAP_Stat->I_status = 1;
    }


  if( !AWAP_Const->Simple_Flag ) {

    reset_interp_meth = 0;
  
    if( (AWAP_Const->RotPRF_Flag == 1) &&
        (AWAP_Const->Interp_Method == 1) ) {
      fprintf(stderr,"=== Warning: awaicgen_parse_args: cannot use %s %s %s\n",
              "interpolation method 1 (area-overlap) when rotating PRF from",
              "input frame to map onto cell grid. Defaulting to method 0",
              "(nearest neighbor) interpolation.");
      reset_interp_meth = 1;
    }

    if( (AWAP_Const->Num_Iter > 1) &&
        (AWAP_Const->Interp_Method == 1) ) {
      fprintf(stderr,"=== Warning: awaicgen_parse_args: cannot use %s %s %s\n",
              "interpolation method 1 (area-overlap) when creating co-add",
              "using >1 MCM iterations. Defaulting to method 0", 
              "(nearest neighbor) interpolation.");
      reset_interp_meth = 1;
    }

    if( reset_interp_meth )
      AWAP_Const->Interp_Method = 0;
  }


  if( AWAP_Const->NumThreads >= 1 ) {
    if(AWAP_Stat->I_Verbose)
      printf("awaicgen_parse_args: number of concurrent threads = %d\n",
             AWAP_Const->NumThreads);
  } else {
      fprintf(stderr,"*** Error: awaicgen_parse_args: number of %s %s\n",
              "concurrent threads to spawn is outside allowed range",
              "(-nt <input>); must be >= 1.");
      AWAP_Stat->I_status = 1;
  }


  if(AWAP_Stat->I_Verbose) {
    printf("awaicgen_parse_args: Debug switch = %d\n", AWAP_Stat->I_Debug); 

    printf("awaicgen_parse_args: Verbose switch = %d\n", AWAP_Stat->I_Verbose);
  }


  if(AWAP_Stat->I_status)
    return 0;

}
