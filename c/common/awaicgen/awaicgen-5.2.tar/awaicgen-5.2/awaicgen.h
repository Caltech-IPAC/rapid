
/***********************************************
awaicgen.h

Purpose

Define some constant values and strings.

***********************************************/

#define	VERSN		         5.2
#define PROGRAM                  "awaicgen"
#define PURPOSE                  "A generic WISE Astronomical Image Coadder"
#define PERSON                   "Frank J. Masci, fmasci@caltech.edu"

/* following is used to define maximum length of input /paths/filenames. */

#define	STRING_BUFFER_SIZE	 256

/* maximum linear mosaic dimension in degrees below which SIN and TAN
   projections give scale distortions <~1% and <~2% respectively. */

#define MAXMOSAICDIM             180.0

/* maximum tolerance for difference in sum of input pixel values in 
   any PRF from unity. */ 

#define UNITSUMTOL               1.0e-05

/* Minimum value for ratio of output mosaic pixel scale to input image
   pixel scale. */

#define MINPIXFACT               0.1

/* Minimum value for ratio of internal cell grid pixel scale to output 
   mosaic pixel scale. */

#define MINCELLFACT              0.2

/* Value to set in output 8-bit mask for omitted (bad) input pixels that
   are not saturated. */

#define OUTMSKBAD                1

/* Value to set in output 8-bit mask for omitted input pixels that 
   are saturated. */

#define OUTMSKSAT                100

