
/*********************************************** 
awaicgen_log_writer.c

Purpose

Summarize processing parameters and status to stdout.

***********************************************/

#include <stdio.h>
#include <string.h>
#include "awaicgen.h"
#include "awaicgen_defs.h"

awaicgen_log_writer(int            argc,
                 AWA_Constants  *AWAP_Const,
		 AWA_Status     *AWAP_Stat,
		 AWA_Filenames  *AWAP_Fnames)
{
  if(argc <= 3)
    return 0;

/*----------------------------------------------------------------------*/
/* Write processing log/summary to stdout. */

 if( AWAP_Stat->I_Verbose ) {

  printf("\n%s: %s, Version %2.1f\n", PROGRAM, PURPOSE, VERSN);

  if(strcmp(AWAP_Fnames->Filename_FITS_Image_List,""))
    printf("  Input image list = %s\n",
           AWAP_Fnames->Filename_FITS_Image_List);

  if( !AWAP_Const->Simple_Flag )
    if(strcmp(AWAP_Fnames->Filename_FITS_PRF_List,""))
      printf("  Input PRF image list = %s\n",
             AWAP_Fnames->Filename_FITS_PRF_List);

  if(strcmp(AWAP_Fnames->Filename_FITS_Uncert_List,""))
    printf("  Input uncertainty image list = %s\n",
           AWAP_Fnames->Filename_FITS_Uncert_List);

  if(strcmp(AWAP_Fnames->Filename_FITS_Mask_List,""))
    printf("  Input mask image list = %s\n",             
           AWAP_Fnames->Filename_FITS_Mask_List);

  if(strcmp(AWAP_Fnames->Filename_Input_MosaicCell,""))
    printf("  Input starting model image for MCM = %s\n",
           AWAP_Fnames->Filename_Input_MosaicCell);

  if(strcmp(AWAP_Fnames->Filename_Output_Mosaic,""))
    printf("  Output mosaic image filename = %s\n",
           AWAP_Fnames->Filename_Output_Mosaic);

  if(strcmp(AWAP_Fnames->Filename_Output_Coverage,""))
    printf("  Output mosaic coverage map filename = %s\n",
           AWAP_Fnames->Filename_Output_Coverage);

  if(strcmp(AWAP_Fnames->Filename_Output_Uncert,""))
    printf("  Output mosaic uncert. image filename = %s\n",
           AWAP_Fnames->Filename_Output_Uncert);

  if( strcmp(AWAP_Fnames->Filename_Output_Stddev,"") &&
      AWAP_Const->Simple_Flag )
    printf("  Output mosaic standard-deviation image filename = %s\n",
           AWAP_Fnames->Filename_Output_Stddev);

  if( AWAP_Const->want_corr )
    printf("  Output mosaic filename of MCM correction-factors = %s\n",
           AWAP_Fnames->Filename_Output_Corr);

  if( AWAP_Const->want_cffv )
    printf("  Output mosaic filename of MCM uncertainties (from CFV) = %s\n",
           AWAP_Fnames->Filename_Output_CFVUncert);

  if(strcmp(AWAP_Fnames->Filename_Output_MosaicCell,""))
    printf("  Output mosaic image base-filename in cell-grid frame = %s\n",
           AWAP_Fnames->Filename_Output_MosaicCell);

  if(strcmp(AWAP_Fnames->Filename_Output_MosaicCFV,""))
    printf("  Output CFV image base-filename in cell-grid frame = %s\n",
           AWAP_Fnames->Filename_Output_MosaicCFV);

  if(strcmp(AWAP_Fnames->Filename_Output_MosaicCOR,""))
    printf("  Output correction-fact base-filename in cell-grid frame = %s\n",
           AWAP_Fnames->Filename_Output_MosaicCOR);

  if(strcmp(AWAP_Fnames->Filename_Output_MosaicIter,""))
    printf("  Output position-dependent iteration-number image in %s = %s\n",
           "cell-grid frame", AWAP_Fnames->Filename_Output_MosaicIter);

  if( strcmp(AWAP_Fnames->Filename_Output_MosaicFIter,"") &&
      (AWAP_Const->Num_Iter > 1) )
    printf("  Output first MCM iteration intensity image in %s = %s\n",
           "down-sampled frame", AWAP_Fnames->Filename_Output_MosaicFIter);

  if( AWAP_Const->want_msk )
    printf("  Output mosaic mask = %s\n",
           AWAP_Fnames->Filename_Output_MosaicMsk);

  printf("  Fatal bitstring mask template = %d\n",
         AWAP_Const->Fatal_Bits);

  if( AWAP_Const->Sat_Bits > 0 )
    printf("  Saturated fatal bitstring mask template = %d\n",
           AWAP_Const->Sat_Bits);

  printf("  Number of significant figures to retain in output %s %d\n",
         "coverage (-o2) and uncertainty (-o3) pixels =",
         AWAP_Const->SigFig);

  printf("  mosaic linear dimension %s = %f\n",
         "(unrotated along E-W)",AWAP_Const->Mosaic_SizeX);

  printf("  mosaic linear dimension %s = %f\n",
         "(unrotated along N-S)",AWAP_Const->Mosaic_SizeY);

  printf("  RA of mosaic center = %f\n", AWAP_Const->RA_center);

  printf("  Dec of mosaic center = %f\n", AWAP_Const->Dec_center);

  printf("  CROTA2 about mosaic center = %f\n", AWAP_Const->Mosaic_Rot);

  if( AWAP_Const->Mosaic_PixScal == -99.99 )
    printf("  mosaic pixel scale factor = %f\n", AWAP_Const->Mosaic_PixFact);
  else
    printf("  mosaic pixel size = %f %s\n", 
           3600.0*AWAP_Const->Mosaic_PixScal, "arcsec");

  if( !AWAP_Const->Simple_Flag )
    printf("  mosaic sub-pixel scale factor = %f\n",
           AWAP_Const->Mosaic_CellFact);

  if( !AWAP_Const->Simple_Flag )
    printf("  flag to create/use area-overlap weighted co-add for %s = %d\n",
           "MCM starting model", AWAP_Const->TophatPrior);

  printf("  inverse variance weighting flag = %d\n", AWAP_Const->Weight_Flag);

  printf("  pixel flux scaling flag = %d\n", AWAP_Const->Flxscal_Flag);

  printf("  simple (area-overlap weighted) co-add creation flag = %d\n",
         AWAP_Const->Simple_Flag);

  printf("  number of concurrent threads = %d\n", AWAP_Const->NumThreads);

  if( AWAP_Const->Simple_Flag )
    printf("  Linear drizzle factor = %f\n", AWAP_Const->Ldriz);

  if( !AWAP_Const->Simple_Flag )
    printf("  Number of MCM iterations = %d\n", AWAP_Const->Num_Iter);

  if( !AWAP_Const->Simple_Flag )
    printf("  Rotate PRF flag = %d\n", AWAP_Const->RotPRF_Flag);

  if( !AWAP_Const->Simple_Flag )
    printf("  PRF to cell-grid pixel difference tolerance = %f %s\n",
           AWAP_Const->PRFScal_Tol, "arcsec");

  if( !AWAP_Const->Simple_Flag )
    printf("  Interpolation method = %d\n", AWAP_Const->Interp_Method);

  if( AWAP_Const->want_corr &&
      AWAP_Const->want_cffv &&
     (AWAP_Const->Num_Iter > 1) )
    printf("  CFV percentage-difference threshold = %f%%\n",
           AWAP_Const->CFVpctdiff);
 }


/*----------------------------------------------------------------------*/
/* Write processing status information to stdout. */

  if( !AWAP_Stat->I_status )
    printf("%s, version %2.1f, %s\n\n",
            PROGRAM, VERSN, "executed successfully.");
  else
    fprintf(stderr,"*** Error: %s, version %2.1f, %s\n\n",
            PROGRAM, VERSN, "executed with errors.");

}
