
/*********************************************** 
awaicgen_compute_simpcoadd.c

Purpose

Contains function to support multi-threading for
co-add creation using exact overlap-area weighted
(top-hat) interpolation with optional drizzling
called from awaicgen_compute_results_simple.c.
Threading is performed over detector pixels of
an input image. 

***********************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "awaicgen.h"
#include "awaicgen_defs.h"
#include "wcs.h"
#include "two_plane.h"
#include "distort.h"

double overlap_area(double *, double *,
                    double, double, double, double, double);

awaicgen_compute_simpcoadd(AWA_Impix     *AWAP_Impix)
{
  float    **Cnum_j;
  float    **Vnum_j;
  float    **NV_j;
  float    **NSV_j;
  float    **N_j;
  float    **imgdata;
  float    **uncdata;
  long     **mskdata;

  float    D_i, M_i, V_i, S_i;

  double   D0_x, D0_y, D1_x, D1_y;
  double   D2_x, D2_y, D3_x, D3_y;
  double   CD0_x, CD0_y, CD1_x, CD1_y;
  double   CD2_x, CD2_y, CD3_x, CD3_y;
  double   CD_x[4], CD_y[4], area;
  double   Xj_min, Xj_max, Yj_min, Yj_max;
  double   D0_xc, D0_yc, D1_xc, D1_yc;
  double   D2_xc, D2_yc, D3_xc, D3_yc;
  double   CD0_xc, CD0_yc, CD1_xc, CD1_yc;
  double   CD2_xc, CD2_yc, CD3_xc, CD3_yc;
  double   CD_xc[4], CD_yc[4], covarea;
  double   Xj_minc, Xj_maxc, Yj_minc, Yj_maxc;

  long     i, ii, j, jj, k, po;
  int      offscl0, offscl1, offscl2, offscl3;
  int      Xmin, Xmax, Ymin, Ymax;  
  int      Xminc, Xmaxc, Yminc, Ymaxc;

  /* Store global/structure variables into local variables. */

  Cnum_j = AWAP_Impix->Cnum_j;
  Vnum_j = AWAP_Impix->Vnum_j;
  NV_j = AWAP_Impix->NV_j;
  NSV_j = AWAP_Impix->NSV_j;
  N_j = AWAP_Impix->N_j;
  imgdata = AWAP_Impix->imgdata;
  uncdata = AWAP_Impix->uncdata;
  mskdata = AWAP_Impix->mskdata;

  if( AWAP_Impix->st.I_Verbose )
    printf("awaicgen_compute_simpcoadd: thread %d: %s %ld <= k <= %ld\n",
           AWAP_Impix->threadid,"1D pixel index range to process:",
           AWAP_Impix->kstart,AWAP_Impix->kend);

/*----------------------------------------------------------------------*/
/* Transform each detector pixel in image m to cell grid frame using fast 
   WCS projection and compute its exact fractional areal overlap with the
   output grid pixels. */ 

  /* initalize number of input image pixels processed. */

  po = 0;

  for(ii = AWAP_Impix->iistart; ii <= AWAP_Impix->iiend; ii++) {
    for(i = 0; i < AWAP_Impix->cp.imgnaxis1; i++) {

     k = (ii * AWAP_Impix->cp.imgnaxis1) + i;
     if( (k >= AWAP_Impix->kstart) && (k <= AWAP_Impix->kend) ) {

      po++;

      /* measured flux in detector pixel at (x,y) = (i+1,ii+1). */

      D_i = imgdata[ii][i];

      /*
      printf("DBG: For image pixel at x,y = %ld,%ld, val = %f\n",
             i+1, ii+1, D_i);
      */

      /* initialize variances to 1 in case input uncertainties
         not given, otherwise use input for detector pixel at
         (x,y) = (i+1,ii+1). */

      V_i = 1.0;
      S_i = 1.0;

      if( AWAP_Impix->co.have_uncert && AWAP_Impix->co.Weight_Flag )
        V_i = uncdata[ii][i] * uncdata[ii][i];

      /* Following is for n = 1 uncertainty estimation with no 
         inverse variance weighting, i.e., Weight_Flag = 0. */

      if( AWAP_Impix->co.have_uncert && !AWAP_Impix->co.Weight_Flag )
        S_i = uncdata[ii][i] * uncdata[ii][i];

      /* initialize mask value to "not masked", otherwise, if input
         masks specified, use specific mask value for detector pixel
         at (x,y) = (i+1,ii+1). */

      M_i = 0.0;

      if( AWAP_Impix->co.have_masks )
        if( mskdata[ii][i] & AWAP_Impix->co.Fatal_Bits )
          M_i = 1.0;

      /* if input pixel D_i or variances V_i, S_i are NaNs or zero
         (regardless if input masks were specified), mask it! */

      if( (D_i != D_i) || (V_i != V_i) || (V_i == 0.0) || (S_i != S_i) )
        M_i = 1.0;

      /* only reproject and co-add input pixel D_i if it is not masked
         and not NaN'd. */

      if( M_i != 1.0 ) {

        /* Coords of the four corners of the input pixel. Starting at
           top right and going counter-clockwise (assumes the
           CDELT1 < 0 & CDELT2 > 0 convention). Also adjust input
           pixel size according to optional drizzle factor. */

        D0_x = i  + 1.5 - AWAP_Impix->Fdriz;
        D0_y = ii + 1.5 - AWAP_Impix->Fdriz;

        D1_x = i  + 0.5 + AWAP_Impix->Fdriz;
        D1_y = ii + 1.5 - AWAP_Impix->Fdriz;

        D2_x = i  + 0.5 + AWAP_Impix->Fdriz;
        D2_y = ii + 0.5 + AWAP_Impix->Fdriz;

        D3_x = i  + 1.5 - AWAP_Impix->Fdriz;
        D3_y = ii + 0.5 + AWAP_Impix->Fdriz;

        /* Also define coords of the original four corners if Fdriz > 0. 
           This is needed to get correct depth-of-coverage. */

        if( AWAP_Impix->Fdriz > 0.0 ) {

          D0_xc = i  + 1.5;
          D0_yc = ii + 1.5;

          D1_xc = i  + 0.5;
          D1_yc = ii + 1.5;

          D2_xc = i  + 0.5;
          D2_yc = ii + 0.5;

          D3_xc = i  + 1.5;
          D3_yc = ii + 0.5;
        }

        /*----------*/
        /* Project these corners to cell grid frame. Note: faster method
           used in AWOD module gives artifacts here, hence not good. */

        offscl0 = plane1_to_plane2_transform( D0_x, D0_y, &CD0_x, &CD0_y,
                                              &AWAP_Impix->twoplane );

        offscl1 = plane1_to_plane2_transform( D1_x, D1_y, &CD1_x, &CD1_y,
                                              &AWAP_Impix->twoplane );

        offscl2 = plane1_to_plane2_transform( D2_x, D2_y, &CD2_x, &CD2_y,
                                              &AWAP_Impix->twoplane );

        offscl3 = plane1_to_plane2_transform( D3_x, D3_y, &CD3_x, &CD3_y,
                                              &AWAP_Impix->twoplane );

        /* Store output corner coordinates in arrays. */
            
        CD_x[0] = CD0_x; CD_y[0] = CD0_y; 
        CD_x[1] = CD1_x; CD_y[1] = CD1_y;
        CD_x[2] = CD2_x; CD_y[2] = CD2_y;
        CD_x[3] = CD3_x; CD_y[3] = CD3_y;

        /* Also repeat above projection of corners to cell grid frame
           if Fdriz > 0 to get correct depth-of-coverage below. */

        if( AWAP_Impix->Fdriz > 0.0 ) {

          offscl0 = plane1_to_plane2_transform( D0_xc, D0_yc, &CD0_xc, &CD0_yc,
                                                &AWAP_Impix->twoplane );

          offscl1 = plane1_to_plane2_transform( D1_xc, D1_yc, &CD1_xc, &CD1_yc,
                                                &AWAP_Impix->twoplane );

          offscl2 = plane1_to_plane2_transform( D2_xc, D2_yc, &CD2_xc, &CD2_yc,
                                                &AWAP_Impix->twoplane );

          offscl3 = plane1_to_plane2_transform( D3_xc, D3_yc, &CD3_xc, &CD3_yc,
                                                &AWAP_Impix->twoplane );

          /* Store output corner coordinates in arrays. */

          CD_xc[0] = CD0_xc; CD_yc[0] = CD0_yc;
          CD_xc[1] = CD1_xc; CD_yc[1] = CD1_yc;
          CD_xc[2] = CD2_xc; CD_yc[2] = CD2_yc;
          CD_xc[3] = CD3_xc; CD_yc[3] = CD3_yc;
        }

        if( !offscl0 && !offscl1 && !offscl2 && !offscl3 ) {

          AWAP_Impix->ProjectionStatus = 1;

          /*----------*/
          /* Find the integral x, y coordinate range of the output (grid 
             frame) pixels overlapping with this input pixel. These are
             in zero-based array coordinates. See below for equivalent
             for Fdriz > 0 case to get depth-of-coverage correct. */

          Xmin = (int)(fmin(fmin(CD0_x, CD1_x),fmin(CD2_x, CD3_x)) + 0.5) - 1; 
          Xmax = (int)(fmax(fmax(CD0_x, CD1_x),fmax(CD2_x, CD3_x)) + 0.5) - 1;
          Ymin = (int)(fmin(fmin(CD0_y, CD1_y),fmin(CD2_y, CD3_y)) + 0.5) - 1;
          Ymax = (int)(fmax(fmax(CD0_y, CD1_y),fmax(CD2_y, CD3_y)) + 0.5) - 1;

          /*----------*/
          /* For this (optionally drizzled) detector pixel and all 
             overlapping output pixels, compute the (unit-normalized)
             area overlaps and update the output cell grid arrays. */

          if( (Xmin >= 0) && (Xmax < AWAP_Impix->cp.cellnaxis1) &&
              (Ymin >= 0) && (Ymax < AWAP_Impix->cp.cellnaxis2) ) {

            for( jj = Ymin; jj <= Ymax; jj++ ) {
              for( j = Xmin; j <= Xmax; j++ ) {

                /* Bounding box for each cell grid pixel. */

                Xj_min = j  + 0.5;
                Xj_max = j  + 1.5;
                Yj_min = jj + 0.5;
                Yj_max = jj + 1.5;

                /* Compute exact overlap area. The N_j array
                   needs the overlap area with the original/
                   native pixel. See below for Fdriz > 0 case. */

                area = overlap_area(CD_x,CD_y,Xj_min,Xj_max,Yj_min,Yj_max,1);

                Cnum_j[jj][j] += ((area * D_i) / V_i);
                Vnum_j[jj][j] += ((area * D_i * D_i) / V_i);
                NSV_j[jj][j] += ((area * area * S_i) / V_i); 
                NV_j[jj][j] += (area / V_i);

                if( AWAP_Impix->Fdriz == 0.0 )
                  N_j[jj][j] += area;
              }
            }

          } /* end of "if output pixels fall in cell grid" statement. */

          /*----------*/
          /* Repetition of above for Fdriz > 0 case to get coverage 
             array correct: Find the integral x,y coordinate range 
             of the output (grid frame) pixels overlapping with this 
             input pixel. These are in zero-based array coordinates. */

          if( AWAP_Impix->Fdriz > 0.0 ) {

            Xminc = (int)(fmin(fmin(CD0_xc,CD1_xc),fmin(CD2_xc,CD3_xc))+0.5)-1;
            Xmaxc = (int)(fmax(fmax(CD0_xc,CD1_xc),fmax(CD2_xc,CD3_xc))+0.5)-1; 
            Yminc = (int)(fmin(fmin(CD0_yc,CD1_yc),fmin(CD2_yc,CD3_yc))+0.5)-1;
            Ymaxc = (int)(fmax(fmax(CD0_yc,CD1_yc),fmax(CD2_yc,CD3_yc))+0.5)-1;

            /*----------*/
            /* For this "original" detector pixel and all overlapping 
               output pixels, compute the (unit-normalized) area overlaps 
               and update the N_j cell grid array only. */

            if( (Xminc >= 0) && (Xmaxc < AWAP_Impix->cp.cellnaxis1) &&
                (Yminc >= 0) && (Ymaxc < AWAP_Impix->cp.cellnaxis2) ) {

              for( jj = Yminc; jj <= Ymaxc; jj++ ) {
                for( j = Xminc; j <= Xmaxc; j++ ) {

                  /* Bounding box for each cell grid pixel. */

                  Xj_minc = j  + 0.5;
                  Xj_maxc = j  + 1.5;
                  Yj_minc = jj + 0.5;
                  Yj_maxc = jj + 1.5;

                  /* Compute exact overlap area. */

                  covarea = overlap_area(CD_xc, CD_yc, Xj_minc, Xj_maxc,
                                         Yj_minc, Yj_maxc, 1);

                  N_j[jj][j] += covarea;
                }
              }

            } /* end of "if output pixels fall in cell grid" statement. */

          } /* end of Fdriz > 0 case for correct coverage-depth arrays. */

        } /* end of "if not offscale" statement. */

      } /* end of "if not masked pixel" statement. */

     } /* end of "k>=kstart && k<=kend" statement. */

    } /* end of loop for x pos. of D_i pixel. */

  } /* end of loop for y pos. of D_i pixel. */

  if( AWAP_Impix->st.I_Verbose )
    printf("awaicgen_compute_simpcoadd: thread %d: %s %ld\n",AWAP_Impix->threadid,
           "number of input image pixels processed =",po);

  /* Store updated outputs back into global/structure variables. */

  AWAP_Impix->Vnum_j = Vnum_j;
  AWAP_Impix->Cnum_j = Cnum_j;
  AWAP_Impix->NV_j = NV_j;
  AWAP_Impix->NSV_j = NSV_j;
  AWAP_Impix->N_j = N_j;

}
