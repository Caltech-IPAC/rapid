
/*********************************************** 
awaicgen_store_img_fnames.c

Purpose

Store the filenames for the detector images, 
uncertainty images and mask images (if these two
are specified) in memory. Check that we have the 
same number for each.

Detector images, uncerts and masks are expected
to be in 1-to-1 correspondence across all input
lists. Also, all are expected to have the same native
pixel scale (CDELTs = pixel scale at image centers),
same CTYPEs, same NAXIS1,2s and same EQUINOX. This is
not explicitly checked.

***********************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "awaicgen.h"
#include "awaicgen_defs.h"
#include "fitsio.h"
#include "wcs.h"

awaicgen_store_img_fnames(AWA_Constants    *AWAP_Const,
                       AWA_Filenames    *AWAP_Fnames,
                       AWA_Computation  *AWAP_Comp,
		       AWA_Status       *AWAP_Stat)
{
  struct   WorldCoor *wcsinput;

  char     imagefile[STRING_BUFFER_SIZE];
  char     *inheaderfits;

  FILE     *fp_file;
  fitsfile *ffp_FITS_In;
  int      i, status=0;


  if(AWAP_Stat->I_status) 
    return 0;

/*----------------------------------------------------------------------*/
/* Read detector image filenames to find their total number. Also store
   some generic WCS keywords for use later from the first listed image. */

  if((fp_file = fopen(AWAP_Fnames->Filename_FITS_Image_List,"r")) == NULL) {
    fprintf(stderr,"*** Error: awaicgen_store_img_fnames: input detector %s\n",
            "image list file could not be opened.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    i = 0;
    while( !feof(fp_file) ) {

      strcpy(imagefile, "");

      fscanf(fp_file, "%s", imagefile);

      if( strcmp(imagefile,"") ) {

        if( AWAP_Stat->I_Verbose )
          printf("awaicgen_store_img_fnames: reading filename %d: %s %s\n",
                 i+1, imagefile, "...");

        if( i == 0 ) {

          if( AWAP_Stat->I_Verbose )
            printf("awaicgen_store_img_fnames: storing generic WCS %s %s %s\n",
                   "keywords from", imagefile,"...");

          fits_open_file(&ffp_FITS_In, imagefile, READONLY, &status);
          if( status ) {
            fprintf(stderr,"*** Error: awaicgen_store_img_fnames: %s %s; %s %d\n",
                    "error opening FITS file:", imagefile,
                    "FITS error code =", status);
            AWAP_Stat->I_status = 1;
            return 0;
          }

          fits_get_image_wcs_keys(ffp_FITS_In, &inheaderfits, &status);
          if( status ) {
            fprintf(stderr,"*** Error: awaicgen_store_img_fnames: %s %s; %s %d\n",
                    "error reading FITS header:", imagefile,
                    "FITS error code =", status);
            AWAP_Stat->I_status = 1;
            return 0;
          }

          wcsinput = wcsinit(inheaderfits);

          /* Ensure that projection type is one of the five zenithal
             projections supported by the fast projection library. */

          if( (strcmp(wcsinput->ptype, "TAN") != 0) && 
              (strcmp(wcsinput->ptype, "SIN") != 0) && 
              (strcmp(wcsinput->ptype, "ZEA") != 0) &&
              (strcmp(wcsinput->ptype, "STG") != 0) &&
              (strcmp(wcsinput->ptype, "ARC") != 0) ) {
            /*
            fprintf(stderr,"*** Error: %s %s (%s) %s %s\n",
                    "awaicgen_store_img_fnames:",
                    "input image projection", wcsinput->ptype,
                    "must be: TAN, SIN, ZEA, STG or ARC to",
                    "support fast reprojection.");
            AWAP_Stat->I_status = 1;
            return 0;
            */

            fprintf(stderr,"=== Warning: %s %s (%s) %s %s\n",
                    "awaicgen_store_img_fnames:",
                    "input image projection", wcsinput->ptype,
                    "must be: TAN, SIN, ZEA, STG or ARC to",
                    "support fast reprojection");

            /* If we had CTYPEn ~ -TPV, we replace it with
               -TAN and continue, with caveat that PV distortion
               polynomial is ignored and will cause innaccuracies! */

            if( strcmp(wcsinput->ptype, "TPV") == 0 ) {
              fprintf(stderr,"=== Warning: %s %s %s\n",
                      "awaicgen_store_img_fnames: detected \"TPV\" in CTYPEs;",
                      "proceeding to replace with \"TAN\" and",
                      "PV distortion polymonial will be ignored!");

              strcpy(wcsinput->ctype[0], "RA---TAN");
              strcpy(wcsinput->ctype[1], "DEC--TAN");

              fprintf(stderr,"=== Warning: %s %s, %s\n",
                      "awaicgen_store_img_fnames: reset CTYPE1,2 values to",
                      wcsinput->ctype[0], wcsinput->ctype[1]);
            }
          }

          strcpy( AWAP_Comp->imgctype1, wcsinput->ctype[0]);

          strcpy( AWAP_Comp->imgctype2, wcsinput->ctype[1]);

          AWAP_Comp->imgcdelt1 = wcsinput->xinc;

          AWAP_Comp->imgcdelt2 = wcsinput->yinc;

          AWAP_Comp->imgequinox = wcsinput->equinox;

          AWAP_Comp->imgnaxis1 = wcsinput->nxpix;

          AWAP_Comp->imgnaxis2 = wcsinput->nypix;

          wcsfree(wcsinput);

          /* Check that sign of CDELTs conforms to convention. */

          /*
          if( !((AWAP_Comp->imgcdelt1 < 0.0) &&
                (AWAP_Comp->imgcdelt2 > 0.0)) ) {
            fprintf(stderr,"*** Error: awaicgen_store_img_fnames: %s \n",
                    "CDELT1 < 0 and CDELT2 > 0 convention not followed.");
            AWAP_Stat->I_status = 1;
            return 0;
          }
          */

          fits_close_file(ffp_FITS_In, &status);
          if( status ) {
            fprintf(stderr,"*** Error: awaicgen_store_img_fnames: %s %s; %s %d\n",
                    "error closing FITS file:", imagefile,
                    "FITS error code =", status);
            AWAP_Stat->I_status = 1;
            return 0;
          }
        }

        i++;
      }
    }
  }

  if( fclose(fp_file) ) {
    fprintf(stderr,"*** Error: awaicgen_store_img_fnames: input detector %s\n",
            "image list file could not be closed.");
    AWAP_Stat->I_status = 1;
    return 0;
  }

  AWAP_Comp->numimages = i;

  if( AWAP_Comp->numimages == 0 ) {
    fprintf(stderr,"*** Error: awaicgen_store_img_fnames: input %s\n",
            "detector image list appears empty!");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose )
      printf("awaicgen_store_img_fnames: read %d %s %s\n",
             AWAP_Comp->numimages, "detector image filenames from",
             AWAP_Fnames->Filename_FITS_Image_List);
  }


/*----------------------------------------------------------------------*/
/* Read uncertainty image filenames to find their total number 
   if specified. */

  if( AWAP_Const->have_uncert ) {

    if((fp_file = fopen(AWAP_Fnames->Filename_FITS_Uncert_List,"r"))==NULL) {
      fprintf(stderr,"*** Error: awaicgen_store_img_fnames: input %s\n",
              "uncertainty image list file could not be opened.");
      AWAP_Stat->I_status = 1;
      return 0;

    } else {

      i = 0;
      while( !feof(fp_file) ) {

        strcpy(imagefile, "");

        fscanf(fp_file, "%s", imagefile);

        if( strcmp(imagefile,"") ) {

          if( AWAP_Stat->I_Verbose )
            printf("awaicgen_store_img_fnames: read filename %d: %s %s\n",
                   i+1, imagefile, "...");

          i++;
        }
      }
    }

    if( fclose(fp_file) ) {
      fprintf(stderr,"*** Error: awaicgen_store_img_fnames: input %s\n",
              "uncertainty image list file could not be closed.");
      AWAP_Stat->I_status = 1;
      return 0;
    }

    AWAP_Comp->numuncerts = i;

    if( AWAP_Comp->numuncerts == 0 ) {
      fprintf(stderr,"*** Error: awaicgen_store_img_fnames: input %s\n",
              "uncertainty image list appears empty!");
      AWAP_Stat->I_status = 1;
      return 0;

    } else {

      if( AWAP_Stat->I_Verbose )
        printf("awaicgen_store_img_fnames: read %d uncertainty %s %s\n",
               AWAP_Comp->numuncerts, "image filenames from",
               AWAP_Fnames->Filename_FITS_Uncert_List);
    }
  }


/*----------------------------------------------------------------------*/
/* Read mask image filenames to find their total number if specified. */ 

  if( AWAP_Const->have_masks ) {

    if((fp_file = fopen(AWAP_Fnames->Filename_FITS_Mask_List,"r"))==NULL) {
      fprintf(stderr,"*** Error: awaicgen_store_img_fnames: input mask %s\n",
              "image list file could not be opened.");
      AWAP_Stat->I_status = 1;
      return 0;

    } else {

      i = 0;
      while( !feof(fp_file) ) {

        strcpy(imagefile, "");

        fscanf(fp_file, "%s", imagefile);

        if( strcmp(imagefile,"") ) {

          if( AWAP_Stat->I_Verbose )
            printf("awaicgen_store_img_fnames: read filename %d: %s %s\n",
                   i+1, imagefile, "...");

          i++;
        }
      }
    }

    if( fclose(fp_file) ) {
      fprintf(stderr,"*** Error: awaicgen_store_img_fnames: input mask %s\n",
              "image list file could not be closed.");
      AWAP_Stat->I_status = 1;
      return 0;
    }

    AWAP_Comp->nummasks = i;

    if( AWAP_Comp->nummasks == 0 ) {
      fprintf(stderr,"*** Error: awaicgen_store_img_fnames: input mask %s\n",
              "image list appears empty!");
      AWAP_Stat->I_status = 1;
      return 0;

    } else {

      if( AWAP_Stat->I_Verbose )
        printf("awaicgen_store_img_fnames: read %d mask %s %s\n",
               AWAP_Comp->nummasks, "image filenames from",
               AWAP_Fnames->Filename_FITS_Mask_List);
    }
  }


/*----------------------------------------------------------------------*/
/* Check that the number of input images, uncerts and masks (if specified)
   are all equal. */

  if( AWAP_Const->have_uncert &&
     (AWAP_Comp->numuncerts != AWAP_Comp->numimages) ) {
    fprintf(stderr,"*** Error: awaicgen_store_img_fnames: number of input %s\n",
            "uncertainty images does not match number of detector images!");
    AWAP_Stat->I_status = 1;
    return 0;
  }

  if( AWAP_Const->have_masks &&
     (AWAP_Comp->nummasks != AWAP_Comp->numimages) ) {
    fprintf(stderr,"*** Error: awaicgen_store_img_fnames: number of input %s\n",
            "mask images does not match number of detector images!");
    AWAP_Stat->I_status = 1;
    return 0;
  }


/*----------------------------------------------------------------------*/
/* Store detector image filenames. */

  AWAP_Fnames->Filename_FITS_Image = malloc(AWAP_Comp->numimages *
                                   sizeof(*AWAP_Fnames->Filename_FITS_Image));

  if( AWAP_Fnames->Filename_FITS_Image == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_store_img_fnames: could not %s\n",
            "allocate memory for Filename_FITS_Image array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_store_img_fnames: allocated %10.8f MB for %s\n",
             (AWAP_Comp->numimages*STRING_BUFFER_SIZE*sizeof(char)/1.0E+06),
             "Filename_FITS_Image array.");
    }
  }

  if((fp_file = fopen(AWAP_Fnames->Filename_FITS_Image_List,"r")) == NULL) {
    fprintf(stderr,"*** Error: awaicgen_store_img_fnames: input detector %s\n",
            "image list file could not be opened.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {
  
    for( i = 0; i < AWAP_Comp->numimages; i++ ) {

      strcpy(imagefile, "");

      fscanf(fp_file, "%s", imagefile);

      if( strcmp(imagefile,"") ) {

        sprintf(AWAP_Fnames->Filename_FITS_Image[i], "%s", imagefile);

        if( AWAP_Stat->I_Verbose )
          printf("awaicgen_store_img_fnames: stored filename %d: %s\n",
                 i+1, imagefile);
      }
    }
  }

  if( fclose(fp_file) ) {
    fprintf(stderr,"*** Error: awaicgen_store_img_fnames: input detector %s\n",
            "image list file could not be closed.");
    AWAP_Stat->I_status = 1;
    return 0;
  }


/*----------------------------------------------------------------------*/
/* Store uncertainty image filenames if specified. */

  if( AWAP_Const->have_uncert ) {

    AWAP_Fnames->Filename_FITS_Uncert = malloc(AWAP_Comp->numuncerts *
                                   sizeof(*AWAP_Fnames->Filename_FITS_Uncert));

    if( AWAP_Fnames->Filename_FITS_Uncert == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_store_img_fnames: could not %s\n",
              "allocate memory for Filename_FITS_Uncert array.");
      AWAP_Stat->I_status = 1;
      return 0;

    } else {

      if( AWAP_Stat->I_Verbose ) {
        printf("awaicgen_store_img_fnames: allocated %10.8f MB for %s\n",
               (AWAP_Comp->numuncerts*STRING_BUFFER_SIZE*sizeof(char)/1.0E+06),
               "Filename_FITS_Uncert array.");
      }
    }

    if((fp_file = fopen(AWAP_Fnames->Filename_FITS_Uncert_List,"r"))==NULL) {
      fprintf(stderr,"*** Error: awaicgen_store_img_fnames: input %s\n",
              "uncertainty image list file could not be opened.");
      AWAP_Stat->I_status = 1;
      return 0;

    } else {

      for( i = 0; i < AWAP_Comp->numuncerts; i++ ) {

        strcpy(imagefile, "");

        fscanf(fp_file, "%s", imagefile);

        if( strcmp(imagefile,"") ) {
    
          sprintf(AWAP_Fnames->Filename_FITS_Uncert[i], "%s", imagefile);

          if( AWAP_Stat->I_Verbose )
            printf("awaicgen_store_img_fnames: stored filename %d: %s\n",
                   i+1, imagefile);
        }
      }
    }

    if( fclose(fp_file) ) {
      fprintf(stderr,"*** Error: awaicgen_store_img_fnames: input %s\n",
              "uncertainty image list file could not be closed.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }


/*----------------------------------------------------------------------*/
/* Store mask image filenames if specified. */

  if( AWAP_Const->have_masks ) {

    AWAP_Fnames->Filename_FITS_Mask = malloc(AWAP_Comp->nummasks *
                                  sizeof(*AWAP_Fnames->Filename_FITS_Mask));

    if( AWAP_Fnames->Filename_FITS_Mask == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_store_img_fnames: could not %s\n",
              "allocate memory for Filename_FITS_Mask array.");
      AWAP_Stat->I_status = 1;
      return 0;
  
    } else {

      if( AWAP_Stat->I_Verbose ) {
        printf("awaicgen_store_img_fnames: allocated %10.8f MB for %s\n",
               (AWAP_Comp->nummasks*STRING_BUFFER_SIZE*sizeof(char)/1.0E+06),
               "Filename_FITS_Mask array.");
      }
    }

    if((fp_file = fopen(AWAP_Fnames->Filename_FITS_Mask_List,"r"))==NULL) {
      fprintf(stderr,"*** Error: awaicgen_store_img_fnames: input mask %s\n",
              "image list file could not be opened.");
      AWAP_Stat->I_status = 1;
      return 0;

    } else {

      for( i = 0; i < AWAP_Comp->nummasks; i++ ) {

        strcpy(imagefile, "");

        fscanf(fp_file, "%s", imagefile);

        if( strcmp(imagefile,"") ) {
    
          sprintf(AWAP_Fnames->Filename_FITS_Mask[i], "%s", imagefile);

          if( AWAP_Stat->I_Verbose )
            printf("awaicgen_store_img_fnames: stored filename %d: %s\n",
                   i+1, imagefile);
        }
      }
    }

    if( fclose(fp_file) ) {
      fprintf(stderr,"*** Error: awaicgen_store_img_fnames: input mask %s\n",
              "image list file could not be closed.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

}
