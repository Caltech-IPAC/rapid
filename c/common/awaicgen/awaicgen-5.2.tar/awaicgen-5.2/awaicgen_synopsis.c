
/***********************************************
awaicgen_synopsis.c

Purpose

Describe command-line arguments, inputs, outputs and usage.

Synopsis is written to standard output if program is executed 
with fewer than 4 command-line arguments.

***********************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "awaicgen.h"
#include "awaicgen_defs.h"

awaicgen_synopsis(int           argc,
               char          **argv,
               AWA_Status    *AWAP_Stat)
{
  AWAP_Stat->I_status = 0;

  if(argc <= 3) {

    printf("\n%s, Version %2.1f\n", PURPOSE, VERSN);

    printf("\nUsage: %s\n", PROGRAM);

    printf(" -f1 <inp_image_list_fname>  (Required; list of images in FITS format)\n");

    printf(" -f2 <inp_mask_list_fname>   (Optional; list of bad-pixel masks in 32-bit INT\n %28s FITS format; only values 0 -> 2^31 are used)\n","");
    
    printf(" -f3 <inp_uncert_list_fname> (Optional; list of uncertainty images in\n %28s FITS format)\n","");
    
    printf(" -f4 <inp_prf_list_fname>    (Required; list of PRF FITS images each\n %28s labeled with location on array)\n","");

    printf(" -f5 <inp_mcm_mod_image>     (Optional; input starting model image to\n %28s support MCM; Default = flat image of 1's\n %28s if -fp 1 is not specified)\n","","");

    printf(" -fp <tophatprior_flag>      (Optional; create/use overlap-area weighted co-add\n %28s for MCM starting model: 1=yes, 0=no; Default=0)\n","");

    printf(" -m  <inp_fatalmask_bits>    (Optional; bitstring template specifying\n %28s pixels to omit as set in input masks; Default=0)\n","");

    printf(" -ms <inp_satmask_bits>      (Optional; bitstring template specifying\n %28s saturated pixels from input mask to tag\n %28s in output mask (-om); Default=0)\n","","");
    
    printf(" -X  <mosaic_size_x>         (Required [deg]; E-W mosaic dimension\n %28s for crota2=0)\n","");
    
    printf(" -Y  <mosaic_size_y>         (Required [deg]; N-S mosaic dimension\n %28s for crota2=0)\n","");
    
    printf(" -R  <RA_center>             (Required [deg]; RA of mosaic center)\n");
    
    printf(" -D  <Dec_center>            (Required [deg]; Dec. of mosaic center)\n");
    
    printf(" -C  <mosaic_rotation>       (Optional [deg]; in terms of crota2:\n %28s +Y axis W of N; Default=0)\n","");
    
    printf(" -ps <pixelscale_factor>     (Optional; output mosaic linear pixel scale\n %28s relative to input pixel scale; Default=0.5)\n","");

    printf(" -pa <pixelscale_absolute>   (Optional [asec]; output mosaic pixel scale\n %28s in absolute units; if specified, over-rides -ps)\n","");
    
    printf(" -pc <mos_cellsize_factor>   (Optional; for PRF placement: internal linear\n %28s cell pixel size relative to mosaic pixel size;\n %28s =input PRF pixel sizes (-f4); Default=0.5)\n","","");

    printf(" -d <drizzle_factor>         (Optional; input pixel linear drizzle factor;\n %28s =ratio: new pix scl/native pix scl (<= 1); only\n %28s used for simple coadds (-sc 1); Default=1.0)\n","","");

    printf(" -wf <inv_var_weight_flag>   (Optional; interp/combine input pixels using\n %28s inverse variance weighting: 1=yes, 0=no;\n %28s Default=0; if yes, requires -f3 input)\n","","");

    printf(" -sf <pixelflux_scale_flag>  (Optional; scale output pixel flux with pixel\n %28s size: 1=yes, 0=no; Default=0)\n","");

    printf(" -sc <simple_coadd_flag>     (Optional; create simple co-add/mosaic using exact\n %28s overlap-area weighting: 1=yes, 0=no; Default=0)\n","");

    printf(" -n  <num_mcm_iterations>    (Optional; number of MCM iterations;\n %28s Default=1 => coadd, no resolution enhancement)\n","");

    printf(" -nt <num_threads>           (Optional; number of concurrent threads to spawn;\n %28s set to number of CPU cores available; Default=1)\n","");

    printf(" -rf <rotate_prf_proj_flag>  (Optional; rotate PRF when projecting input\n %28s frame pixels: 1=yes, 0=no; recommended for -n > 1\n %28s if PRF severely non-axisymmetric; Default=0)\n","","");

    printf(" -ct <prf_cell_size_tol>     (Optional [asec]; maximum tolerance for difference\n %28s between cell-grid pixel size [-pc] and input\n %28s PRF pixel size; Default=0.0001 arcsec)\n","","");

    printf(" -if <interpolation_option>  (Optional; method for interpolating PRF onto\n %28s co-add cell-grid: 0=nearest neighbor,\n %28s 1=area-overlap weighting [only possible for\n %28s -n = 1 & -rf = 0]; Default=0)\n","","","");

    printf(" -t <unc_sigfigs_retained>   (Optional; number of significant figures to retain\n %28s in output coverages (-o2) and uncertainties (-o3)\n %28s to assist in compression; Default=0 => no change)\n","","");

    printf(" -h <cfv_pctdiff_thres>      (Optional; minimum tolerance for %% difference in\n %28s real CFV from iteration n -> n+1 below which MCM\n %28s pixel-cell arrays get frozen at n; aids in\n %28s noise-suppression; activated if -n > 1 and\n %28s -o5,-o6 specified; Default=0 => no suppression)\n","","","","");
    
    printf(" -o1 <out_mosaic_image>      (Required; output mosaic image FITS filename)\n");
    
    printf(" -o2 <out_mosaic_cov_map>    (Required; output mosaic coverage map FITS fname)\n");
    
    printf(" -o3 <out_uncert_mosaic>     (Optional; output uncertainty mosaic FITS fname;\n %28s only applicable to -n = 1 and -sc 1 co-adds;\n %28s based on input prior uncertainties)\n","","");

    printf(" -o4 <out_stddev_mosaic>     (Optional; output standard deviation mosaic\n %28s FITS filename; only possible under -sc 1;\n %28s N.B: will not account for correlated noise like\n %28s -o3 output. Latter accounts for movement of\n %28s noise-power to low freq.)\n","","","","");

    printf(" -o5 <out_corfac_mosaic>     (Optional; output mosaic of MCM correction-factors;\n %28s only valid when -n > 1)\n","");

    printf(" -o6 <out_cfvuncert_mosaic>  (Optional; output mosaic of data derived\n %28s MCM uncertainties (from CFV); only valid\n %28s when -n > 1)\n","","");

    printf(" -o7 <out_cellmosaic_image>  (Optional; output mosaic basename in upsampled\n %28s cell-grid frame; for debug or resuming MCM later;\n %28s will be appended with mcm iteration number)\n","","");

    printf(" -o8 <out_cellcfv_image>     (Optional; output CFV mosaic basename in upsampled\n %28s cell-grid frame for debug purposes; will be\n %28s appended with mcm iteration number)\n","","");

    printf(" -o9 <out_cellcor_image>     (Optional; output mosaic of MCM correction\n %28s factors in upsampled cell-grid frame;\n %28s will be appended with mcm iteration number)\n","","");

    printf(" -oi <out_celliter_image>    (Optional; output mosaic of position-dep iteration\n %28s numbers; only generated if -o5,-o6 specified)\n","");

    printf(" -of <out_firstmcm_image>    (Optional; output mosaic intensity image from\n %28s first MCM iteration; only generated for -n > 1)\n","");

    printf(" -om <out_mask_image>        (Optional; output 8-bit mosaic showing locations\n %28s of bad and saturated pixels that occur at least\n %28s once in stack; only applicable to -n = 1 co-adds)\n","","");

    printf(" -g                          (Optional; switch to print debug statements\n %28s to stdout and files)\n","");

    printf(" -v                          (Optional; switch to print more verbose output)\n\n");

    AWAP_Stat->I_status = 1;

    return 0;
  }

}
