
/*********************************************** 
awaicgen_write_mcmiter.c

Purpose

Write out 2D array: position-dependent "last-iteration"
cell array to FITS format. This image is for diagnostic 
purposes and contains no WCS keywords.

***********************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "awaicgen.h"
#include "awaicgen_defs.h"
#include "fitsio.h"

awaicgen_write_mcmiter(short int         **NlastIter_j,
                    AWA_Computation   *AWAP_Comp,
                    AWA_Filenames     *AWAP_Fnames,
                    AWA_Status        *AWAP_Stat)
{
  char     iter_str[20];
  char     outfitsname[STRING_BUFFER_SIZE];
  long     fimgpix[2], naxis, naxes[2]; 
  int      status=0;

  fitsfile *ffp_FITS_Out;


  if(AWAP_Stat->I_status)
    return 0;

/*----------------------------------------------------------------------*/
/* Generate FITS image. */

  strcpy(outfitsname, AWAP_Fnames->Filename_Output_MosaicIter);

  naxis = 2;
  naxes[0] = AWAP_Comp->cellnaxis1;
  naxes[1] = AWAP_Comp->cellnaxis2;
  fimgpix[0] = 1;
  fimgpix[1] = 1;

  if( AWAP_Stat->I_Verbose )
    printf("awaicgen_write_mcmiter: creating/writing FITS file for %s: %s %s\n",
           "last-iteration numbers in cell grid frame", outfitsname, "..."); 

  fits_create_file(&ffp_FITS_Out, outfitsname, &status);

  if( status ) {
    fprintf(stderr,"*** Error: awaicgen_write_mcmiter: error %s %s; %s %d\n",
            "creating FITS file:", outfitsname, "FITS error code =", status);
    AWAP_Stat->I_status = 1;
    return 0;
  }

  fits_create_img(ffp_FITS_Out, SHORT_IMG, naxis, naxes, &status);

  if( status ) {
    fprintf(stderr,"*** Error: awaicgen_write_mcmiter: error %s %s; %s %d\n",
            "creating FITS file image:", outfitsname, "FITS error code =",
            status);
    AWAP_Stat->I_status = 1;
    return 0;
  }

  for(fimgpix[1] = 1; fimgpix[1] <= naxes[1]; fimgpix[1]++) {

    fits_write_pix(ffp_FITS_Out, TSHORT, fimgpix, naxes[0],
                   NlastIter_j[fimgpix[1] - 1], &status);

    if( status ) {
      fprintf(stderr,"*** Error: awaicgen_write_mcmiter: error %s %s; %s %d\n",
              "writing pixels to:", outfitsname, "FITS error code =", status);
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  fits_close_file(ffp_FITS_Out, &status);

  if( status ) {
    fprintf(stderr,"*** Error: awaicgen_write_mcmiter: error %s %s; %s %d\n",
            "closing FITS file:", outfitsname, "FITS error code =", status);
    AWAP_Stat->I_status = 1;
    return 0;
  }

}
