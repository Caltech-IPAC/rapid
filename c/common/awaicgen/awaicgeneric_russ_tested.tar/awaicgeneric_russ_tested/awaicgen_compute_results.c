
/***********************************************
awaicgen_compute_results.c

Purpose

Main computational processing loop of program
for PRF-interpolated co-add (first iteration of MCM).
This also optionally creates a mosaic mask (not made
by the other awaicgen_compute_results* routines).
Depends on function in awaicgen_compute_prfcoadd.c
to support multi-threading.

Input-to-output interpolation is based on using
input PRF(s) as the interpolation kernel(s).

See awaicgen_compute_results_simple.c for simple
co-add created using exact overlap-area weighting
or awaicgen_compute_results_hires.c for HiRes'ing.

***********************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <pthread.h>
#include "awaicgen.h"
#include "awaicgen_defs.h"
#include "fitsio.h"
#include "wcs.h"
#include "two_plane.h"
#include "distort.h"

double sigfigs(double, int);

void *awaicgen_compute_prfcoadd(AWA_Impix         *AWAP_Impix);

int awaicgen_compute_results(AWA_Constants     *AWAP_Const,
                      AWA_Filenames     *AWAP_Fnames,
                      AWA_Computation   *AWAP_Comp,
                      AWA_Impix         *AWAP_Impix,
                      AWA_Status        *AWAP_Stat)
{
  struct   WorldCoor *wcsoutput;
  struct   WorldCoor *rwcsoutput;
  char     *inheaderfits;

  float   **sig_cell_array, outin_area_ratio;

  long    i, ii, j, jj, k, tasksPerThread;
  long    fimgpix[2], xj_min, yj_min;
  long    naxis, naxes[2];

  int     m, iter=1, status=0, maxoffset=0, nkeys;
  int     n, p, t, ProjectionStatus;
  int     x_scl, y_scl, scalefact;

  fitsfile *ffp_FITS_In;
  fitsfile *ffp_FITS_Msk;
  fitsfile *ffp_FITS_Unc;

  pthread_t thread[AWAP_Const->NumThreads];
  AWA_Impix coaddata[AWAP_Const->NumThreads];

  if(AWAP_Stat->I_status)
    return 0;

/*----------------------------------------------------------------------*/
/* Copy some global variables into "AWA_Impix" global variables to use in
   each thread call to awaicgen_compute_prfcoadd.c below. */

  for(t = 0; t < AWAP_Const->NumThreads; t++) {
    coaddata[t].cp.cellnaxis1 = AWAP_Comp->cellnaxis1;
    coaddata[t].cp.cellnaxis2 = AWAP_Comp->cellnaxis2;
    coaddata[t].cp.mosnaxis1 = AWAP_Comp->mosnaxis1;
    coaddata[t].cp.mosnaxis2 = AWAP_Comp->mosnaxis2;
    coaddata[t].cp.numprfs = AWAP_Comp->numprfs;
    coaddata[t].cp.prfgriddim = AWAP_Comp->prfgriddim;
    coaddata[t].cp.imgnaxis1 = AWAP_Comp->imgnaxis1;
    coaddata[t].cp.imgnaxis2 = AWAP_Comp->imgnaxis2;
    coaddata[t].cp.prflistind = AWAP_Comp->prflistind;
    coaddata[t].cp.prfnaxis1 = AWAP_Comp->prfnaxis1;
    coaddata[t].cp.prfnaxis2 = AWAP_Comp->prfnaxis2;
    coaddata[t].cp.prfcrpix1 = AWAP_Comp->prfcrpix1;
    coaddata[t].cp.prfcrpix2 = AWAP_Comp->prfcrpix2;
    coaddata[t].cp.prfdata = AWAP_Comp->prfdata;
    coaddata[t].co.have_uncert = AWAP_Const->have_uncert;
    coaddata[t].co.have_masks = AWAP_Const->have_masks;
    coaddata[t].co.Weight_Flag = AWAP_Const->Weight_Flag;
    coaddata[t].co.Fatal_Bits = AWAP_Const->Fatal_Bits;
    coaddata[t].co.Sat_Bits = AWAP_Const->Sat_Bits;
    coaddata[t].co.want_msk = AWAP_Const->want_msk;
    coaddata[t].st.I_Verbose = AWAP_Stat->I_Verbose;
  }


/*----------------------------------------------------------------------*/
/* Define number of tasks per thread, rounded to nearest integer. Also
   assign input image pixel ranges for each concurrent thread to run below.
   Note: kstart,kend refer to 1D pixel indices; iistart,iiend refer to
   indices along Y-axis of input image. */

  tasksPerThread = (long) (((AWAP_Comp->imgnaxis1*AWAP_Comp->imgnaxis2) +
                             AWAP_Const->NumThreads-1)/AWAP_Const->NumThreads);

  if( AWAP_Stat->I_Verbose )
    printf("awaicgen_compute_results: %s to process per thread (%s %d %s) = %ld\n",
           "average number of input pixels", "over", AWAP_Const->NumThreads,
           "threads", tasksPerThread);

  for(t = 0; t < AWAP_Const->NumThreads; t++) {
    k = 0;
    for(ii = 0; ii < AWAP_Comp->imgnaxis2; ii++) {
      for(i = 0; i < AWAP_Comp->imgnaxis1; i++) {
        if( k == t*tasksPerThread ) {
          coaddata[t].kstart = k;
          coaddata[t].iistart = ii;
        }
        if( k == (t+1)*tasksPerThread - 1 ) {
          coaddata[t].kend = k;
          coaddata[t].iiend = ii;
        }
        k++;
      }
    }
  }

  /* ensure indices for last thread don't exceed their allowed maxima. */

  coaddata[AWAP_Const->NumThreads-1].iiend = AWAP_Comp->imgnaxis2 - 1;
  coaddata[AWAP_Const->NumThreads-1].kend =
                      (AWAP_Comp->imgnaxis1*AWAP_Comp->imgnaxis2) - 1;

  if( AWAP_Stat->I_Verbose ) {
    printf("awaicgen_compute_results: input image pixel processing ranges %s:\n",
           "per thread (zero-based)");
    for(t = 0; t < AWAP_Const->NumThreads; t++) {
       printf("awaicgen_compute_results: thread %d: ystart = %ld, yend = %ld; ",
              t, coaddata[t].iistart, coaddata[t].iiend);
       printf("1D: kstart = %ld, kend = %ld\n", coaddata[t].kstart,
              coaddata[t].kend);
    }
  }


/*----------------------------------------------------------------------*/
/* Allocate memory to internal working arrays. */

  /*----------*/
  /* Internal mosaic sub-pixel (cell) grid sampled at pixel size:
     Mosaic_PixFact * Mosaic_CellFact * inp_image_CDELT or
     Mosaic_PixScal * Mosaic_CellFact. */

  AWAP_Impix->mos_cell_array = (float **) calloc(AWAP_Comp->cellnaxis2,
                                                 sizeof(float *));

  if( AWAP_Impix->mos_cell_array == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_compute_results: could not allocate %s\n",
            "memory for mos_cell_array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_compute_results: allocated %f MB for %s\n",
             (AWAP_Comp->cellnaxis1*
             AWAP_Comp->cellnaxis2*sizeof(float)/1.0E+06),
             "internal mosaic cell array.");
    }
  }

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ ) {

    AWAP_Impix->mos_cell_array[i] = (float *) calloc(AWAP_Comp->cellnaxis1,
                                                     sizeof(float));

    if( AWAP_Impix->mos_cell_array[i] == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_compute_results: could not %s\n",
              "allocate memory for mos_cell_array.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  /*----------*/
  /* Internal sub-pixel (cell) grid for Num_Iter = 1 uncertainties
     sampled at pixel size: Mosaic_PixFact * Mosaic_CellFact *
     inp_image_CDELT or Mosaic_PixScal * Mosaic_CellFact. */

  sig_cell_array = (float **) calloc(AWAP_Comp->cellnaxis2, sizeof(float *));

  if( sig_cell_array == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_compute_results: could not allocate %s\n",
            "memory for sig_cell_array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_compute_results: allocated %f MB for %s\n",
             (AWAP_Comp->cellnaxis1*
             AWAP_Comp->cellnaxis2*sizeof(float)/1.0E+06),
             "internal uncertainty (Num_Iter=1) cell array.");
    }
  }

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ ) {

    sig_cell_array[i] = (float *) calloc(AWAP_Comp->cellnaxis1, sizeof(float));

    if( sig_cell_array[i] == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_compute_results: could not %s\n",
              "allocate memory for sig_cell_array.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  /*----------*/
  /* Internal Cnum_j (cell pixel grid) array for computing <f_j>. */

  AWAP_Impix->Cnum_j = (float **) calloc(AWAP_Comp->cellnaxis2,
                                         sizeof(float *));

  if( AWAP_Impix->Cnum_j == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_compute_results: could not allocate %s\n",
            "memory for Cnum_j array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_compute_results: allocated %f MB for %s\n",
             (AWAP_Comp->cellnaxis1*
             AWAP_Comp->cellnaxis2*sizeof(float)/1.0E+06),
             "internal Cnum_j array.");
    }
  }

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ ) {

    AWAP_Impix->Cnum_j[i] = (float *) calloc(AWAP_Comp->cellnaxis1,
                                             sizeof(float));

    if( AWAP_Impix->Cnum_j[i] == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_compute_results: could not %s\n",
              "allocate memory for Cnum_j array.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  /*----------*/
  /* Internal NV_j (cell pixel grid) array for computing <f_j>. */

  AWAP_Impix->NV_j = (float **) calloc(AWAP_Comp->cellnaxis2, sizeof(float *));

  if( AWAP_Impix->NV_j == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_compute_results: could not allocate %s\n",
            "memory for NV_j array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_compute_results: allocated %f MB for %s\n",
             (AWAP_Comp->cellnaxis1*
             AWAP_Comp->cellnaxis2*sizeof(float)/1.0E+06),
             "internal NV_j array.");
    }
  }

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ ) {

    AWAP_Impix->NV_j[i] = (float *) calloc(AWAP_Comp->cellnaxis1,
                                           sizeof(float));

    if( AWAP_Impix->NV_j[i] == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_compute_results: could not %s\n",
              "allocate memory for NV_j array.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  /*----------*/
  /* Internal N_j (cell pixel grid) "coverage depth" array. */

  AWAP_Impix->N_j = (float **) calloc(AWAP_Comp->cellnaxis2, sizeof(float *));

  if( AWAP_Impix->N_j == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_compute_results: could not allocate %s\n",
            "memory for N_j array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_compute_results: allocated %f MB for %s\n",
             (AWAP_Comp->cellnaxis1*
             AWAP_Comp->cellnaxis2*sizeof(float)/1.0E+06),
             "internal N_j array.");
    }
  }

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ ) {

    AWAP_Impix->N_j[i] = (float *) calloc(AWAP_Comp->cellnaxis1,
                                          sizeof(float));

    if( AWAP_Impix->N_j[i] == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_compute_results: could not %s\n",
              "allocate memory for N_j array.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  /*----------*/
  /* Internal NSV_j (cell pixel grid) array for computing output uncerts.
     These output uncertainties are only valid for Num_Iter = 1. */

  AWAP_Impix->NSV_j = (float **) calloc(AWAP_Comp->cellnaxis2,
                                        sizeof(float *));

  if( AWAP_Impix->NSV_j == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_compute_results: could not allocate %s\n",
            "memory for NSV_j array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_compute_results: allocated %f MB for %s\n",
             (AWAP_Comp->cellnaxis1*
             AWAP_Comp->cellnaxis2*sizeof(float)/1.0E+06),
             "internal NSV_j array.");
    }
  }

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ ) {

    AWAP_Impix->NSV_j[i] = (float *) calloc(AWAP_Comp->cellnaxis1,
                                            sizeof(float));

    if( AWAP_Impix->NSV_j[i] == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_compute_results: could not %s\n",
              "allocate memory for NSV_j array.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  /*----------*/
  /* Allocate memory for output 8-bit mosaic mask if requested. Size
     corresponds to real size of output mosaic products. */

  if( AWAP_Const->want_msk ) {

    AWAP_Impix->mos_msk_array = (char **) calloc(AWAP_Comp->mosnaxis2,
                                                 sizeof(char *));

    if( AWAP_Impix->mos_msk_array == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_compute_results: could not %s\n",
              "allocate memory for mos_msk_array.");
      AWAP_Stat->I_status = 1;
      return 0;

    } else {

      if( AWAP_Stat->I_Verbose ) {
        printf("awaicgen_compute_results: allocated %f MB for %s\n",
               (AWAP_Comp->mosnaxis1*
               AWAP_Comp->mosnaxis2*sizeof(char)/1.0E+06),
               "output mosaic-mask array.");
      }
    }

    for( i = 0; i < AWAP_Comp->mosnaxis2; i++ ) {

      AWAP_Impix->mos_msk_array[i] = (char *) calloc(AWAP_Comp->mosnaxis1,
                                                    sizeof(char));

      if( AWAP_Impix->mos_msk_array[i] == NULL ) {
        fprintf(stderr,"*** Error: awaicgen_compute_results: could not %s\n",
                "allocate memory for mos_msk_array.");
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }
  }


/*----------------------------------------------------------------------*/
/* Loop over detector images. Read individually from disk and project. */

    /*----------*/
    /* Initialize the <f_j> component arrays: Cnum_j, NV_j where
       eventually <f_j> = Cnum_j / NV_j, also coverage depth:
       N_j, and output uncertainty component array NSV_j. */

    for( jj = 0; jj < AWAP_Comp->cellnaxis2; jj++ ) {
      for( j = 0; j < AWAP_Comp->cellnaxis1; j++ ) {

        AWAP_Impix->Cnum_j[jj][j] = 0.0;
        AWAP_Impix->NV_j[jj][j] = 0.0;
        AWAP_Impix->NSV_j[jj][j] = 0.0;
        AWAP_Impix->N_j[jj][j] = 0.0;
      }
    }

    /*----------*/
    /* Initialize projection flag. */

    ProjectionStatus = 0;

    for( m = 0; m < AWAP_Comp->numimages; m++ ) {

      fits_open_file(&ffp_FITS_In, AWAP_Fnames->Filename_FITS_Image[m],
                     READONLY, &status);
      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_compute_results: %s %s; %s %d\n",
                "error opening FITS file:",
                AWAP_Fnames->Filename_FITS_Image[m],
                "FITS error code =", status);
        AWAP_Stat->I_status = 1;
        return 0;
      }

      /*----------*/
      /* store pixel data from detector image m in 2D dynamic array. */

      AWAP_Impix->imgdata = (float **) calloc(AWAP_Comp->imgnaxis2,
                                              sizeof(float *));

      for( p = 0; p < AWAP_Comp->imgnaxis2; p++ )
        AWAP_Impix->imgdata[p] = (float *) calloc(AWAP_Comp->imgnaxis1,
                                                  sizeof(float));

      if( AWAP_Impix->imgdata == NULL ) {
        fprintf(stderr,"*** Error: awaicgen_compute_results: could not %s\n",
                "allocate memory for imgdata array.");
        AWAP_Stat->I_status = 1;
        return 0;
      }

      fimgpix[0] = 1;  /* column dim. in input image. */
      fimgpix[1] = 1;  /* row dim. in input image.    */

      /* pixel data is stored as: imgdata[y_pix-1][x_pix-1] where
         y_pix = 1..naxis2; x_pix = 1..naxis1. */

      for(fimgpix[1] = 1; fimgpix[1] <= AWAP_Comp->imgnaxis2; fimgpix[1]++) {

        fits_read_pix(ffp_FITS_In, TFLOAT, fimgpix, AWAP_Comp->imgnaxis1,
                      NULL, AWAP_Impix->imgdata[fimgpix[1] - 1], NULL,&status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_compute_results: error %s %s\n",
                  "storing pixel data from image",
                  AWAP_Fnames->Filename_FITS_Image[m]);
          AWAP_Stat->I_status = 1;
          return 0;
        }
      }

      printf("\n----------\n");
      printf("awaicgen_compute_results: %s #%d of %d: %s %s\n",
             "processing image", m+1, AWAP_Comp->numimages,
             AWAP_Fnames->Filename_FITS_Image[m],"...");

      /*----------*/
      /* get the WCS keywords from image m to use in projection below. */

      ffhdr2str(ffp_FITS_In, 1, NULL, 0, &inheaderfits, &nkeys, &status);
      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_compute_results: %s %s; %s %d\n",
                "error reading FITS header:",
                AWAP_Fnames->Filename_FITS_Image[m],
                "FITS error code =", status);
        AWAP_Stat->I_status = 1;
        return 0;
      }

      fits_close_file(ffp_FITS_In, &status);
      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_compute_results: %s %s; %s %d\n",
                "error closing FITS file:",
                AWAP_Fnames->Filename_FITS_Image[m],
                "FITS error code =", status);
        AWAP_Stat->I_status = 1;
        return 0;
      }

      /*----------*/
      /* read/store pixel uncertainty data (if specified) for detector image
         m in 2D dynamic array. These are assumed to be sigmas, not
         variances. */

      if( AWAP_Const->have_uncert ) {

        if( AWAP_Stat->I_Verbose )
          printf("awaicgen_compute_results: reading/storing %s #%d: %s %s\n",
                 "uncertainty image", m+1,
                 AWAP_Fnames->Filename_FITS_Uncert[m], "...");

        fits_open_file(&ffp_FITS_Unc, AWAP_Fnames->Filename_FITS_Uncert[m],
                       READONLY, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_compute_results: %s %s; %s %d\n",
                  "error opening FITS file:",
                  AWAP_Fnames->Filename_FITS_Uncert[m],
                  "FITS error code =", status);
          AWAP_Stat->I_status = 1;
          return 0;
        }

        AWAP_Impix->uncdata = (float **) calloc(AWAP_Comp->imgnaxis2,
                                                sizeof(float *));

        for( p = 0; p < AWAP_Comp->imgnaxis2; p++ )
          AWAP_Impix->uncdata[p] = (float *) calloc(AWAP_Comp->imgnaxis1,
                                                    sizeof(float));

        if( AWAP_Impix->uncdata == NULL ) {
          fprintf(stderr,"*** Error: awaicgen_compute_results: could not %s\n",
                  "allocate memory for uncdata array.");
          AWAP_Stat->I_status = 1;
          return 0;
        }

        /* uncertainty data is stored as: uncdata[y_pix-1][x_pix-1] where
           y_pix = 1..naxis2; x_pix = 1..naxis1. */

        for(fimgpix[1] = 1; fimgpix[1] <= AWAP_Comp->imgnaxis2; fimgpix[1]++) {

          fits_read_pix(ffp_FITS_Unc, TFLOAT, fimgpix, AWAP_Comp->imgnaxis1,
                        NULL,AWAP_Impix->uncdata[fimgpix[1] - 1],NULL,&status);
          if( status ) {
            fprintf(stderr,"*** Error: awaicgen_compute_results: error %s %s\n",
                    "storing pixel data from uncertainty image:",
                    AWAP_Fnames->Filename_FITS_Uncert[m]);
            AWAP_Stat->I_status = 1;
            return 0;
          }
        }

        fits_close_file(ffp_FITS_Unc, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_compute_results: %s %s; %s %d\n",
                  "error closing FITS file:",
                  AWAP_Fnames->Filename_FITS_Uncert[m],
                  "FITS error code =", status);
          AWAP_Stat->I_status = 1;
          return 0;
        }
      }

      /*----------*/
      /* read/store pixel mask data (if specified) for detector image m
         in 2D dynamic array. Assumes good pixels have value 0; "bad" pixels
         have integer values > 0 up to integer +2^31. */

      if( AWAP_Const->have_masks ) {

        if( AWAP_Stat->I_Verbose )
          printf("awaicgen_compute_results: reading/storing mask #%d: %s %s\n",
                 m+1, AWAP_Fnames->Filename_FITS_Mask[m],"...");

        fits_open_file(&ffp_FITS_Msk, AWAP_Fnames->Filename_FITS_Mask[m],
                       READONLY, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_compute_results: %s %s; %s %d\n",
                  "error opening FITS file:",
                  AWAP_Fnames->Filename_FITS_Mask[m],
                  "FITS error code =", status);
          AWAP_Stat->I_status = 1;
          return 0;
        }

        AWAP_Impix->mskdata = (long **) calloc(AWAP_Comp->imgnaxis2,
                                               sizeof(long));

        for( p = 0; p < AWAP_Comp->imgnaxis2; p++ )
          AWAP_Impix->mskdata[p] = (long *) calloc(AWAP_Comp->imgnaxis1,
                                                   sizeof(long));

        if( AWAP_Impix->mskdata == NULL ) {
          fprintf(stderr,"*** Error: awaicgen_compute_results: could not %s\n",
                  "allocate memory for mskdata array.");
          AWAP_Stat->I_status = 1;
          return 0;
        }

        /* mask data is stored as: mskdata[y_pix-1][x_pix-1] where
           y_pix = 1..naxis2; x_pix = 1..naxis1. */

        for(fimgpix[1] = 1; fimgpix[1] <= AWAP_Comp->imgnaxis2; fimgpix[1]++) {

          fits_read_pix(ffp_FITS_Msk, TLONG, fimgpix, AWAP_Comp->imgnaxis1,
                        NULL,AWAP_Impix->mskdata[fimgpix[1] - 1],NULL,&status);
          if( status ) {
            fprintf(stderr,"*** Error: awaicgen_compute_results: error %s %s\n",
                    "storing pixel data from mask:",
                    AWAP_Fnames->Filename_FITS_Mask[m]);
            AWAP_Stat->I_status = 1;
            return 0;
          }
        }

        fits_close_file(ffp_FITS_Msk, &status);
        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_compute_results: %s %s; %s %d\n",
                  "error closing FITS file:",
                  AWAP_Fnames->Filename_FITS_Mask[m],
                  "FITS error code =", status);
          AWAP_Stat->I_status = 1;
          return 0;
        }
      }

      /*----------*/
      /* set-up the structure for the plane-to-plane WCS transform:
         image m to output mosaic _cell_ grid. */

      wcsoutput = wcsinit(AWAP_Comp->outwcsheader);

      status = Initialize_TwoPlane_FirstDistort(&AWAP_Impix->twoplane,
                                                inheaderfits,
                                                wcsoutput);

      if( status ) {
        fprintf(stderr,"*** Error: awaicgen_compute_results: could not %s\n",
                "set-up plane-to-plane transform for cell grid.");
        AWAP_Stat->I_status = 1;
        return 0;
      }

      wcsfree(wcsoutput);

      /*----------*/
      /* set-up the structure for the plane-to-plane WCS transform:
         image m to output (real) mosaic mask grid. */

      if( AWAP_Const->want_msk ) {

        rwcsoutput = wcsinit(AWAP_Comp->outrwcsheader);

        status = Initialize_TwoPlane_FirstDistort(&AWAP_Impix->rtwoplane,
                                                  inheaderfits,
                                                  rwcsoutput);

        if( status ) {
          fprintf(stderr,"*** Error: awaicgen_compute_results: could not %s\n",
                  "set-up plane-to-plane transform for mosaic mask grid.");
          AWAP_Stat->I_status = 1;
          return 0;
        }

        wcsfree(rwcsoutput);
      }

      free(inheaderfits);

      /*----------*/
      /* for each detector pixel (D_x, D_y) in image m, transform to
         mosaic cell grid frame =(CD_x, CD_y) using fast WCS projection.
         Then transform native PRF coords centered at this pixel to mosaic
         cell grid using linear transformation and round to nearest integer
         cell pixel. Beware that PRF is not transformed using full non-linear
         WCS transformation from input image to mosaic plane. For large
         mosaics, there could be an inaccurate representation of the PRF
         flux distribution towards mosaic edges. */

      if(AWAP_Stat->I_status)
        return 0;

      /* launch concurrent threads according to input pixel processing
         ranges defined above for image m. */

      for(t = 0; t < AWAP_Const->NumThreads; t++) {
        if( AWAP_Stat->I_Verbose )
          printf("awaicgen_compute_results: creating thread %d...\n", t);

        coaddata[t].threadid = t;
        coaddata[t].twoplane = AWAP_Impix->twoplane;
        coaddata[t].rtwoplane = AWAP_Impix->rtwoplane;
        coaddata[t].mos_msk_array = AWAP_Impix->mos_msk_array;
        coaddata[t].Cnum_j = AWAP_Impix->Cnum_j;
        coaddata[t].NV_j = AWAP_Impix->NV_j;
        coaddata[t].NSV_j = AWAP_Impix->NSV_j;
        coaddata[t].N_j = AWAP_Impix->N_j;
        coaddata[t].imgdata = AWAP_Impix->imgdata;
        coaddata[t].uncdata = AWAP_Impix->uncdata;
        coaddata[t].mskdata = AWAP_Impix->mskdata;

        if( pthread_create(&thread[t], NULL, (void *)awaicgen_compute_prfcoadd,
                           &coaddata[t]) ) {
          fprintf(stderr,"*** Error: awaicgen_compute_results: %s %d; %s\n",
                  "problem creating thread", t, "quitting...");
          AWAP_Stat->I_status = 1;
          return 0;
        }
      }

      /* wait for threads to finish */

      for(t = 0; t < AWAP_Const->NumThreads; t++) {
        if( pthread_join(thread[t], NULL) ) {
          fprintf(stderr,"*** Error: awaicgen_compute_results: %s %d; %s\n",
                  "problem completing (pthread_join'ing) thread", t,
                  "quitting...");
          AWAP_Stat->I_status = 1;
          return 0;

        } else {
          if( AWAP_Stat->I_Verbose )
            printf("awaicgen_compute_results: thread %d run of %s finished.\n", t,
                   "\'awaicgen_compute_prfcoadd\'");
        }
      }

      /* Combine some parameter outputs that depend on entire input image
         being processed by all threads. */

      for(t = 0; t < AWAP_Const->NumThreads; t++)
        if( coaddata[t].ProjectionStatus )
          ProjectionStatus = 1;

      /*----------*/
      /* free memory in 2D pixel data array for image m. */

      for( p = 0; p < AWAP_Comp->imgnaxis2; p++ )
        free( AWAP_Impix->imgdata[p] );

      free( AWAP_Impix->imgdata );

      /*----------*/
      /* free memory in 2D pixel mask array for image m if masks
         were specified. */

      if( AWAP_Const->have_masks ) {

        for( p = 0; p < AWAP_Comp->imgnaxis2; p++ )
          free( AWAP_Impix->mskdata[p] );

        free( AWAP_Impix->mskdata );
      }

      /*----------*/
      /* free memory in 2D pixel uncertainty array for image m if
         uncertainty images were specified. */

      if( AWAP_Const->have_uncert ) {

        for( p = 0; p < AWAP_Comp->imgnaxis2; p++ )
          free( AWAP_Impix->uncdata[p] );

        free( AWAP_Impix->uncdata );
      }

    }  /* end of loop for detector image m. */

    /*----------*/
    /* compute the PRF and inverse variance weighted average flux array
       per cell pixel j. Also compute the output uncertainty for cell
       pixel j. */

    for( jj = 0; jj < AWAP_Comp->cellnaxis2; jj++ ) {
      for( j = 0; j < AWAP_Comp->cellnaxis1; j++ ) {

        AWAP_Impix->mos_cell_array[jj][j] = AWAP_Impix->Cnum_j[jj][j] /
                                            AWAP_Impix->NV_j[jj][j];

        sig_cell_array[jj][j] = sqrt(AWAP_Impix->NSV_j[jj][j]) /
                                     AWAP_Impix->NV_j[jj][j];
      }
    }

    /*----------*/
    /* If output base filename specified (-o7), write mos_cell_array[jj][j]
       array to FITS file. Really for diagnostic purposes. Note: this image
       contains no WCS keywords. Output FITS filename will be:
       <Filename_Output_MosaicCell>_iter. */

    if( strcmp(AWAP_Fnames->Filename_Output_MosaicCell,"") ) {

      awaicgen_write_mcmimg(AWAP_Impix->mos_cell_array,
                         iter,
                         AWAP_Comp,
                         AWAP_Fnames,
                         AWAP_Stat);

      if(AWAP_Stat->I_status)
        return 0;
    }


/*----------------------------------------------------------------------*/
/* Check projection status flag to ensure some of the input pixels
   were projected. If not, abort with error message. */

  if( !ProjectionStatus ) {

    fprintf(stderr,"*** Error: awaicgen_compute_results: %s; %s\n",
            "none of the input pixels fell onto the WCS grid",
            "quitting...");
    AWAP_Stat->I_status = 1;
    return 0;
  }


/*----------------------------------------------------------------------*/
/* Free some undesired memory. */

  free( AWAP_Fnames->Filename_FITS_Image );

  if( AWAP_Const->have_uncert )
    free( AWAP_Fnames->Filename_FITS_Uncert );

  if( AWAP_Const->have_masks )
    free( AWAP_Fnames->Filename_FITS_Mask );

  free( AWAP_Comp->outwcsheader );

  free( AWAP_Comp->xprf );

  free( AWAP_Comp->yprf );

  for( i = 0; i < AWAP_Comp->numprfs; i++ )
    free( AWAP_Comp->prfdata[i] );

  free( AWAP_Comp->prfdata );

  for( i = 0; i < AWAP_Comp->prfgriddim; i++ )
    free( AWAP_Comp->prflistind[i] );

  free( AWAP_Comp->prflistind );

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ )
    free( AWAP_Impix->Cnum_j[i] );

  free( AWAP_Impix->Cnum_j );

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ )
    free( AWAP_Impix->NSV_j[i] );

  free( AWAP_Impix->NSV_j );

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ )
    free( AWAP_Impix->NV_j[i] );

  free( AWAP_Impix->NV_j );


/*----------------------------------------------------------------------*/
/* Allocate memory to final output mosaic product arrays. */

  /*----------*/
  /* Actual real output mosaic grid sampled at pixel size:
     Mosaic_PixFact * inp_image_CDELT or simply Mosaic_PixScal: */

  AWAP_Comp->mos_pix_array = (float **) calloc(AWAP_Comp->mosnaxis2,
                                               sizeof(float *));

  if( AWAP_Comp->mos_pix_array == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_compute_results: could not allocate %s\n",
            "memory for mos_pix_array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_compute_results: allocated %f MB for %s\n",
            (AWAP_Comp->mosnaxis1*AWAP_Comp->mosnaxis2*
             sizeof(float)/1.0E+06),
             "output mosaic pixel array.");
    }
  }

  for( i = 0; i < AWAP_Comp->mosnaxis2; i++ ) {

    AWAP_Comp->mos_pix_array[i] = (float *) calloc(AWAP_Comp->mosnaxis1,
                                                   sizeof(float));

    if( AWAP_Comp->mos_pix_array[i] == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_compute_results: could not %s\n",
              "allocate memory for mos_pix_array.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  /*----------*/
  /* Output mosaic coverage map at mosaic pixel scale: */

  AWAP_Comp->mos_cov_array = (float **) calloc(AWAP_Comp->mosnaxis2,
                                               sizeof(float *));

  if( AWAP_Comp->mos_cov_array == NULL ) {
    fprintf(stderr,"*** Error: awaicgen_compute_results: could not allocate %s\n",
            "memory for mos_cov_array.");
    AWAP_Stat->I_status = 1;
    return 0;

  } else {

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_compute_results: allocated %f MB for %s\n",
            (AWAP_Comp->mosnaxis1*AWAP_Comp->mosnaxis2*
             sizeof(float)/1.0E+06),
             "output mosaic coverage array.");
    }
  }

  for( i = 0; i < AWAP_Comp->mosnaxis2; i++ ) {

    AWAP_Comp->mos_cov_array[i] = (float *) calloc(AWAP_Comp->mosnaxis1,
                                                   sizeof(float));

    if( AWAP_Comp->mos_cov_array[i] == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_compute_results: could not %s\n",
              "allocate memory for mos_cov_array.");
      AWAP_Stat->I_status = 1;
      return 0;
    }
  }

  /*----------*/
  /* Optional output uncertainty image at mosaic pixel scale. This
     output product only makes sense for Num_Iter = 1 mosaic. */

  if( strcmp(AWAP_Fnames->Filename_Output_Uncert,"") ) {

    AWAP_Comp->mos_sig_array = (float **) calloc(AWAP_Comp->mosnaxis2,
                                                 sizeof(float *));

    if( AWAP_Comp->mos_sig_array == NULL ) {
      fprintf(stderr,"*** Error: awaicgen_compute_results: could not %s\n",
              "allocate memory for mos_sig_array.");
      AWAP_Stat->I_status = 1;
      return 0;

    } else {

      if( AWAP_Stat->I_Verbose ) {
        printf("awaicgen_compute_results: allocated %f MB for %s\n",
              (AWAP_Comp->mosnaxis1*AWAP_Comp->mosnaxis2*
               sizeof(float)/1.0E+06),
               "output uncert. image array.");
      }
    }

    for( i = 0; i < AWAP_Comp->mosnaxis2; i++ ) {

      AWAP_Comp->mos_sig_array[i] = (float *) calloc(AWAP_Comp->mosnaxis1,
                                                     sizeof(float));

      if( AWAP_Comp->mos_sig_array[i] == NULL ) {
        fprintf(stderr,"*** Error: awaicgen_compute_results: could not %s\n",
                "allocate memory for mos_sig_array.");
        AWAP_Stat->I_status = 1;
        return 0;
      }
    }
  }


/*----------------------------------------------------------------------*/
/* Set-up for downsampling and re-sizing of cell-grid arrays. */

  x_scl = (int)((AWAP_Comp->moscdelt1/AWAP_Comp->cellcdelt1) + 0.5);

  y_scl = (int)((AWAP_Comp->moscdelt2/AWAP_Comp->cellcdelt2) + 0.5);

  xj_min = (long)((double)(0.5 * (AWAP_Comp->cellnaxis1 - (x_scl *
                                  AWAP_Comp->mosnaxis1))));

  yj_min = (long)((double)(0.5 * (AWAP_Comp->cellnaxis2 - (y_scl *
                                  AWAP_Comp->mosnaxis2))));

  outin_area_ratio = (AWAP_Comp->moscdelt1 * AWAP_Comp->moscdelt2) /
                     (AWAP_Comp->imgcdelt1 * AWAP_Comp->imgcdelt2);

  /* Scale factor to use on coverage and uncertainty output pixels below
     so they will compress better. */

  if( AWAP_Const->SigFig ) {
    scalefact = exp2(floor((AWAP_Const->SigFig/log10(2)) + 1));

    if( AWAP_Stat->I_Verbose ) {
      printf("awaicgen_compute_results: scale factor for reducing %s %d\n",
             "precision in coverage and uncertainty output pixels =",
             scalefact);
    }
  }


/*----------------------------------------------------------------------*/
/* Downsample/re-size the cell grid mosaic array to desired pixel-scale
   and size. */

  if( AWAP_Stat->I_Verbose )
    printf("awaicgen_compute_results: down-sampling/re-sizing %s\n",
           "mosaic cell array...");

  for( ii = 0; ii < AWAP_Comp->mosnaxis2; ii++ ) {
    for( i = 0; i < AWAP_Comp->mosnaxis1; i++ ) {

      AWAP_Comp->mos_pix_array[ii][i] = 0.0;

      for( jj = (yj_min + y_scl*ii); jj < (yj_min + y_scl*(ii + 1)); jj++ )
        for( j = (xj_min + x_scl*i); j < (xj_min + x_scl*(i + 1)); j++ )
          AWAP_Comp->mos_pix_array[ii][i] += AWAP_Impix->mos_cell_array[jj][j];

      /* Down-scale flux according to cell versus output pixel area. */

      AWAP_Comp->mos_pix_array[ii][i] /= (x_scl * y_scl);

      /* If warranted, scale flux according to input vs. output pixel area. */

      if( AWAP_Const->Flxscal_Flag )
        AWAP_Comp->mos_pix_array[ii][i] *= outin_area_ratio;

      /*
      printf("DBG:(%d,%d) %20.15f\n",i+1,ii+1,AWAP_Comp->mos_pix_array[ii][i]);
      */
    }
  }


/*----------------------------------------------------------------------*/
/* Downsample/re-size the cell grid coverage array to desired pixel-scale
   and size. */

  if( AWAP_Stat->I_Verbose )
    printf("awaicgen_compute_results: down-sampling/re-sizing %s\n",
           "coverage cell array...");

  for( ii = 0; ii < AWAP_Comp->mosnaxis2; ii++ ) {
    for( i = 0; i < AWAP_Comp->mosnaxis1; i++ ) {

      AWAP_Comp->mos_cov_array[ii][i] = 0.0;

      for( jj = (yj_min + y_scl*ii); jj < (yj_min + y_scl*(ii + 1)); jj++ )
        for( j = (xj_min + x_scl*i); j < (xj_min + x_scl*(i + 1)); j++ )
          AWAP_Comp->mos_cov_array[ii][i] += AWAP_Impix->N_j[jj][j];

      /* Re-scale coverage according to input versus output pixel area. */

      AWAP_Comp->mos_cov_array[ii][i] /= outin_area_ratio;

      /* Optionally limit precision so will compress better on output. */

      if( AWAP_Const->SigFig )
        AWAP_Comp->mos_cov_array[ii][i] = (float)sigfigs(
                   AWAP_Comp->mos_cov_array[ii][i], scalefact);

      /*
      printf("DBG:(%d,%d) %20.15f\n",i+1,ii+1,AWAP_Comp->mos_cov_array[ii][i]);
      */
    }
  }


/*----------------------------------------------------------------------*/
/* Downsample/re-size the cell grid uncertainty array to desired pixel-scale
   and size. Only generate if output uncertainty filename specified. Also,
   this product only makes sense for a Num_Iter = 1 mosaic. */

  if( strcmp(AWAP_Fnames->Filename_Output_Uncert,"") ) {

    if( AWAP_Stat->I_Verbose )
      printf("awaicgen_compute_results: down-sampling/re-sizing %s\n",
             "mosaic-uncertainty (Num_Iter=1) cell array...");

    for( ii = 0; ii < AWAP_Comp->mosnaxis2; ii++ ) {
      for( i = 0; i < AWAP_Comp->mosnaxis1; i++ ) {

        AWAP_Comp->mos_sig_array[ii][i] = 0.0;

        for( jj = (yj_min + y_scl*ii); jj < (yj_min + y_scl*(ii + 1)); jj++ )
          for( j = (xj_min + x_scl*i); j < (xj_min + x_scl*(i + 1)); j++ )
            AWAP_Comp->mos_sig_array[ii][i] += sig_cell_array[jj][j];

        /* Down-scale sigma according to cell versus output pixel area. */

        AWAP_Comp->mos_sig_array[ii][i] /= (x_scl * y_scl);

        /* If warranted, scale sigma according to inp vs. out pixel area. */

        if( AWAP_Const->Flxscal_Flag )
          AWAP_Comp->mos_sig_array[ii][i] *= outin_area_ratio;

        /* Optionally limit precision so will compress better on output. */

        if( AWAP_Const->SigFig )
          AWAP_Comp->mos_sig_array[ii][i] = (float)sigfigs(
                     AWAP_Comp->mos_sig_array[ii][i], scalefact);

        /*
        printf("DBG:(%d,%d) %20.15f\n",i+1,ii+1,
               AWAP_Comp->mos_sig_array[ii][i]);
        */
      }
    }
  }


/*----------------------------------------------------------------------*/
/* Free undesired memory. */

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ )
    free( AWAP_Impix->mos_cell_array[i] );

  free( AWAP_Impix->mos_cell_array );

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ )
    free( sig_cell_array[i] );

  free( sig_cell_array );

  for( i = 0; i < AWAP_Comp->cellnaxis2; i++ )
    free( AWAP_Impix->N_j[i] );

  free( AWAP_Impix->N_j );

}

double sigfigs(double f, int accuracy)
{
  int exp;
  double man;
  man = frexp(f,&exp);
  return ldexp(rint(man*accuracy)/accuracy,exp);
}

